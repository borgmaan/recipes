# Salmon, Tuna or Mackerel Log

* 1 tin of salmon, tuna or mackerel
* 8oz soft cream cheese
* 1 T lemon juice
* 1 t grated onion
* 1 t horseradish sauce
* 1/4 t salt
* Topping:
* 1 c chopped nuts
* 3-4 T chopped parsley

Drain fish and combine with other ingredients.  Chill for 2 hours.  Roll into log and then in nuts and parsley.  Chill at least another 3 hours.

Source: Cornell Cookbook

