# Smoked Fish Quiche

* 175g shortcrust pastry
* 50g butter
* 1 medium onion, diced
* 225g smoked fish, flaked
* 1 pkt onion soup
* 1 1/2 c milk
* 2 eggs, beaten
* chopped parsley

Line an 18cm flan ring with the pastry.  Sauté the onions in the butter and place in pastry base.  Make sauce with onion soup powder and milk.  Add fish and simmer for 10 minutes.  Cool slightly before adding beaten eggs and chopped parsley.  Place mixture in pastry, garnish with sliced tomato or grated cheese and paprika.  Bake at 190C for about 30 minutes until set.

Source: Cornell Cookbook

