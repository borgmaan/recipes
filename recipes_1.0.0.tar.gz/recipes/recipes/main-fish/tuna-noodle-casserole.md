# Tuna noodle casserole

* 300g tuna
* 3 cup cooked pasta
* 1 can of condensed mushroom soup
* 1 can of milk
* 1/2 c grated cheese
* 1 c peas
* Topping
* 1/2 c grated cheese
* bread crumbs

Mix together all ingredients.  Top with grated cheese and breadcrumbs.  Bake at 350 F for 20 minutes or until cheese starts to bubble.


