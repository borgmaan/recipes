# Honey Crackles

* 4oz butter
* 4oz brown sugar
* 1T honey
* 4 c rice bubbles
* 1 c muesli

Boil butter, sugar and honey for 3 minutes (soft ball stage).  Mix in rice bubbles and muesli.  Chill and when cold slice into bars.

Source: Notebook

