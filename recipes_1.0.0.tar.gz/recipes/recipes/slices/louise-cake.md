# Louise Cake

* 3 3/4oz butter
* 1 1/2 c sugar
* 3 egg yolks
* 7 1/2 oz flour
* 1/4 t baking powder
* Raspberry Jam
* Topping
* 6oz sugar
* 3oz coconut
* 3 egg whites

Cream butter and sugar. Add egg yolks and sift in flour and baking powder.  Mix well.  Roll out fairly thin, put on a greased tray and spread on raspberry jam.  Beat egg whites until quite stiff and add sugar and coconut.  Mix and spread on top of jam.  Bake for 30 minutes at 180C


