# Coconut honey bars

* 4oz butter
* 1 D honey
* 1/2 c sugar
* 1 c coconut
* 1 c rolled oats
* 1 c cornflakes

Melt butter with honey.  Mix in remaining ingredients and cook in sandwich tin.  Bake at 180C for 25 minutes.


