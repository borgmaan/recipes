# Chocolate Fruit Bars

* 6oz flour
* 4oz butter
* 3oz brown sugar
* 3t cocoa
* 1t baking powder
* 1 c chopped dates
* 1 c chopped walnuts
* 1 egg

Sift flour and rub in butter.  Add  brown sugar, cocoa, baking powder, chopped dates, chopped walnuts.  Mix with egg.  Bake for 20-25 at 180C.

Source: Notebook

