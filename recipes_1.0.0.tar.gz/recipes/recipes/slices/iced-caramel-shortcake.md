# Iced Caramel Shortcake

* 6 oz butter
* 1 t baking powder
* 1 T cocoa
* salt
* 4 oz sugar
* 1/2 t vanilla
* 9 oz flour
* FILLING:
* 2 oz butter
* 1/4 t vanilla
* 1/2 tin condensed milk
* 1/4 c sugar
* 1 T golden syrup

Melt butter and add other ingredients.  Press half mixture into sponge roll tin.  

FILLING
Bring all to boil, stirring.  Pour on to base.  

Add 1T to remaining mixture and sprinkle on top.  Bake at 170C for 30 minutes.  Ice with chocolate icing while hot.  Cut and remove from tin while warm.

Time: 30 minutes  
Source: Onslow College Cookbook, page 144

