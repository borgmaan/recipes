# Caramel sultana square

* 4oz butter
* 4oz sugar
* 1 egg
* 1 1/2 c flour
* 2 T custard powder
* 1 t baking powder
* FILING:
* 3oz butter
* 1/2 tin sweetened condensed milk
* 2 T golden syrup
* 1/4 c sugar

Cream butter and sugar, add egg, then dry ingredients.  Divide shortcake in two.  Press one half into tin.

Melt butter, sweetened condensed milk, syrup and sugar and pour over base.  Sprinkle with sultanas and cover with remaining mixture.  Bake at 180C for 20-30 minutes.

Time: 50 minutes  

Comments: yummy  
Source: Rally cook book, page 64

