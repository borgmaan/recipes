# Nut fingers

* 6oz butter
* 6oz sugar
* 2 eggs
* 10oz dates
* 4oz walnuts
* 6oz flour
* 1 t baking powder

Cream butter and sugar, and beat in eggs.  Add dates and walnuts, sift in flour and baking powder, then mix well.  Bake in a Swiss roll tin at 180C for 20-25 minutes.


