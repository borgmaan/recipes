# Date squares

* 4oz butter
* 1 D golden syrup
* 1 egg, beaten
* 1 c sugar
* 1 c dates, chopped
* 1 c self-raising flour
* 1 c coconut
* 1/2 c walnuts, chopped

Melt butter and golden syrup.  Cool and add beaten egg.  Pour in the remaining ingredients and mix well.  Press into a Swiss roll tin and bake at 180C for 20-30 minutes.

Time: 30 minutes  

Comments: delicious  
Source: Rally cook book, page 68

