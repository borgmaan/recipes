# Chinese chew

* 4oz butter
* 1 D golden syrup
* 1 egg, beaten
* 1 c sugar
* 1 c sultanas
* 1 c flour
* 1 t baking powder
* 1 c coconut

Melt butter and golden syrup.  Cool and add egg.  Add remaining ingredients and press into sponge roll tin.  Bake at 150C for 30 minutes.  Cut while warm.

Time: 50 minutes  

Comments: very nice  
Source: Rally cook book, page 65

