# Coconut slice

* 1 1/2 c self-raising flour
* Pinch salt
* 1 c sugar
* 1 1/2 c coconut
* 6oz butter
* 3 eggs
* 3/4 c milk

Sift flour and salt into a basin, add sugar, coconut and melted butter.  Mix well.  Stir in beaten eggs and milk.  Pour into greased sponge roll tin.  Bake at 180C for 25-30 minutes.  When cold ice with lemon icing and sprinkle with coconut.  Cut into squares.

Source: Rally cook book, page 67

