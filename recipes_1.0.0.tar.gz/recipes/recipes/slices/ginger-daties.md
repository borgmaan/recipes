# Ginger daties

* 8oz butter
* 1 c sugar
* 2 c flour
* 1 T golden syrup
* 1 T milk
* 2 t ginger
* 2 t baking soda
* 1/2 t salt
* 2oz walnuts
* 3oz dates

Cream butter and sugar.  Warm syrup and milk and add soda and ginger.  Add chopped dates and nuts.  Sift in flour, salt and mix well.

Roll into balls, place on tray and flatten with a fork.

Bake for 15 minutes at 325 F.


Comments: This is a biscuit recipe, not a slice and is complete.  

Admin. please move it to the correct section.  
Source: Cornell Cookbook

