# Fruit Square

* 6oz butter
* 4oz sugar
* 2d golden syrup
* 2 c flour
* 2t baking powder
* 1/2 c walnuts
* 1/2 c raisins

Melt butter, sugar and golden syrup.  Sift in flour and baking powder.  Mix in raisins and walnuts.  Bake for 30 minutes at 180C.  Ice while hot.


