# Chocolate Slice

* 250g butter
* 1 c sugar
* 3 T cocoa
* 2 c coconut
* 2 c cornflakes
* 2 c flour, plain
* 2 t baking powder
* 1/4 t salt
* 1 t vanilla

Melt butter.  Stir in sugar and cocoa.  While sugar is dissolving mix in remaining ingredients. Press firmly into sponge roll tin.  Bake at 180C for 20 minutes.  Ice with chocolate icing.

Time: 35 minutes  
Source: Kid's Cookbook, page 101

