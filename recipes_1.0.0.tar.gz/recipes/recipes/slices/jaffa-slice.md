# Jaffa Slice

* 7 1/2 oz butter
* 1 1/2 D golden syrup
* 1 1/2 c coconut
* 1 1/2 c brown sugar
* 1 1/2 c cornflakes (or oats)
* 1 1/2 c flour
* 1 1/2 t baking powder
* grated rind of an orange

Melt butter and golden syrup.  Add remaining ingredients and mix well.  Spread in 8" x 8" tin.  Bake at 180C for 20 minutes.  Ice with jaffa (cocoa + orange juice) icing.

Source: Onslow College Cookbook, page 140

