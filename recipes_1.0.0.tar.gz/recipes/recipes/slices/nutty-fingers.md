# Nutty Fingers

* 1 c coconut
* 3/4 c brown sugar
* 1/2 c walnuts, chopped
* 4 oz butter
* 1 c rolled oats
* 1 t baking powder
* pinch of salt

Melt butter and add to dry ingredients.  Mix well.  Press into sponge roll tin and bake at 140C for 20 minutes.

Time: 20 minutes  
Source: Onslow College Cookbook, page 143

