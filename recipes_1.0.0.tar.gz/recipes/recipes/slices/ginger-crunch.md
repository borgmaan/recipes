# Ginger Crunch

* 6oz butter
* 4oz sugar
* 10 1/2oz flour
* 1 1/2 t ground ginger
* 1 1/2 t baking powder
* TOPPING:
* 2oz butter
* 4oz icing sugar
* 4 t golden syrup
* 2 t ground ginger

Cream butter and sugar, add sifted dry ingredients.  Knead well and press into a greased shallow tin.  Bake for 20 to 25 minutes at 190C.

TOPPING:
Heat all ingredients in a pot until melted.   Pour over cake when hot, and cut into squares before it gets cold.

Time: 25 minutes  
Source: Modified Edmonds recipe, page 38 1978 ed.

