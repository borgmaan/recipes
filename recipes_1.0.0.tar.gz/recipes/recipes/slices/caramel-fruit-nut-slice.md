# Caramel Fruit & Nut Slice

* 1/2 cup sugar
* 1 cup plain flour
* 1 cup dessicated coconut
* 1 tsp baking powder
* 100g butter melted
* 2 cups dried fruit - apricots and/or pitted prunes chopped in quarters, raisins, ginger, cranberrries  etc.
* 1 cup coursely chopped raw nuts or halved walnuts, pecans etc.
* 1 approx 400g can of sweetened condensed milk

Line a sponge roll tin (20cmx30cm) with baking paper.

Mix together sugar, flour, coconut, baking powder and combine with melted butter. Press into the lined tin and bake for 10 mins at 180 degrees C.

Remove from oven and randomly top the base with fruit and nuts in a single layer.  Drizzle condensed milk over this to coat the fruit and nuts evenily.

Bake a further 20 mins until golden.  Remove from oven and cool in the tin.  

Cut into squares or fingers when cold.  Keeps for one week in an airtight container.  

Freezes well.  

Easy to transport.


Comments: Rich and delicious for a special occasion. Use 2 or three types of dried fruits that look colourful and combine well flavourwise.    
Source: Rita V

