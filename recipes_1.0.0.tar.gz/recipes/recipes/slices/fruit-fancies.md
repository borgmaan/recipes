# Fruit fancies

* 6oz flour
* 1 t baking powder
* 4oz sugar
* 2oz coconut
* 4oz mixed fruit
* 4oz butter
* 1 T honey
* Milk

Sift flour and baking powder, add other dry ingredients and fruit.  Add butter and honey melted together and add enough milk to make a moist mixture.  Press into a sponge roll tin and bake at 180C for 20 minutes.  Ice if desired and cut into squares.

Time: 60 minutes  
Source: Rally cook book, page 69

