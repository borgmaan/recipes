# Cowboy Squares

* 100g butter
* 100g sugar
* 1T golden syrup
* 1 egg
* 1t vanilla
* 1 c sultanas
* 1 c flour
* 1t baking powder
* pinch salt

Melt butter, sugar and golden syrup.  Cool until luke- warm, then beat in egg and then remaining ingredients.  Lightly grease a Swiss roll tin and spread mixture over evenly.  Bake at 180C for 25 minutes.  Ice with lemon icing while still warm.  Cut into bars when cool.

Source: Cornell Cookbook

