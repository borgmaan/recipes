# Mincemeat Pinwheels

* 90g butter
* 1/2 c brown sugar
* 1 egg yolk
* 1 1/2 c plain flour
* 1/2 t mixed spice
* 1/4 t baking soda
* 1 T milk
* 1 c mincemeat

Cream butter and sugar.  Add egg yolk, beat until combined.  Add sifted flour, spice, soda and milk.  Press together to form a soft dough.  Turn onto lightly floured surface and knead for 2 minutes until smooth.  Leave, covered with plastic wrap, in refrigerator for 30 minutes.

Roll out onto lightly floured surface to a rectangle 20 x 28 cm.  Spread evenly with mincemeat.  Roll up from the long side.  Wrap in plastic, refrigerate 30  minutes.

Using a sharp knife cut log into 8 mm-thick rounds.  Place on prepared trays and bake for 10 minutes at 180C.

Time: 40 minutes  

Comments: An alternative to mince pies  
Source: Family Circle Bestever Christmas Book, page 48

