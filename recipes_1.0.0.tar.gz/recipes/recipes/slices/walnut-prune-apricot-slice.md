# Walnut Prune & Apricot Slice

* 1/2 cup sugar
* 1 cup plain flour
* 1 cup dessicated coconut
* 1 tsp baking powder
* 100g butter melted
* 1 cup pitted prunes chopped in quarters
* 1 cup dried apricots chopped in quarters
* 1 cup walnut halves
* 395g can sweetened condensed milk

Preheat oven to 180 degrees C.  Line sponge roll tin with baking paper.

Combine first five ingredients and press into pan.
Bake for 10 mins.

Sprinkle next three ingredients evenly over the top in a single layer.

Drizzle over condensed milk to coat fruit and nuts evenly.
Bake a further 20 mins until golden.

Remove from oven and cool in tin.  Cut when cold.


Comments: Easy and great to look at - even better to eat.  

