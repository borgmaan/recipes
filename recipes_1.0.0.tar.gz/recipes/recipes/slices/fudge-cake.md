# Fudge Cake

* 4 oz butter
* 3 oz sugar
* 1/2 t vanilla essence 
* 1 egg, beaten
* 2 D cocoa
* 1 t baking powder
* 1 c flour
* 1 c coconut
* 1 c sultanas

Cream butter and sugar and vanilla essence.  Beat in egg, then add dry ingredients.  Spread in shallow tin (8" x 10").  Bake at 180C for 20 minutes.

Cut and ice with chocolate icing while still warm.

Time: 20 minutes  
Source: Onslow College Cookbook, page 139

