# Quick Biscuit

* 5oz butter
* 1T golden syrup
* 8oz flour
* 1 c sugar
* 1 c cornflakes
* 1/2 c peanuts
* 1t baking powder
* 1 egg, beaten

Melt butter and sugar.  Add remaining ingredients and mix well.  Bake in a Swiss roll tin at 150C for 20 minutes.  When cool ice with lemon icing.

Source: Cornell Cookbook

