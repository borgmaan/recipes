# Weetbix delight

* 5 crushed weetbix
* 1 1/2 c flour
* 1 1/2 c coconut
* 1 c sugar
* 6oz butter, melted
* 1/2 t baking powder
* TOPPING:
* 1 T butter
* 1/2 tin sweetened condensed milk
* 1 1/2 T golden syrup

Add melted butter to dry ingredients.  Press into sponge roll tin.  Bake 15 minutes at 180C.

Heat butter, sweetened condensed milk and syrup until blended.  Spread on base and return to oven for 3 minutes.  Ice with chocolate icing while warm.

Time: 18 minutes  

Comments: delicious  
Source: Rally cook book, page 74

