# Coconut squares

* 4oz butter
* 1/2 c of sugar
* 1 c of flour
* 3/4 c of coconut
* 1/4 c of wheatgerm
* 1 t of baking powder
* 1 t of golden syrup
* Icing :
* 1/3 tin of condensed milk
* 1 c of icing sugar
* 1oz of butter
* 1 c of coconut
* 3 t of cocoa

Cream butter, sugar, golden syrup.  Then add other ingredients. Spread in a Swiss roll tin.  

Bake 180C for 20-25 minutes.

Icing:

Warm condensed milk and butter in a saucepan over low heat.  Blend in icing sugar, then coconut and lastly the cocoa.  Mix well and spread on cake while hot.  Cut into squares when it has cooled a little.


Comments: VERY GOOD  
Source: Onslow College Cookbook, page 138

