# Russian Square

* 6oz butter
* 1 c sugar
* 2 D  golden syrup
* 2 eggs
* 2 c sultanas
* 2 c flour
* 2 t baking powder
* 1 t vanilla essence

Melt butter, sugar and syrup.  Cool.  Add egg and other ingredients.   Bake at 180C for 20 minutes.

Time: 20 minutes  
Source: Rally cook book, page 72

