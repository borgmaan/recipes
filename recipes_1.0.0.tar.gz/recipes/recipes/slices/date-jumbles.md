# Date jumbles

* 4oz butter
* 4oz sugar
* 3/4 c milk
* 8oz dates
* 6oz flour
* 1oz cocoa
* 1 t baking powder

Warm butter, sugar and milk.  Add remaining ingredients and pour into sandwich tin.  Bake at 180C for 30 minutes.


LEMON DATE JUMBLE

Replace cocoa with flour and add 1 teaspoon lemon essence.  Ice with lemon icing.


