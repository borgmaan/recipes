# Anzac cake

* 1/2 c golden syrup
* 4oz (125g) butter
* 2 c self raising flour
* 1/2 castor sugar
* 1/2 shredded coconut
* 2 eggs, lightly beaten
* 1 c milk
* ICING
* 60g butter
* 1 t honey
* 1 t vanilla
* 1 1/2 c icing sugar
* 1 T hot water

Combine syrup and butter in pan, stir over heat until smooth.  Combine sifted flour, sugar and coconut in bowl, add syrup mixture and mix well.  Using an electric beater gradually beat in combined eggs and milk.  Pour mixture into a greased 20 x 30cm pan and cook at 180C for 30 minutes.  

ICING
Combine butter, honey, and vanilla in bowl.  Gradually beat in sifted icing sugar and water until smooth.


