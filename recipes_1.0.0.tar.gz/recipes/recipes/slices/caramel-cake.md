# Caramel cake

* 6oz butter
* 1 T golden syrup
* 1/2 c raisins
* 1 c raw sugar
* 2 c flour
* 2 t baking powder
* ICING:
* 1 1/2 T butter
* 1 1/2 T golden syrup
* Vanilla
* 1 1/2 c icing sugar

Melt butter and syrup then add raisins and dry ingredients.  Press into sponge roll tin and bake 20 minutes at 180C.  Ice and cut when warm.

ICING:
Melt butter, syrup and vanilla.  Add icing sugar and mix well.

Time: 50 minutes  

Comments: very good  
Source: Rally cook book, page 63

