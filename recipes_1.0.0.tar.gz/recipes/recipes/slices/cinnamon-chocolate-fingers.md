# Cinnamon Chocolate Fingers

* 4 oz sugar
* 4 oz butter
* 1 t cinnamon
* 1/2 t slat
* 7 oz flour
* 1 t baking powder
* 1 oz cocoa
* TOPPING:
* 4 oz icing sugar
* 2 oz butter
* 1 t golden syrup
* 1/2 t cinnamon
* 1 D hot water

Cream butter and sugar.  Sift together the dry ingredients and add.  Press into sponge roll tin.  Bake at 180C for 10 minutes..

TOPPING
In a saucepan put the icing sugar, golden syrup, hot water, butter and cinnamon.  Warm over low heat until boiling.  While it is still hot, pour over the hot cake.  Cool and set.  Cut into fingers.

Time: 10 minutes  
Source: Onslow College Cookbook, page 142

