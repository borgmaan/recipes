# Date, Honey and Oat Slice

* 100g butter
* 1 T honey
* 1 c rolled oats
* 1 c dates, chopped
* 1/2 c wholemeal flour, raw sugar, desiccated coconut
* 1/2 t baking powder

Melt butter and honey together and add dry ingredients.  Press into a greased 23cm tin and bake at 180C for 15 minutes.  When cool ice with lemon icing.

Time: 25 minutes  
Source: newspaper

