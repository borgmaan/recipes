# Coconut and Apricot Slice

* 1 1/2 c self-raising flour
* 1 1/4 c coconut
* 1 1/4 c castor sugar
* 1/3 c chopped, dried apricots
* 125g butter, melted
* 3 eggs, lightly beaten
* 3/4 c milk

Grease a 20cm by 30cm lamington pan, line base with paper then grease paper.  Sift flour into a bowl, add coconut, sugar and apricots; stir in butter, eggs and milk.  Pour mixture into prepared pan and bake at 180C for 30 minutes.  Let slice stand in pan for 10 minutes, turn on to wire rack to cool.

Source: Cornell Cookbook

