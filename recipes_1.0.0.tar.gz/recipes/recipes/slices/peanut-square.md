# Peanut square

* 4oz butter
* 3/4 c sugar
* 1 T golden syrup
* 1 T milk
* 5oz flour
* 1 t baking powder
* 1 c peanuts
* 1 c rice bubbles or cornflakes

Boil together butter, sugar, golden syrup and milk until it is slightly caramelised.  Cool.  Add dry ingredients.  Lastly add peanuts and rice bubble or cornflakes.  Place in a greased sponge roll tin and bake at 180C for 15-20 minutes.  Cut into squares while hot.

Time: 20 minutes  

Comments: very good  
Source: Rally cook book, page 71

