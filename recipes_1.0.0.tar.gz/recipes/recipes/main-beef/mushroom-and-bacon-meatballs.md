# Mushroom and bacon meatballs

* 500g mince
* 1 T Worcestershire sauce
* 1 T dry mustard
* 1 mushroom soup mix
* salt, pepper
* 1 egg
* 2 T oil
* 30g butter or margarine
* 125g mushrooms
* 3 rashers of bacon
* 2 T flour
* 1 beef stock cube
* 3 t prepared mustard
* 2 c water
* 1 T Worcestershire sauce
* 2 T dry sherry

Combine mince,  sauce, soup, salt, pepper and egg, mix well.  Shape tablespoonfuls of mixture into balls, heat oil in a large frying pan, add meatballs, brown well, remove from pan.  Add butter to pan.  When melted add chopped bacon and sliced mushrooms, sauté for 2 minutes, remove from pan.  Add flour and mustard to pan, stir until smooth and well browned.  Add water and crumbled stock cube, stir until sauce boils.  Add extra sauce, sherry, salt, pepper and meatballs.  Reduce heat, simmer covered 30-35 minutes.


