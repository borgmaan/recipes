# Speedy mince stroganoff

* 2 T butter or oil
* 1 large onion, chopped
* 500g mince
* 1 pkt mushroom soup
* 1 1/2 c water
* 2 T tomato concentrate
* 1/4 c sour cream
* 100-200g mushrooms

Melt butter in large pan, add onion and mince and brown on high heat.  Mix in mushroom soup and water, simmer for 10-15 minutes.  Stir in tomato concentrate, sour cream and mushrooms.  

Simmer for 4-5 minutes then serve with noodles.


