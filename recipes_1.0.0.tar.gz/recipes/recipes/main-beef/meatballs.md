# Meatballs

* 500g mince
* 1 egg
* 1 pkt mushroom soup
* 1 c rolled oats

Mix well, make into meatballs and cook in frying pan.  Use with sweet and sour pork sauce or with a spaghetti sauce.  Serve with rice for the former and spaghetti with the latter.


Comments: Excellent  
Source: Hadley Wickham

