# Chinese Beef

* 1/2 lb cold roast beef
* 1 med. onion
* 2 or 3 sticks of celery
* 1/4 lb mushrooms
* 1 t cornflour
* 1/4 t ground ginger
* 2 T soy sauce
* salt and pepper
* 8 oz long grain rice
* 1 T oil

Slice the beef into half inch strips.  Slice onions finely.  Cut celery into slices and chop mushrooms.  Heat oil in frypan, add the prepared vegetables and cook them over a low heat for 10 - 15 minutes.  Blend the cornflour, ginger and soy sauce together in a bowl.  Remove the pan from the heat and stir this mixture into the vegetables.  Return pan to the heat and when the sauce has thickened, sit in the beef, season to taste, then cook  it over a low heat for a further five minutes.  Meanwhile boil rice in salted water.  Drain.

Source: Onslow College Cookbook, page 62

