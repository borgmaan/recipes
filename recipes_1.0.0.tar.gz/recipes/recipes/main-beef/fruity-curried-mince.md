# Fruity curried mince

* 2 large onions
* 2 t curry powder
* 2 T butter
* 1 large apple
* 500g mince 
* 1 clove garlic, crushed
* 3 T flour
* 1 c beef stock
* 1/2 c crushed pineapple with juice
* 2 T lemon juice
* 1/2 t salt
* pepper to taste
* 2 t liquid gravy browning
* 1/2 c sultanas
* 1 T brown sugar

1.  Dice onions.  Combine with curry powder and butter in a medium-sized dish.  Micro-cook, uncovered, high power, 5 minutes.

2.  Peel, core and dice apple.  Add to casserole with the mince and garlic.  Micro-cook, uncovered, high power, 3 minutes.  Break up mince once during cooking.

3.  Add flour, beef stock, crushed pineapple, lemon, salt, pepper, gravy browning, sultanas and brown sugar.  Mix well, breaking up mince.

4.  Micro-cook, covered, high power, 10 minutes., stirring once during cooking.  Stand covered 5-10 minutes.  Serve hot on a bed of rice.

Time: 48 minutes  
Source: NZ Microwave Cookbook, page 24

