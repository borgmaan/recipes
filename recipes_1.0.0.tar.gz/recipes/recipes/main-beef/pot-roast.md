# Pot roast

* A couple of pounds of cheap pot roast meat
* 2 handfuls of 1-inch carrot slices
* 1 can diced tomatoes
* 2 cans water
* 2 T tomato paste
* 1/4 c lemon juice
* 1/4 c vinegar
* 3 T brown sugar
* 2 T worchestshire sauce
* 1/4 c tomato sauce
* 2 T mustard
* potatoes

Fry carrots in hot oil ~2 minutes (until browned) and remove. 

Pat dry and season meat.  Brown all sides in a couple T of oil over high heat.  Add tomatoes, water, carrots and tomato paste and cook for 3.5 hours at 350F.

(Optional) Add potatoes 90 minutes before done.

Rest for 20 minutes.  Pour off some sauce and thicken with cornstarch.

Source: From Jeff & internet

