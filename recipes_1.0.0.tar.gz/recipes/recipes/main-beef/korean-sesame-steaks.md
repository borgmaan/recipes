# Korean sesame steaks

* 4 Rib eye steaks or 500g skirt steak cut across grain in thin slice, or pork loin, chicken or lamb
* 2 T soy sauce
* 1-2 cloves garlic, crushed
* 1 T sesame oil

Combine the steaks with the remaining ingredients in a shallow dish or unpunctured plastic bag.  Leave to stand for 30 minutes.  

Pan-grill in a very hot pan until cooked as desired.  Add the remaining marinade and turn meat to coat with glaze.

Serve with rice.

Source: Meat International

