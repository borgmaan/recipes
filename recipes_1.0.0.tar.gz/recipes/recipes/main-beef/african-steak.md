# African steak

* 1/2 c flour
* 1/2 t salt
* 1/2 t baking soda
* 2 lb (1kg) steak, cubed
* 2 t sugar
* 1 c water
* 1/2 T Worcestershire sauce
* 3 T vinegar

Mix wet ingredients and pour into dry.  Mix well and pour over steak in casserole dish.  Cook for 2 1/2 hours at 180C.


