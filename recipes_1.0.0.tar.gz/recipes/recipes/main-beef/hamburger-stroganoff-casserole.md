# Hamburger stroganoff casserole

* 1 packet "kluski" noodles
* 50g butter
* 2 large onions
* 2 cloves garlic, sliced
* 200-300g button mushrooms
* 1 kg minced beef
* 1 pkt mushroom soup
* 1 T instant beef stock
* 2 c water
* 2-3 T tomato concentrate.
* 1 carton sour cream
* 1/4 c parmesan cheese

Cook noodles until barely tender.  Drain, rinse, and spread in one or more shallow greased (or sprayed) ovenware dishes.

While noodles cook, brown the onions, mushrooms and garlic in butter.  Remove from the pan.  Brown the mince until it loses its pinkness then add the soup mix, instant stock and water (or use 1/2 c wine, 1.5 c water).  Simmer five minutes, then add the mixture, tomato concentrate and sour cream.  Simmer five minutes longer, then spoon over the noodles.  Sprinkle with parmesan cheese.  Refrigerate until required.

To reheat, bake at 180ºC for 15 minutes covered, then uncovered for 15 minutes, or until hot right through and bubbling at the edges.

Source: Meat International

