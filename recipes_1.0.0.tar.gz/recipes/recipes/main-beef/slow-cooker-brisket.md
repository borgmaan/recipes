# Slow cooker brisket

* 2.5 lb brisket
* salt and pepper
* 4 cloves of garlic, crushed
* 1 bottle of stout
* 1/3 c tomato paste
* 1/3 c vinegar
* 1/3 c mustard
* 1/3 c soy sauce

Brown brisket, salt and pepper and garlic.  Cook in slow cooker on low for 8+ hours.

Source: Adapted from somewhere on the internet

