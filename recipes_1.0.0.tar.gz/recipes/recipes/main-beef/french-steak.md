# French steak

* 1 T flour
* 1 T Worcestershire sauce
* 1/2 t mustard
* salt & pepper
* 1 T vinegar
* pinch baking soda
* 1 1/2 c water
* 2 chopped tomatoes
* 1 chopped onion
* 2 lb steak cubes

Mix wet ingredients and pour into dry.  Mix well and pour over steak in casserole dish.  Cook for 2 1/2 hours at 180C.


