# Savoury mince

* 1 stick celery
* 1 onion
* 1 t butter
* 2 carrots
* 500g mince
* 37g pkt soup powder
* 2 T flour
* 1 c water
* 1 T Worcester sauce
* 2 T tomato sauce
* 1/2 c frozen peas

1.  Thinly slice celery and onion.  Combine in a medium-sized casserole dish with butter.  Micro-cook, uncovered, high power, 4 minutes.

2.  Peel and slice carrots.  Add to onions and celery with mince.  Mix well.

3.  Micro-cook, uncovered, high power, 4 minutes,. breaking the mince up once during cooking.  Drain off excess fat.

4.  Add soup powder, flour, water, Worcestershire and tomato sauces to mince.  Stir, breaking up mince.  Stir in peas.

5.  Micro-cook, covered, high power, 12-14 minutes., breaking up mince once during cooking.

Time: 37 minutes  
Source: NZ Microwave Cookbook, page 66

