# Beef Curry

* 1.5 kg blade or topside steak
* 2 large carrots
* 2 parsnips
* 4 small onions
* 2 apples
* 4 T flour
* 4 t curry powder
* 2 cloves crushed garlic
* .5 t salt
* 1 t ground pepper
* 1 c sultanas
* 2 T brown sugar
* 1 225gm can of crushed pineapple with juice
* 4 T lemon juice
* 4 T olive oil
* 1 small piece of ginger - grated

1.  Dice onions, combine with curry powder and cook in frying pan using oil.  Place in large casserole dish.
2.  Cut meat into bite sized cubes and brown in frying pan.  Remove and add to casserole dish.
3.  Prepare carrot, parsnip, and apple by peeling and cutting into cubes.  Add to casserole dish.
4.  Add rest of ingredients.
5.  Cook in 150 C oven for 120 minutes.
Serve with rice, and condiments such as banana, peanuts, sultanas, pineapple pieces, sliced tomatoes, and sliced cucumber.

Source: Brian Wickham

