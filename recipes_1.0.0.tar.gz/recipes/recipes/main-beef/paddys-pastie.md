# Paddy's pastie

* 1 packet of flaky pastry
*  Or short pastry made with :-
* 2 c flour
* 125g butter
* 1/2 c grated cheese
* water to mix
* 250g minced beef
* 2 medium potatoes, cubed
* 1 carrot, grated
* 1 c frozen peas
* 1 mushroom soup mix
* 1/4 c water
* 1/4 c chopped parsley
* 1 T Worcestershire sauce

Pastry:
Cut butter into flour until it looks like rolled oats, then add the grated cheese.  Add cold water, a few drops at a time, until the dough particle can be pressed together to form a ball.  Chill for 5 minutes or more then roll out thinly in two circles, one 25 cm in diameter, the other 22cm.

Line the thin with the bigger pastry circle.
 
Filling:
Mix together remaining ingredients thoroughly.  Cut the scrubbed potatoes into little-finger-nail sized cubes, coarsely grate the carrot and thaw the frozen peas.
Put the uncooked mixture into the lower uncooked pastry circle and cover with the remaining circle.  Dampen the two crusts where they meet, pinch them together and trim, leaving enough to fold over.  Crimp or otherwise decorate the edges.  Brush with beaten egg for golden glaze.  Cut a few steam vents in top.
Bake at 200C for 30 minutes then at 180C for another 30 minutes.


