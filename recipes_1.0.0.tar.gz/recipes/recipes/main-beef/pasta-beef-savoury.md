# Pasta & Beef Savoury

* 1 T oil
* 1 onion, finely chopped
* 500g mince
* 1/4 t salt
* 1/4 t pepper
* 1 c canned tomatoes
* 3/4 c tomato puree
* 1 t oregano
* 1/4 t sugar
* 1 c water
* 1 1/2 c small shell pasta

Fry onion in hot oil.  Add mince and cook until well browned.  Add salt, pepper, canned tomatoes, puree, oregano, sugar and water.  Stir it all together until it starts to boil.  Turn heat to low and simmer for 40 minutes.

Cook pasta. Put in a casserole dish and pour hot mince over.  Serve

Time: 60 minutes  
Source: Kid's Cookbook, page 58

