# Guinness Beef Stew with Dumplings

* 1.5kg rump steak cut into large chunks
* 350g bacon, diced
* 1 cup bacon or beef stock
* 355ml can of Guinness
* 400g tomato puree
* 1 T dried thyme
* 1-2 T brown sugar
* 3-4 cloves garlic, minced
* 2-3 medium onions 
* 2 sticks celery, chopped
* 250g mushrooms, sliced
* 3 carrots, peeled and chopped
* black pepper to season
* DUMPLINGS:
* 2 cups flour
* 2 t baking powder
* 1/2 t salt
* 50g butter
* 1 large egg
* 3/4 c milk
* 4 T finely chopped parsley

Saute bacon and beef in heavy frypan until coloured but not completely cooked.  Place in large casserole dish.  Deglaze frypan with stock and pour over beef.  Add stout, tomato puree, thyme and brown sugar.

Saute the garlic and onions until soft and lightly browned.  Add to meat.  Gently cook celery, mushrooms and carrots for a few minutes and add to meat. Season.  Cook covered for 2 hours at 150C.

Place dumplings in round shapes on top and bake a further 30 minutes at 180C.

DUMPLINGS:
Sift dry ingredients, work in butter.  Mix together egg and milk and add to mixture.  Add parsley.  


Comments: Serves 8  

