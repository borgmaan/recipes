# Hearty Beef Casserole

* 1.2 kg rump steak
* 4 rashers bacon
* 1/2 c flour
* 1 T mixed dried herbs
* 1 T oil
* 14 small pickling onions
* 400g can tomatoes, roughly chopped
* 1 2/3 c vegetable stock
* 3 medium carrots, chopped
* 3 celery sticks, chopped
* 400g parsnip, cubed
* 1/2 c red wine
* 3 large zucchini, sliced

Preheat oven to moderate 180 C.  Trim meat of any fat and sinew.
1.  Cut meat into 2 cm cubes.  Cut bacon into 2 cm strips.  Combine flour and herbs in a plastic bag .  Toss meat lightly in seasoned flour; shake of excess.  Reserve remaining flour.
2.  Heat oil in large heavy-based pan.  Add bacon, cook over medium-high heat until browned; drain on absorbent paper.  Cook meat quickly, in small batches over medium-high heat until well browned; lift out and drain on absorbent paper.
3.  Transfer meat, bacon and onions to large casserole dish.  Add tomatoes and stock.  Bake, covered, for 40 minutes.  Remove from oven; stir in carrots, celery, parsnip and combine wine and remaining flour.  Cover, return to oven and bake further 40 minutes.  Stir in zucchini, bake for further 20 minutes.  Serve hot with farmhouse loaf.

Source: Family Circle - Dinner P., page 96

