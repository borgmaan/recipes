# Mince and macaroni pie

* 1 cup cooked macaroni
* 350g mince
* 1 onion, sliced
* 1 pkt mushroom soup
* 1 c water
* 2 t Worchestershire sauce
* 4 slices buttered bread
* 1 c cheese, grated

Place cooked macaroni in bottom of a greased fairly shallow ovenware diish.  Mix together the beef, onion, soup mix, water and sauce.  Spread over the macaroni.  Remove the crusts from the bread.  Cut the slices to cover the top of the macaroni and place them butter side up.  Sprinkle cheese evenly all over the bread.  

Bake at 180 C for 45 minutes.

Time: 45 minutes  
Source: Alison Holst Family Cookbook, page 50

