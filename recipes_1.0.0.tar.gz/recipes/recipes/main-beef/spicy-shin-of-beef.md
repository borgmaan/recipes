# Spicy Shin of Beef

* 750g boned shin of beef in 20mm thick slices or 1-1.4 kg beef shin-on-bone, sliced 20mm thick
* 1/2 c tomato sauce
* 1/2 c water
* 3 T soy sauce
* 1 t honey
* 1 clove of garlic, crushed
* or 1 t grated ginger (optional)
* flour or cornflour to thicken
* chopped parsley to garnish

1.  Trim outer skin and any fat or gristle from beef.  Cut meat into rectangles about 50mm by 60mm, or leave rounds of shin on bone.  Place in casserole.
2.  Combine tomato sauce, water, soy sauce, honey, and optional garlic or fresh ginger.  Pour over meat.
3.  Cover casserole well and cook slowly at 150 C for about three hours or until beef is tender.  Thicken if desired with flour (or cornflour) mixed to a light paste with cold water.  Stir in paste and simmer for 10 minutes.
4.  Sprinkle with chopped parsley and service with mashed potatoes, brown rice or noodles, and a green vegetable.


Comments: Alternatives: Also works really well with pork spareribs, lamb or skinless chicken pieces.   
Source: Beef & Lamb

