# Lamb Spinach & Chickpeas

* 500g lamb  cut into 1-inch pieces
* 2 cloves garlic crushed
* 3 tablespoons olive oil
* 1 cup cubed peeled carrots
* 450g chickpeas drained
* 1/2 cup vegetable or chicken broth
* 1/2 cup canned or fresh chopped tomatoes 
* 1 tablespoon fresh lemon juice
* 400g washed spinach leaves
* Lemon wedges

Sprinkle lamb with salt, pepper. Heat oil in heavy large pot over medium-high heat. Add lamb and sauté until well browned. Add carrots and garlic and sauté until beginning to brown. Add chickpeas, broth, tomatoes and lemon juice and bring to simmer. Reduce heat to medium-low, cover pot and simmer gently until lamb is tender, about 1 hour.  

Add spinach and cook until wilted, stirring frequently,  Season to taste and serve with lemon wedges.

Source: Adapted from recipe in Bon Appétit  | February 1999

