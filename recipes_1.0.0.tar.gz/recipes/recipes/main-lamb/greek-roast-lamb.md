# Greek Roast Lamb

* Small boned leg lamb ( ~1kg)
* 1 head garlic divided into cloves but unpeeled
* juice of 1 orange
* 100ml red wine
* 2 sprigs fresh rosemary
* 1 onion cut inot wedges
* 1 aubergine diced
* 1 red pepper de-seeded and diced
* 1 green pepper, deseeded and diced
* 400g chopped tomatoes
* Salt and freshly ground black pepper

Put lamb in roasting pan and scatter garlic cloves around.  Pour over juice and wine and arrange rosemary sprigs on top.  Season.
Roast uncovered for 1 hour at 170C.

Remove from oven and reduce temperature to 140C.
Skim  off fat.  Squeeze garlic from 4 cloves and spread on top of lamb. (Remove other cloves to use some other time.) 

Mix together vegetables and place around lamb. Make an airtight tent over the pan with foil and return to bake for  a further 1 1/2 hours.  Alternatively place all in a large covered casserole dish.


Comments: Tender and delicious.
WW 5 points per serve of 125g meat per person.  

