# Indonesian roast lamb

* 1 small shoulder roast
* juice of 1 lemon
* 2 T dark soy sauce
* 3-4 drops tabasco
* 1 T oil
* 2 cloves garlic, chopped
* 1 t ground coriander
* 1/2 t ground ginger
* 1/4 c brown sugar
* 2 T smooth peanut butter
* 1/4 c water

Tie roast if necessary.  Put in an unpunctured bag with the next seven ingredients.  Marinate at least 1/2 hour, or up to two days. 

Take roast from marinade.  Heat marinade with the peanut butter and water until thick and bubbly to make the glaze.

Roast meat at 170C for 1-1.5 hours, as desired, brushing with glaze during last 10 minutes.  

To microwave, brush uncooked roast with glaze.  Cook at 50% to 50% power level, to an internal temperature of 70C, and about 15 minutes for each 750g.  Allow to stand for 10 minutes.  Slice and pour glaze, thinned if necessary, over meat.


Comments: Serve with rice.  
Source: Meat International

