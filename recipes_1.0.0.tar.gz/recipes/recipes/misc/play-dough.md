# Play Dough

* 2 c flour
* 1 c salt
* 2 T oil
* 4 T Cream of Tatar
* 2 c water
* Food colouring

Mix dry ingredients in a saucepan.  Add water and colouring and lastly oil.  Heat gently and turn slowly until it is cooked, or when it comes away from the sides easily.  Work lightly with floured hands and store in an air-tight container.

Source: Rally cook book, page 159

