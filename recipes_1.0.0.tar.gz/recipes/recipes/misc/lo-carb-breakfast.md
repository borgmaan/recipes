# Lo Carb breakfast

* SCRAMBLED EGGS & CHEESE FOR TWO
* 3 eggs
* 50 mls milk
* 20 g Feta cheese
* small sprig parsley washed and chopped
* ½ tsp butter
* Heat non-stick pan to moderately hot.
* Beat eggs and milk together.  Pour into hot pan.  Crumble over Feta cheese and sprinkle on parsley.
* Turn mixture with a spatula until cooked.
* Serve with fresh vegetables or tomato.




