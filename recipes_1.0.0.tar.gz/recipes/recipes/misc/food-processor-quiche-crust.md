# Food processor quiche crust

* Use metal cutting bade of food processor.
* Place 1 cup wholemeal flour in it and add 70gms cold butter cubed.  DO NOT mix yet.
* In a separate cup, add one or two teaspoons lemon juice to 1 cup of water.
*  
* Start to mix using pulse button while drizzling in water in a thin stream. Stop as soon as it looks like crumbs.  Test to see if it presses into a ball. DO NOT Over mix.
* Add filling. 
* Cook at 220 C for about 30 mins. 




Comments: From A Holst.
Meals without meat.1997  

