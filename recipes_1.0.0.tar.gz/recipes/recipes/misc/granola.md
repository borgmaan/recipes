# Granola

* 1/4 c oil
* 1 T honey
* ice cream container (total) of:
* oats
* wheatgerm
* bran
* coconut
* sunflower seeds
* nuts

Melt oil and honey.  Add in remaining ingredients and cool.

Bake 15 mins 180 C.  Stir after 7 mins.  

Source: Notebook, page 14

