# Blintzes

* BATTER:
* 2 eggs
* 1 c flour
* 1 t salt
* 1 c water
* FILING:
* 3/4 lb cottage cheese
* 1 egg
* 2 t sugar
* Lemon rind, grated
* Vanilla or cinnamon

Mix batter by adding salt and water to eggs and stirring gradually into the flour until smooth.  Heat pan, grease well.  Pour only enough batter into pan to make a very thin pancake, tipping pan in all directions to cover bottom.  Bake of one side until it blisters.  Shake out of pan on to board.

Press cottage cheese though colander, add egg and season to taste.

Place rounded tablespoon of filing in the centre of each pancake.  Fold over from both sides, and then fold over top to make a square.  Fry on both sides until golden brown.  Serve hot.


Comments: Nice  
Source: Rally cook book, page 117

