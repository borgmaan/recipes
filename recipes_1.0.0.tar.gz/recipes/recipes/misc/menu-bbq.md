# Menu: BBQ

* Vegetables Mediterranean Style
* Korean Sesame Chicken 
* Lamb Chops
* Sausages
* Crusty Bread
* Livi's Strawberry Pie
* Vanilla Yogurt

Adjust quantities to suit group.  If more than 6-10 people and extra salads and desserts.

BBQ meat until just cooked through without blackening surface.


