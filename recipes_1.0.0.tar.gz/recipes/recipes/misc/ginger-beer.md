# Ginger beer

* 1/4 t yeast
* 1 cup sugar
* 2T grated ginger, fresh
* juice from one lemon

Mix together in a 2L bottle.  Fill with warm water and leave in a warm place for 24-48 hours (until bottle feels hard).  Chill thoroughly and then open carefully!


