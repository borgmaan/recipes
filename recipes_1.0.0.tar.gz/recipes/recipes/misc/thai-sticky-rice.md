# Thai sticky rice






Comments: Rinse rice 2-3 times, until water runs clear. Place rinsed rice in a bowl and fill with cool water so the water is approximately 2-3 inches above the rice (see Step 1). Let the rice stand in water for 6-8 hours. Drain the rice, place it in a cheesecloth, wrap it up and put the cheesecloth inside bamboo steamer. Put 6-8 cups of water in sticky rice steamer and bring to a boil. Then place bamboo steamer inside sticky rice steamer (see step 2). Be sure the bottom of the bamboo steamer does not touch the boiling water. Place a standard 8 inch lid loosely over the top of the bamboo steamer (see Step 3). Steam the rice for 45 minutes (or until tender). Enjoy!  
Source: http://importfood.com/stickyrice.html

