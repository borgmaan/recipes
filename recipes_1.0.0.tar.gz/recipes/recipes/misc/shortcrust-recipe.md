# Shortcrust Recipe

* 1/4 lb butter
* 2oz castor sugar
* 1 egg
* 8oz flour
* 1t baking powder

Cream butter and sugar.  Add well beaten egg.  Sift in flour and baking powder.  Mix to a firm dough and chill in fridge.


Comments: Makes 16, 2 inch pie tops and bases.
Also very nice cut into shapes and stuck together with raspberry jam.  
Source: Cornell Cookbook

