# Apricot and Lemon Jam

* 500g dried apricots
* 9 c water
* 5 lemons
* 8 c sugar

Soak apricots in half the water overnight.  Boil whole lemons, uncovered, in remaining water until soft.  Remove lemons and retain water.  When cold slice lemons thinly, removing pips and setting aside.

Boil apricots in their soaking water until tender, add sugar and sliced lemons, together with the reserved water and pips.  (Tie the pips in a small muslin square.)  Boil until the jam thickens and a teaspoon of the mixture placed on a saucer wrinkles when pushed with a finger.

Remove pips and spoon jam into sterilised jars.  Seal while still hot.

Time: 90 minutes  
Source: Family Circle Bestever Christmas Book, page 41

