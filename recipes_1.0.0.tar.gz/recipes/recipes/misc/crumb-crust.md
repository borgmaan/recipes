# Crumb Crust

* 1/2 lb plain biscuits
* 4oz butter
* 1/2t cinnamon

Crush biscuit finely and mix with cinnamon and melted butted.  Press into dish.  Chill.

Source: Notebook

