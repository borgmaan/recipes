# Candied citrus peel

* 2 large oranges
* Sugar

1.  Cut oranges into 8ths, then remove flesh. Cut each wedge into 3-4 strips

1.  Put peel in pan and cover with cold water. Bring to boil & simmer for 5 mins.
    Drain, return to pan, cover with fresh water and re-boil. Simmer for 30 mins.

1.  Drain the peel, reserving cooking water.  Measure 100g sugar for each
    100 ml liquid. Mix sugar and liquid and heat until sugar dissolves.
    
1.  Add the peel and simmer for 30 minutes. Drain, then put on single layer
    on oven sheet and dry for 30 minutes in oven on lowest setting.
    
1.  Toss peel in sugar, and leave to air dry for at least an hour.

Source: [BBC good food](http://www.bbcgoodfood.com/recipes/candied-citrus-peel)
