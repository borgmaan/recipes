# Fruit filling for Shortcrust

* 4oz sultanas
* 3 t mixed spice
* water
* cornflour
* 1 t butter
* 1 t vanilla essence

Cover sultanas and mixed spice with water and boil.  Thicken with cornflour and add butter and vanilla essence.  Cool.

Source: Notebook

