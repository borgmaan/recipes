# Strawberry pie, Livi's

* 1 cup strawberries, crushed
* 1/3 cup sugar
* Juice of 1/2 lemon
* 1 Tablespoon butter
* 1 rounded Tablespoon of cornflour
* 2-3 cups ripe strawberries
* Pie shell
* Whipped cream

Crush 1 cup of berries in blender, put puree in pot with sugar, butter and lemon juice.  Stir when boiling, thicken with cornflour, then remove from heat and cool a little.  Pour over strawberries neatly arranged pointed side up in a pastry shell and chill.
Serve with cream.


Comments: Impressive to look at and very tasty.  

