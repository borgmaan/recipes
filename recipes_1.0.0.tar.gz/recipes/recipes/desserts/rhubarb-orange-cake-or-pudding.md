# Rhubarb & Orange Cake or Pudding

* 100g butter
* ½ cup white sugar
* 2 eggs
* 1 cup and two teaspoons of plain white flour
* 1 heaped teaspoon baking powder
* ¼ cup of milk
* 250gm rhubarb washed and chopped into 1 cm pieces
* ¼ cup light golden brown sugar 
* 1 small orange for zest and ¼ cup of juice
*  

Line a 23 x13 cm tin with baking paper.
Heat the oven to 160 C
Scrub the skin of one small orange clean

Finely grate the skin of the orange, avoiding the bitter white pith and set aside.  

Beat the softened (but not melted) butter and sugar together until light. 
Beat in the eggs one at a time with a teaspoon of measured flour to prevent the mix curdling.
Sift flour and baking powder together and stir gently by hand into the mix alternating with the milk. The mixture  should be soft, not stiff, so add a little extra milk if needed.  Add orange zest. 

Place the mix in the tin in and sprinkle raw rhubarb on the top.  Press it lightly onto the mix. Sprinkle with brown sugar.

Bake at 160 C for 40 minutes. Pour orange juice evenly over the top and bake for another 5 minutes.
Serve as a cake or pudding, warm with plain yogurt, or ice-cream.
Recipe can be doubled and cooked in two loaf pans. 

    


