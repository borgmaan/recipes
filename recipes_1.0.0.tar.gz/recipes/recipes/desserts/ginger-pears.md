# Ginger pears

* 2-3 pears peeled and cut into pieces
* 1 T butter
* 3 T golden syrup
* 100g butter
* 1/2 c brown sugar
* 2 T golden syrup
* 2 eggs lightly beaten
* 1 c flour
* 1/2 t baking powder
* 1 t ground ginger
* 1 t cinnamon
* pinch of nutmeg
* salt to taste

Preheat oven to 180 C.   Warm the first measure of butter and golden syrup in a 20cm baking tin.  Arrange the pear pieces in tin.

Cream the butter, brown sugar and golden syrup.  Gradually add the lightly beaten eggs to the creamed mixture.  Sift dry ingredients and fold into creamed mixture.

Spread mixture carefully over pears.  Bake 180 C 35-40 minutes.  Invert the tin onto plate to serve.

Drained tinned pears may be used on place of fresh pears.


