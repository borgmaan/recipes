# Pecan pie

* 3 eggs
* 180g water
* 420g brown sugar
* 1/2 t salt
* 60g butter, melted
* 1 T brandy/rum
* 2 t vanilla
* 240g pecan pieces

Mix together.  Fill pie crusts and bake at 400 F for 10 minutes, then reduce temp to 325 F and bake until center is set, about 65 minutes.

Source: Well done cooking classes

