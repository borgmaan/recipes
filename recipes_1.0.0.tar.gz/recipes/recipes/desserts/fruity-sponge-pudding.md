# Fruity sponge pudding

* FRUIT TOPPING
* 1/2 c dried apricots
* 1/2 c sultanas
* 1/2 c diced prunes
* 1 1/2 c water
* 1/4 c brown sugar
* 1/2 t cinnamon
* 2 T butter
* SPONGE
* 125g butter
* 1/2 c castor sugar
* 2 eggs
* 4 T jam
* 2 c self-raising flour
* 1/4 c milk

1. Combine dried fruit and water in a heatproof mixing bowl.  Micro-cook, high power, 4-5 minutes. or until fruit is plump.  Drain off excess liquid and reserve.  Leave fruit to stand in bowl.

2. Cream 125g butter and castor sugar.  Beat in eggs one at a time, followed by the jam.  Stir in flour alternately with milk and reserved fruit liquid.

3.  Stir brown sugar, cinnamon and 2 T butter into fruit mixture.  Spread sponge over the top.  Micro-cook, covered, medium-low power, 13-15 minutes.  Test for doneness with a skewer.  Stand covered, 5-10 minutes.  Turn out on to serving plate.

Time: 50 minutes  

Comments: Very good  
Source: NZ Microwave Cookbook, page 84

