# Chocolate log

* 4 eggs, separated
* 4oz flour
* 1/2 c sugar
* 115g dark chocolate
* 3/4 c cream
* 2T icing sugar
* 1T brandy

Beat yolks and add sugar and beat until thick and pale.  Break chocolate into pieces and melt. Add to yolks and sugar.  Beat egg whites until stiff and fold in. Fold in sifted flour. 

Spread into a greased and floured sponge roll tin with grease proof paper on bottom at 190C for 15 minutes.  

Remove and cover with layer of damp grease proof paper then put it in the refrigerator.  Whip cream with icing sugar and brandy.  Spread onto top and roll up.


Comments: At Christmas fill the log with whipped cream and thawed frozen raspberries.

Ice with chocolate icing to resemble a log.  
Source: Cornell Cookbook

