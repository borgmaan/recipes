# Quick oven dessert

* 1 can fruit
* cinnamon
* 1 egg
* 1 t vanilla
* 3/4 c sugar
* 1 c flour
* 1 t baking powder
* 4oz butter, melted

Place drained fruit in shallow ovenware dish.  Sprinkle with cinnamon to taste.  Beat egg and vanilla lightly, sift in sugar, flour and baking powder, mix until crumbly.  Distribute mixture evenly over fruit then pour melted butter over top.  Bake at 180C for approx. 30 minutes.


