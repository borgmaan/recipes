# Crunchy Fruit Squares

* 1 c thick fruit puree
* 1/4 c brown sugar
* 1 T flour
* 2 t lemon juice
* 3 oz butter
* 1/3 c brown sugar
* 2/3 c rolled oats
* 1/3 c coconut
* 1/2 t cinnamon
* 1/3 c flour

Mix fruit puree, 1/4 cup brown sugar, 1 T flour and lemon juice.  Cook in heavy pan over low heat for about 5 minutes, until thick.  Allow to cool.  Cream butter and 1/3 cup brown sugar.  Stir in 1/3 cup flour, rolled oats, coconut and cinnamon.  Press half of the mixture in a greased paper lined square cake tin 6".  Spread the cooled filling on top.  Drop the remaining mixture in even sized pieces on top.  Bake at 190C for 25 minutes.  Cut in squares when cold.  Serve with ice cream.

Time: 25 minutes  
Source: Onslow College Cookbook, page 160

