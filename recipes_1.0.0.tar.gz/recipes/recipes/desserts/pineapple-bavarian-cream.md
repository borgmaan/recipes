# Pineapple Bavarian Cream

* 1 pkt pineapple jelly
* 2 c hot water
* 1 t lemon juice
* 1/4 pint whipped cream
* 1 c crushed pineapple

Dissolve jelly in hot water, add lemon juice.  When beginning to set, beat until fluffy then gently fold in pineapple and whipped cream.  Set in wet mould.

Source: Notebook

