# Lemon Ice Cream Pudding

* BASE
* 75g butter, melted
* 2 c crushed cornflakes
* 1 T sugar
* FILLING
* 3 eggs
* 1 c cream
* 1/2 c sugar
* 1/4 c lemon juice
* 2 t lemon rind, grated

BASE
Mix melted butter with crushed cornflakes and sugar, press all but 2 T into Swiss roll tin.  Place in fridge to harden

FILLING
Lightly whip cream.  Separate eggs.  Beat egg whites until foamy.  Gradually add sugar and beat until stiff.  Beat yolks until creamy. Fold yolks into whites, then carefully mix in remaining ingredients.  Pile on base and sprinkle with retained base mixture and freeze.  Serves 10.

Time: 60 minutes  

Comments: NB
Be careful if you live in a place where people are advised to avoid eating raw eggs.  
Source: Rally cook book, page 88

