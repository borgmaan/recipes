# Cheese cake, black forest

* Crumb Crust:
* 250g plain chocolate biscuits
* 125g butter
* Filling:
* 1/2 c water
* 1 T gelatine
* 1 pkt cream cheese (250g)
* 3/4 c sugar
* 300ml thickened cream
* 1 T lemon juice
* 425g can cherries
* Topping:
* 1 T cornflour
* 1 T rum
* 1 T sugar
* 1/2 c cream, extra

Crumb Crust:

Crush biscuit finely, add melted butter; press mixture onto sides and base of greased 20cm spring form pan.  Refrigerate while preparing filling.  

Filling:

Beat cream cheese, sugar and lemon juice until smooth.  Sprinkle gelatine over water, dissolve over hot water, cool.  Add to cream cheese mixture, beat well, fold into whipped cream.  Drain cherries, reserve 3/4 c syrup; pit cherries.  Spoon 1/3 filling into crumb crust, arrange half the cherries over the filling; spoon another 1/3 filling over, arranged the remaining cherries over; top evenly with the remaining filling.  Refrigerate until firm.

Topping:

Place sugar and cornflour in a sauce pan, gradually stir in reserved syrup.  Stir until boiling, remove from heat, add rum.  Continue stirring for a few minutes to allow mixture to cool slightly.  Spread topping over cheese cake.  Swirl lightly into mixture with spoon.  Refrigerate until set.  Pipe around edge of cheese cake with whipped cream.


Comments: EXCELLENT  
Source: Cornell Cookbook

