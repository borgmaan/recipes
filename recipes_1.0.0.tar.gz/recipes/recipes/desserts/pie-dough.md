# Pie dough

* 1 lb butter
* 1 lb 5 oz pastry flour
* 4 oz buttermilk
* 2 t s
* 0.5 oz sugar
* 1 T vanilla

Keep everything very cold.  In food processor, pulse flour, and, in pieces, butter. Mix all other ingredients and add gradually until mealy.

Blind bake at 375 F for ~10 minutes.

Source: Well done cooking

