# Apple gingerbread

## Apples

* 3-4 apples
* 1/2 sugar
* 1/3 c water

Peel apples and put in baking dish. Sprinkle over sugar and water.  Place in 180 C oven while preparing topping.

## Topping 

* 1 t ginger
* 1 c flour
* 1/3 c sugar
* 1 t baking soda
* 2oz butter
* 1/2 cup golden syrup
* 1/2 cup water

Sift flour, ginger and soda in a bowl.  Add sugar.  Heat butter and golden syrup and mix into dry ingredients. Pour over hot apples and bake 30-45 minutes at 180C.

Alternatively heat already cooked apples in a microwave proof dish.  When hot pour mixture over and microwave, on high, for 6 minutes.

Time: 55 minutes  

Comments: very good  
Source: Rally cook book, page 177

