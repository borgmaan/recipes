# Apple crumble pudding

* 4 cooking apples
* 3/4 c water
* 1 t cinnamon
* 3/4 c rolled oats
* 2 1/2 T butter
* 1/2 c brown sugar
* VARIATIONS:
* Omit cinnamon and add:
* 1. Zest of half a lemon & 1/2 cup raisins or
* 2. 1/2 cup chopped dates or
* 3. 1 cup frozen or fresh berries
*  to sliced apples in dish.
*   
* 4. Add 1/4 cup chopped walnuts or pecans to topping

Slice apples in pie dish.  Cover with water and cinnamon.  Rub butter into dry ingredients and sprinkle on top.  Bake at 170C for 20 minutes or until apples are soft and topping crisp and brown.

Serve warm with vanilla ice cream or plain unsweetened yogurt.


Comments: An old fashioned, fast, easy, fairly low calorie dessert that is always delicious whether served plain or dressed up for company.  
Source: AW modification of traditonal NZ recipe

