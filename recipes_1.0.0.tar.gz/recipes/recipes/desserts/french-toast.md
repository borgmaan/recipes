# French toast

* 1 c milk/cream
* 3 eggs
* 2 T maple syrup
* 1 t vanilla essence
* 1/4 t salt
* 8 (1/2-inch) slices bread
* 4 T butter

Whisk first five ingredients together.  Soak bread for 30s each time, and then drain on a rack for 1-2 mins.  Fry in butter for 2-3 mins each side (until golden brown) and then bake for 10 mins at 375 F.

Source: http://www.foodnetwork.com/recipes/alton-brown/french-toast-recipe/index.html

