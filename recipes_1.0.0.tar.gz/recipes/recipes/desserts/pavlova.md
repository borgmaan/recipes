# Pavlova

* 4 egg whites                
* 1 t vinegar
* 3 T cold water    
* 1 t vanilla essence (less if pure)
* 1 cup castor sugar          
* 3 t cornflour

Beat egg whites until stiff, add cold water and beat again. Add castor sugar very gradually while still beating. Slow beater and add vinegar, vanilla and cornflour.  Pile up in saucer sized pile on greased tray and bake at 150 degrees C (300 degrees F) for 45 minutes, then leave to cool in the oven.

Garnish with lots of whipped cream and kiwifruit, strawberries, peach slices, whatever.


