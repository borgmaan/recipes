# Apple and walnut crisp

* 1 t cinnamon
* 1 1/2 c wholemeal flour
* 1/2 c rolled oats
* 1/2 t baking powder
* 1/4 t salt
* 1/2 c brown sugar
* 1/4 c chopped walnuts
* 100g butter
* 1 T golden syrup
* 1 t vanilla essence
* 3 apples
* rind of 1 lemon
* 2 T brown sugar
* 1/4 c sultanas

1.  Mix together cinnamon, flour, rolled oat, baking powder, salt, brown sugar and walnuts.

2.  Combine butter, golden syrup and vanilla in a separate bowl.  Micro-cook, high power, 1-1 1/2 minutes. or until the butter has melted.  Stir butter mixture into dry ingredients  Mix well.

3.  Thinly slice apples.  Press half the flour mixture into a dish approx. 34 x 18 cm.  Top with sliced apple, lemon rind, second measure brown sugar and sultanas.  Sprinkle with remaining flour mix.

4.  Micro-cook, uncovered, medium power, 8-11 minutes. or until top is fairly dry.  (25 minutes. at 180C).

Time: 32 minutes  

Comments: Excellent  
Source: NZ Microwave Cookbook, page 83

