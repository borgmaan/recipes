# Chocolate pudding, self-saucing

* 1 c self-raising flour
* pinch salt
* 3/4 c white sugar
* 1/3 c cocoa
* 1/2 c milk
* 60g butter, melted
* 1 t vanilla essence
* 1/2 c brown sugar 
* 1 1/2 c water
* 3 t coffee powder

1.  Sift flour, salt, white sugar and 2 T cocoa into a 2-litre casserole or souffle dish.  Stir in milk, melted butter and vanilla essence.  Mix well.  Scrape down from sides and level the top.

2.  Sift brown sugar and remaining cocoa over pudding mixture.

3.  Combine water and coffee powder.  Micro-cook, high power, 2 minutes.  Pour carefully over the pudding.

4.  Micro-cook the pudding, high power, 8-10 minutes. or until the sponge rises up through the sauce.

Time: 27 minutes  
Source: NZ Microwave Cookbook, page 83

