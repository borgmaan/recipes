# Carrot Plum Pudding

* 1 c flour
* 4oz sugar
* 1t cinnamon
* 1t mixed spice
* pinch salt
* 1 grated carrot
* 1 c mixed fruit
* 1T butter
* 1t baking soda
* 3/4 c milk

Put all dry ingredients except for the baking soda in bowl and add fruit and carrot.  Add butter and soda dissolved in warm milk.  Steam for 3 hours

Source: Cornell Cookbook

