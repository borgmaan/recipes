# Butterscotch date walnut dessert

* 1 1/2 cup dates
* 1 1/2 cup water
* 50g butter
* 1 cup brown sugar
* 1/2 t baking soda
* 1 t vanilla
* 1/2 cup chopped walnuts
* 2 large eggs
* 1 1/2 cups self-raising flour
* BUTTERSCOTCH SAUCE:
* 50g butter
* 1/2 cup brown sugar
* 1/2 cup sour cream
* 1-2 T rum
* 1 t vanilla

Boil dates in water for 5 minutes.  Mash with potato masher.  Remove from heat and add butter and brown sugar.  Stir in baking soda and cool pot to room temperature.  Stir in vanilla and walnuts.  Sift in flour and fold in, mixing as little as possible.  Pour mixture in loaf tin and bake at 180 C for about 40-60 minutes.

Turn out onto rack after 10 minutes.  Slice warm cake and top with ice cream and sauce.

To make sauce, heat butter and brown sugar over moderate heat.  Remove from heat and stir in sour cream and add flavourings.

Source: Newspaper

