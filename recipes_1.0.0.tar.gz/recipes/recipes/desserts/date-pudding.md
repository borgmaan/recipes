# Date Pudding

* 3 eggs, beaten
* 1 c sugar
* 1/4 c sifted flour
* 1t baking powder
* 1/4t salt
* 1 c dates
* 1 c walnuts

Beat eggs and sugar until light.  Add flour baking powder and salt.  Stir in dates and nuts.  Bake in pan of hot water for 1 hour at 180C.

Source: Notebook

