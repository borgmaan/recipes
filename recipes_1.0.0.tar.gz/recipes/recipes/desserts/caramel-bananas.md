# Caramel Bananas

* 1 T butter
* 1 T brown sugar
* 1 banana

Put butter and sugar into a flat ovenproof dish and cook in microwave one minute at a time until it caramelises.  Cut bananas lengthwise and add.  Cook for approximately 10 minute.

Use 1 T butter and 1 T sugar for each banana.

Source: Onslow College Cookbook, page 96

