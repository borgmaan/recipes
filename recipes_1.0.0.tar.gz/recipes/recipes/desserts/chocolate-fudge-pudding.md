# Chocolate Fudge Pudding

* 1 c flour
* 1 t baking powder
* 1/2 t salt
* 3/4 c brown sugar
* 1/3 c chopped nuts (or coconut)
* 3/4 c milk
* 2 T melted butter
* 1 1/2 T cocoa
* vanilla essence
* TOPPING:
* 3/4 c brown sugar
* 1 1/2 T cocoa
* 1 3/4 c boiling water

Sift flour, baking powder, salt and cocoa together, add sugar and stir in milk and butter.  Add vanilla and nuts.  Pour into overproof pie dish.

TOPPING:
Mix together ingredients and pour over main mixture.  Bake at 180C for 50 - 60 minutes.  Serve with cream.

Time: 60 minutes  
Source: Onslow College Cookbook, page 101

