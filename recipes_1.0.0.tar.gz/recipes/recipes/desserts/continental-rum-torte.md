# Continental Rum Torte

* CAKE:
* 3 eggs, separated
* 3/4 c castor sugar
* pinch salt
* 1 c flour
* 1 t baking powder
* 1 T cornflour
* 1 t butter dissolved in 3 T boiling water
* MOUSSE:
* 4 oz dark cooking chocolate
* 1 T sugar
* 1 T water
* 1 T rum
* 2 eggs, separated

Beat whites of eggs with salt till stiff, gradually add sugar.  Fold in yolks and then sifted flour.  Quickly stir in boiling water and butter.  Pour into greased and floured 8" spring-form tin.  Bake at 180C for 30 minutes.  Remove sides of tin.

Melt chopped chocolate with sugar and water.  Add yolks, stir over boiling water to cook yolks for a few minutes but do not over heat.  Beat whites until very stiff and dry, gradually pour in the chocolate mixture and fold in gently.  Place side of tin around cooled cake.  Break surface of cake with a fork in several places, almost through to the base.  Spoon chocolate mixture over cake 1 T at a time, letting it run into the spaces.  Chill thoroughly till set.

Serve garnished with strawberries and cream.

Time: 30 minutes  
Source: Onslow College Cookbook, page 104

