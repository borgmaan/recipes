# Frozen chocolate crunch

* 4 oz coconut biscuits
* 4 oz slivered almonds
* 5 oz butter
* 1 c icing sugar
* 8 oz dark cooking chocolate
* 3 eggs, separated
* 2 L vanilla ice cream
* 1 t vanilla
* 2 T coffee liqueur

Crush biscuits coarsely, combine with slivered almonds.  Spread on oven tray, heat in slow oven until biscuit crumbs are crisp and almonds golden brown.  Cream butter and sugar, add egg yolks, vanilla, and coffee liqueur, beat until fluffy.  Melt chocolate in top of double boiler over warm water.  Cool, then add to butter mixture.  

Fold in firmly beaten egg-whites.  Press half biscuit in base of aluminium foil lined 8" square cake tin.  Pour half chocolate mixture on top, pressing down so nuts are held in mixture.  Slice ice cream over chocolate, then other half of chocolate mixture and lastly other half of biscuits, pressing nuts again into chocolate.  Freeze overnight.  Cut into slices to serve.

Source: Onslow College Cookbook, page 112

