# Ginger Steamed Pudding

* 4oz butter
* 2oz sugar
* 2T golden syrup
* 1 egg
* 8oz flour
* 1t ground ginger
* 1t baking soda
* 1/4 pint milk

Cream butter, sugar and syrup.  Add egg.  Dissolve baking soda in milk and add alternately with dry ingredients.  Steam for 2 hours.

Source: Notebook

