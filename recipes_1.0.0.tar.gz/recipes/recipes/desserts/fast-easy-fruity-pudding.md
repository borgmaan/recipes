# Fast & Easy Fruity Pudding

* 1 c large dark raisins or mixed fruit
* 1/4 c total nuts, peel and cherries if desired
* 1/2 c brown sugar
* 1 c milk
* 3oz butter
* a few drops each of lemon, almond and vanilla esssence 
* 1 c flour
* 1 t cocoa
* 1 t baking soda
* 1 t cinnamon
* 1 t mixed spice

Rinse fruit well under the hot tap in a seive to remove any grit.

Prepare an average size microwaveable pudding bowl by greasing well.

Put first five ingredients into a large sauce pan and warm slowly to simmer for a few minutes.  Take off heat and add essences, then remaining sifted ingredients.  

Mix well -it will puff up a lot as you are mxing. Put in the pudding basin, level the top surface and leave uncovered.

Place in the microwave and cook for seven minutes on high.

Pour sherry or brandy over to taste if desired.  Serve hot with vanilla icecream, yogurt or custard.


Comments: Very good if you like the flavour of traditional Christmas pudding, but not the heavy fruity texture. 

Can be made and consumed within half an hour!  

