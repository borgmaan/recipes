# Rhubarb family pudding

* 200g butter
* 1 c sugar
* 4 eggs 
* 2 c flour 
* 2 1/4 t baking powder 
* 1/3 c milk 
* TOPPING:
* 500g Rhubarb
* 1/2 c sugar 
* 1 T flour 
* 1 t cinnamon 
* icing sugar

In a food processor or bowl, cream the warmed (but not melted) butter and sugar, add the eggs one at a time, then stir in the dry ingredients alternately with the milk, until both are combined.  

Line a loose-bottomed 35 x 23 cm  tin with two strips of paper, so all sides and the bottom are covered, then spoon in the cake mixture in 16 spoonfuls, without spreading these smoothly.  

Remove all rough strings from the rhubarb and cut it into 1cm lengths.  Toss rhubarb in sugar, flour, and cinnamon, then sprinkle over the surface of the dough so that much of the rhubarb is between the batter rather than on top of it.  Sprinkle the remaining sugar mixture over the batter.  

Bake at 190C for 40-45 minutes, until golden brown and springs back when touched.

Cool in the tin for 15 minutes, then lift away from the sides of the tin, and remove the paper at the sides of the cake.  Sprinkle evenly with icing sugar, using a fine sieve.  Serve warm or reheated, cut in squares or rectangles.


Comments: EXCELLENT  
Source: Newspaper

