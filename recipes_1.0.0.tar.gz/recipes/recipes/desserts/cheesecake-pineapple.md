# Cheesecake, Pineapple

* crumb crust
* 1 D gelatine
* 1/4 c cold water
* 3 egg yolks
* 1 c crushed pineapple
* 2 D lemon juice
* 1 t grated lemon rind
* 1/4 c sugar
* 8oz cream cheese
* 3 egg whites
* 1/2 c sugar

Soak gelatine in water. Beat yolks, add pineapple, lemon and sugar.  Cook over water, stir until thick.  Add gelatine and dissolve.  Remove from heat and add cream cheese.  Stir until well blended.  Cool until mixture begins to thicken.  Beat egg whites and gradually add 1/2 c sugar, then fold meringue into pineapple mixture.  Pile into crust and chill.

Source: Notebook

