# Lemon Meringue Pie

* 170g Sweet Short Pastry
* 3 eggs, separated
* 1 c water
* Juice and rind of 2 medium lemons
* 1 c sugar
* 1 T butter
* 4 T cornflour
* 4 T castor sugar
* 1/2 t vanilla essence

Roll pastry and line a 23cm pie dish and bake at 200C for 20 minutes - cool.

FILLING:  Into a small pot place yolks of 3 eggs, water, lemon juice and rind, sugar butter and cornflour.  Heat until very thick and cook another 2-3 minutes.  When quite cold pour into baked pie shell and top with meringue.

MERANGUE:  Beat egg-whites until stiff then add the castor sugar a little at a time, beating well after each addition, then finally beat in the vanilla.  Spread meringue well over to the edges to seal.  Cook at 200C for 10 to 15 minutes until golden brown.

Time: 95 minutes  

Comments: delicious  
Source: Edmonds Cook Book, page 124

