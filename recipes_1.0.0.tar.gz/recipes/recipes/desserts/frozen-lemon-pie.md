# Frozen lemon pie

* Base:
* 2 c crushed malt meal wafers
* 3 T butter, melted
* 1 T sugar
* Filling:
* 3 eggs
* 1/2 pint whipped cream
* 2 t lemon rind
* 1/2 c sugar
* 2 t lemon rind
* 1/2 c sugar
* 1/4 c lemon juice

Mix biscuit crumbs, melted butter and sugar together and press into 2 8" tins retaining 2 T of mixture.  Separate eggs and beat whites till glossy, then in sugar till glossy,.  Beat yolks till thick and fold in.  Whip into crust and sprinkle with reserved crumbs.  Freeze.

Source: Onslow College Cookbook, page 118

