# Fresh fruit sauce

* 2 tangelos
* 1 lemon
* water
* 2 T custard powder
* 3 T white sugar
* 2 T brown sugar
* 1 banana, 3 plums, 6 strawberries or 1 1/2 c fresh fruit

Squeeze juice from tangelos and lemon.  Make up to one c with water.  Combine custard powder, white and brown sugar in a large measuring jug.  Stir in fruit juices slowly.  Micro-cook, high power 3 minutes, stirring once.  Dice remaining fruit and stir into sauce mixture. Micro-cook, high power, 2 in.  Thin or sweeten as desired.  Serve hot or cold with ice cream or steamed pudding.

Time: 15 minutes  

Comments: Tangy  
Source: NZ Microwave Cookbook, page 84

