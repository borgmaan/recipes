# Lemon sponge pie

* 1 c sugar
* 3 T flour
* 1 t lemon rind
* 2 T lemon juice
* 1 egg, separated
* 2 T butter, melted
* 1 c milk
* Pinch of salt
* 1 unbaked pie shell

Combine sugar and flour.  Stir in lemon rind and juice, beat in egg yolk, then melted butter.  Stir in milk.  Beat egg white and salt until stiff, then fold in to lemon mixture until no streaks of white show.  Pour into unbaked pie shell.  Bake at 180C for 35-40 minutes.  Cool for 15 minutes before cutting.


Comments: Good warm or cold  

