# Rhubarb and Orange tart

* 8oz sweet pastry
* 1 lb rhubarb
* 6oz sugar
* 1oz flour
* 1 egg, beaten
* Orange rind, grate
* 2 T orange juice
* 1/2 c water

Line a pie dish with sweet pastry.  

Wash rhubarb and cut into 2 1/2 cm lengths.  Place on pastry.  Bring water, sugar, rind and juice to boil in a saucepan.  Place egg and flour in a bowl and pour the juice and water over, stirring to blend, return to heat and stir until thick.  Pour over rhubarb.  Cut strips of pastry to form a lattice on top.  Bake at 200C for 30 minutes.

Time: 60 minutes  

Comments: delicious  
Source: Rally cook book, page 183

