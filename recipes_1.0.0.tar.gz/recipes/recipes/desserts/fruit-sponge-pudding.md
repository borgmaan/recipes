# Fruit Sponge Pudding

* Stewed fruit
* SPONGE TOP:
* 4oz (125g) butter
* 4oz (125g) sugar
* 1 egg
* 4oz (125g) flour
* 2 t baking powder

Half fill pudding dish or pie-disk with stewed, sweetened fruit and keep hot.  

Cream butter and sugar, add egg and beat well.  Add sifted flour and baking powder, and pour over hot fruit.  Bake about 45 minutes at 190C.  Sprinkle with icing sugar and serve hot.

Time: 45 minutes  
Source: Edmonds Cook Book, page 119

