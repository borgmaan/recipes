# Date & lemon self saucing pudding

* 1 c self raising flour
* 60g butter
* 1 T brown sugar
* 1/2 c chopped dates
* 2 t lemon rind
* 1 egg, lightly beaten
* 1/4 c hot water
* 1 c hot water
* 1/3 c golden syrup
* 3 t butter

Grease dish.  Rub butter into flour, add sugar, dates and lemon rind.  Add egg and 1/4 c water, then mix well.  Place in dish.  Combine golden syrup, 1 c hot water and butter, then pour over.  Bake for 40 minutes at 180C.


