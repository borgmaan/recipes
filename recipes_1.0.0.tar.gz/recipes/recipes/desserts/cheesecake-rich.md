# Cheesecake, rich

* CRUST:
* 1/2 c flour
* 2 T sugar
* 50g cold butter
* 1 egg yolk
* FILLING:
* 750g (3 cartons) cream cheese
* 1 c sugar
* 3 T flour
* 1 t vanilla
* 1 t fine grated citrus rind
* 3 eggs
* 2 T milk

To make the crust, either combine the first three ingredients in the food processor, mix until butter is finely chopped then add egg yolk and mix to a dough or rub or cut butter into dry ingredients, then add egg yolk and mix with a fork until combined.

Press mixture onto the bottom of a buttered or sprayed loose bottomed cake tin, 20 or 23 cm in diameter.  Bake base at 200 C for 5 minutes.

Soften cream cheese in a warm room or in a microwave oven (each carton warms in 30-60 seconds).  Blend softened cream cheese with the sugar, flour, vanilla and very finely grated lemon, orange or tangelo rind, then add the eggs and milk and beat until evenly smooth.  Use a food processor if available, or mix first by hand then using a beater, in a large mixing bowl.

Pour onto the partially cooked base.  Bake at 200 C for 15 minutes, then at 150 C for 45-60 minutes, until a pointed knife inserted in the middle comes out clean.

Leave to stand for 30 minutes then run a sharp knife around the sides of the tin and remove leaving the cheesecake sitting on the base of the tin.


Comments: EXCELLENT  
Source: Cornell Cookbook

