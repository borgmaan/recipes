# Pumpkin pie

* 8oz cream cream, room temp
* 3/4 c sugar
* 2 c pumpkin (1 large can)
* 1/4 t salt
* 1 egg + 2 egg yolks
* 1 c half & half
* 1/4 c butter, melted
* 1 t vanilla
* 1/2 t cinnamon
* 1/4 t ginger

Mix cream cheese and sugar, then beat in all other ingredients.  Pour in to pie crusts and bake at 375 until set, ~ 50 minutes.

Makes enough for two 9" pies.

Source: Well done cooking classes

