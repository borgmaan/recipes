# Monday pudding

* 3 slices bread
* 1 c milk
* 1 t baking soda
* 1 1/2oz butter
* 1/4 c sugar
* 2 T golden syrup
* 3 T flour
* 1 t mixed spice
* 1 c sultanas
* 1 c stewed apple

Soak bread in milk and beat with a fork until soft.  Add baking soda, melted butter and golden syrup, then fruit and dry ingredients.  Cover and steam in a greased basin for 2 hours.

Time: 120 minutes  

Comments: Excellent  
Source: Rally cook book, page 175

