# Bread and butter pudding

* 50g butter, softened 
* large baguette
* 60g sultanas or dried cranberries, or a mixture of both 
* 3 T apricot jam
* 2 large egg yolks 
* 2 large eggs 
* 40g caster sugar 
* 300ml double cream 
* 300ml milk 
* 4 tbsp Baileys 
* demerara sugar

Heat oven to 180C.

Grease large shallow ovenproof dish with butter.  Butter sliced bread.  Arrange bread in dish with dried fruit sprinkled between layers.  Spread apricot jam on lower layer.

Beat yolks, eggs and castor sugar together until creamy.  Add cream, milk and Baileys.  Pour mixture over bread. 

Gently press bread down and leave to stand for 20 mins.  

Sprinkle demerara sugar on top.  Place dish in roasting dish full of water in the oven (so water comes halfway up the dish).  Cook 40-50 mins.

Josh's notes: i put 200ml of Baileys in this pud.  the more the better I say. it's my wife that says 4 tbps. So some where in between the two values i suppose   


