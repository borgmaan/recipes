# Christmas pudding, rich

* 2oz flour
* 2oz soft breadcrumbs
* 4oz brown sugar
* 1oz chopped almonds
* 1 1/2 T rum or brandy
* 4oz butter
* 4oz sultanas
* 2oz currants
* 1oz chopped candied peel
* 4oz raisins
* 2 eggs
* 1/8 t salt
* 1/8 t nutmeg
* 1/8 t mixed spice
* 1/8 t ginger
* 1/8 t cinnamon
* 1/8 t baking powder

Sprinkle fruit with brandy and soak over night.  

Cream butter and sugar.  Gradually add beaten eggs, beating constantly.  Stir in sifted dry ingredients, add bread crumbs alternately with fruit and nuts.  

Put into large lined and greased basin.  Cover with aluminum foil and tie on with string. 

Sit on a trivet in a large saucepan and add boiling water 2/3 up the sides of the bowl.  Place the lid on the pan. 

Steam for 6 hours checking occasionally and topping up with boiling water.


Comments: Big enough for eight.  Very rich and delicous.  

