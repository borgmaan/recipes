# Couscous with chickpeas



Heat in a large skillet over medium heat:

3 T olive oil

Add

1 C sliced blanched almonds

Cook for about a minute

1 t paprika
1 t cumin
1 t coriander
1/2 - 1 t hot red pepper suace

Cook about 1 minute.  Stir in:

2 1/2 c chicken or vegetable stock
2 c cooked chickpeas
1 c currants

Bring to boil and stir in 1 1/4 c couscous.

Cover, remove from heat and stand 5 minues.  Fluff coucous with fork.

Season with salt and ground black pepper to taste.
Garnish with 1/4 c chopped fresh parsley or cilantro


Comments: Very tasty indeed AW  
Source: Joy of cooking

