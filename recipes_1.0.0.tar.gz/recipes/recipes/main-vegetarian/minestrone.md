# Minestrone

* 1 medium onion
* 1 tablespoon olive oil
* 1 tablespoon flour
* 2 medium carrots
* 1 small parsnip
* 1/4 cup fozen peas or handful of chopped fresh spinach
* 1-2 T tomato concentrate
* 1 handful pasta
* 600ml water
* sesaonings
* These quantities are approximate and can be varied to taste.  Vegetables can be varied to what you have on hand - try and ensure an attractive selection of colours.  Add enough tomato concentrate to give soup a distinctive reddish colour.  Season to taste.

Chop onions and gently cook in oil.  When soft stir in flour and cook for a few minutes longer - do  not brown.  Stir in 200 mls water and cook until thickened.  

Neatly dice all vegetables. Add all remaining ingredients except pasta.  Cook for about 10 minutes then add pasta.  Cook for a further 10 minutes.  Taste adn season.   Serve and enjoy.

Source: Jennifer Sleeman

