# Macaroni cheese

* 6 teaspoons (30g) margarine
* 6 teaspoons plain flour
* 1/2 teaspoon each powdered mustard and salt
* 1/8 teaspoon pepper
* 1 1/2 cups liquid skim milk
* 330grams tasty grated cheese
* 3 cups cooked macaroni
* 1 medium tomato, sliced
* 30 grams grated parmesan cheese

In 2 litre casserole add margarine; microwave on high until melted, 40-50 seconds.  Blend in flour, mustard, salt and pepper.  Using wire whisk or a fork, gradually stir in milk, mixing well.  Microwave milk mixture on high until thickened, 7-10 minutes, stirring 4 times during process.   Add tasty cheese, stirring until melted.  Add macaroni and stir to combine.

Put mix in 21x21x4 casserole dish that has been sprayed with non-stick spray.  Put tomato and parmesan on top.  Microwave on high 4-5 minutes.  Place under grill until lightly browned if necessary.

Each serve: 2 protein exchanges, 1 bread, 1/4 vegetable, 1 fat. 1/4 milk, 40 kJ optional.

Source: Weight Watchers Microwave, page 82

