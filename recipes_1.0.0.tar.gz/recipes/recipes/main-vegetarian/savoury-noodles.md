# Savoury Noodles

* 1 1/2 c macaroni
* 2 T butter
* 2 t vegetable stock
* 1 t green herb stock
* 1 t sugar
* 1/4 c chopped parsley
* 1 t cornflour

Cook noodles in unsalted water.  Drain, reserving 1/2 c of water.  Add butter, then stocks, sugar and parsley.  Mix cornflour to a paste and add.  Cook until noodles coated and no sauce left in pot.

Source: Notebook

