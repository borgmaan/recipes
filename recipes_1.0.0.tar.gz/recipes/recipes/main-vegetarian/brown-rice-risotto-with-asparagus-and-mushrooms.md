# Brown Rice Risotto with Asparagus and Mushrooms

* 1 large shallot, minced
* 1 cup mushrooms, chopped
* 2 tablespoons olive oil
* 1 cup brown rice
* 2 cups chicken broth
* 1 tablespoon tomato paste
* 1-pound of fresh asparagus
* 1/4 cup grated Parmesan cheese

Saute onion, mushrooms and rice.  Heat stock and paste to boiling and add gradually.  Cook partially covered.

Steam asparagus for 5-6 minutes and add just before serving.

Source: http://homecooking.about.com/library/archive/blv79.htm

