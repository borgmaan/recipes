# Crustless quiche

* 1 large onion
* 2 cloves garlic
* 1 T butter
* 3 eggs
* 3/4 t salt
* 1 c milk
* 1 c self raising flour
* 2 cubed potatoes, cooked
* 1 c diced mushrooms
* 1 c grated cheese

Cook onion, garlic and butter until tender.  Cool and add eggs, salt and milk.  Pour into large bowl and add flour, then stir with fork.  Add potatoes, mushrooms and cheese.
Pour into well sprayed 23cm flan tin.  Cook at 200C for 25-30 minutes.


