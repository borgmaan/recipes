# Brocolli and cheddar soup

* Croutons:
* 2 T butter melted
* 2 T olive oil
* 1 1/2 T mustard
* 1/4 t salt
* ~ 3 cups of wholegrain bread torn into small chunks
* Soup:
* 2 T olive oil
* 1 shallot, chopped
* 1 med. onion, chopped
* 1 large potato, cut into 1 cm chunks
* 2 cloves garlic
* 3 1/2 cup vegetable broth
* 1 large head of broccoli
* 2/3 c grated cheddar
* 1-3 t mustard

Croutons: mix butter, oil, mustard and salt and pour over torn-up bread.  Bake for 10-15 at 350C until crunchy.

Soup: saute shallots & onions for a few minutes.  Add potato, cover and cover until slightly tender.  Uncover, add garlic & broth and bring to a boil.  Add broccoli and cook until just tender, ~4 minutes.

Puree with immersion blender, and add cheese.   

Source: http://www.101cookbooks.com/archives/broccoli-cheddar-soup-recipe.html

