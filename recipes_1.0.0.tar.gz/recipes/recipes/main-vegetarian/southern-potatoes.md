# Southern potatoes

* 4 pounds red potatoes
* 6 bacon slices
* 1 bunch green onions, chopped
* 16 oz. sour cream
* 2 cups shredded cheddar cheese
* 1/3 cup butter, softened
* 1/4 cup milk (I use half-n-half)
* 1 teaspoon salt
* 1/2 teaspoon pepper
* 1/2 teaspoon garlic (optional)

Cook bacon in a large skillet until crisp.  Remove bacon and drain on paper towels, reserving 2 tablespoons drippings in skillet.  Add chopped green onions to skillet and cook for 1 minute or until tender.  Crumble  bacon and return to skillet.  Set mixture aside.
 
Cut potatoes into 1/4-inch pieces (you can peel the potatoes, but I leave the skins on for an extra kick of vitamins).  Place potatoes in boiling, salted water in a Dutch oven to cover and cook 15-20 minutes or until tender.  Drain and return to Dutch oven.
 
Add bacon/onion mixture to potatoes as well as sour cream, 1 cup of cheese, butter, milk (I use half-n-half), salt and pepper (and garlic, if desired).  Combine all ingredients with a potato masher until blended.  Spoon mixture into a lightly greased 13" x 9" baking dish.  Top with remaining cheese and bake at 350 degrees for 10 minutes or until cheese melts.

Source: From Susannah Koontz Webb

