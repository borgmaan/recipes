# Corn Fritters

* For 2 large servings
* 1 egg
* 1.5 cups drained cooked corn
* 3-4 tbsp liquid from corn or 0.25 cup milk
* 1 cup self raising flour

Heat about 1 cm deep of canola oil in a frypan on medium heat.

Put egg and liquid in a bowl and mix lightly.  Stir in the corn then add flour. Mix until flour is just moistened. Do not over mix (important).

Put teaspoonfuls of mix into hot oil and fry until golden brown on bottom.  Turn and cook on other side.  Drain on paper towels.  Serve hot.


Comments: For a tasty and quick meal at short notice.  
Source: Meals Without Meat A & S Holst

