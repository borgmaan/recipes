# Cheese & Carrot Squares

* 500g carrots
* 1 onion, diced
* 2 cloves garlic, crushed
* 25g butter
* 1 c self-raising flour
* 1 c cheese, grated
* 4 eggs, lightly beaten
* salt and pepper

Pre-heat the oven to 180C.  Peel the carrots and grate.
Saute the onion and garlic in butter in a heavy pan until soft.
Combine the carrots with flour and cheese, tossing to mix well.  Add onion and garlic.  Stir in the eggs then season with salt and pepper.

Place in a greased lasagne style pan and bake until set and golden brown, about 45 mins.

Source: Living Today

