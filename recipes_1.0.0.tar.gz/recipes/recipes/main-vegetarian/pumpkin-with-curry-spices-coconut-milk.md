# Pumpkin with curry spices & coconut milk

* 3 T oil (not olive)
* About 850g mixed pumpkin pieces peeled - leave skin on soft types eg butternut
* 1-2 cloves garlic crushed
* 1 t cinnamon
* 1 t turmeric
* 2 t curry powder
* 2 t salt
* 270ml coconut milk

Heat oil in heavy frying pan.  Add pumpkin and cook on high heat, turning frequently until well browned, even slightly blackened in places.  Add garlic and spices and cook 2 minutes until fragrant.  Add salt & coconut cream, stir to combine and cover pan with lid or foil.  Reduce heat and cook 10-15 minutes until pumpkin is tender.  If coconut milk reduces too far add a little water.  The sauce should coat the pumpkin.

Serves 4 as a curry with rice dish or 6 as a side dish.


