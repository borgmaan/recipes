# Edamame Soup

* 1 teaspoon olive oil 
* 1 medium onion, finely chopped 
* 1 potato, cubed
* 750 g (1 1/2 lb) frozen edamame beans, defrosted 
* 1 quart (1.2 litres or 2 pints) vegetable stock 
* 2 tablespoons creme fraiche 

Saute onion and potato.  Cover and allow to soften for 4 minutes.  Add bean and stock and simmer for 15-20 minutes until beans are tender.  Puree, then stir in cream.


Comments: Delicious and very simple  
Source: 101 cookbooks.com

