# Mock Whitebait Patties

* 1 egg
* 2 1/2 T flour
* 2 T milk
* 3 T cheese, grated
* Pepper and salt
* 2 medium potatoes, grated
* 1 t baking powder

Beat egg, add flour, milk, cheese and seasonings.  Add potato and baking powder just before frying.  Fry in hot, shallow fat 5 minutes on each side.  Serve hot, garnished with parsley.

Source: Edmonds Cook Book, page 85

