# Potato gratin (big)

* 2.5 lb potatoes, thinly sliced
* 3 T butter
* 3 T flour
* 2 cups milk
* 1/2 cup cheese
* 1/2 cup cheese
* breadcrumbs
* Optional: cubed ham

Layer sliced potatoes with salt, pepper and optionally ham in large baking dish.  Pour cheese sauce over layers.  Top with extra grated cheese and breadcrumbs.

Bake at 370 F for one hour, until potatoes are cooked and top is golden brown.

Source: Hadley and Jeff original

