# Indian Stir Fried vegetables

* 1 t black mustard seeds
* 1 t cumin seeds
* ginger/garlic/onion as preferred
* chopped vegetables
* 2 t ground coriander
* 1 t ground cumin
* salt chili (red) optional
* 1/2 t turmeric
* 1 T oil

Heat oil in a wok. Add mustard seeds (allow to pop)
Add grated ginger, garlic, diced onion and brown lightly.  Add chopped veges.

Add ground coriander, cumin, salt, chilli, turmeric, and a tiny bit of sugar.

Allow to cook to taste.  You can add a little bit of water if necessary. 

Chopped tomatoes may be added for a different flavour.

Source: Rita V

