# Firecracker Spuds

* 750g potatoes
* 2 T olive oil
* 2 T butter
* 1 medium onion, chopped
* 400g can tomatoes
* 1/2 c chicken stock
* 1 t chilli paste
* 1 t caraway seeds
* 2 t paprika

Peel and cut the potatoes in 2.5cm cubes.  Pat dry.  Heat the oil and butter in a heavy saucepan.  Saute the potatoes, turning regularly until they being to brown.
Add the onion and cook for 5 minutes.  Stir in the tomatoes and juice, stock and seasoning.  Simmer uncovered for 20 minutes or until the potatoes are tender

Source: Living Today

