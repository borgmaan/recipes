# Mushroom stroganoff -  july 2003

* 1 t oil
* 4 sticks celery chopped 
* medium onion - finely chopped
* 2 cloves garlic crushed
* 450g button mushrooms
* heaped tablespoon plain flour
* 125ml vegetable stock
* 1 t mustard (made up whole grain)
* 1 t marmite
* bay leaf
* salt & pepper
* 150g low fat natural yogurt

Saute celery, onion, garlice and mushoroms in oil for 5 mins until tender.  Add flour and cook for a few minutes more, then add vegetable stock and stir until sauce thickens.  Add mustard, marmite, bay leaf, salt & pepper.  Simmer for 1 minute then add yogurt.  Reheat gently and serve with pasta.

Add some stir fried chicken if liked.  
t = teaspoon


