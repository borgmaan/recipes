# Gingerbread, Sticky

* 125g butter
* 3/4 c brown sugar, packed
* 3/4 c golden syrup
* 1 egg, large
* 1/2 c + 2 T milk
* 2 c flour
* 4 t ginger
* 1 t baking soda

Line a 20cm square baking pan.

Melt butter then add brown sugar and golden syrup.  Add milk (without mixing) then sift in flour, ginger and baking soda.  Stir until evenly golden brown.

Pour into pan and bake at 160 C for 1 hour.

Time: 75 minutes  
Source: Newspaper

