# Honey loaf

* 8oz flour
* 4oz sugar
* 1 t baking powder
* 1 t baking soda
* 300ml water, boiling
* 2 T honey

Mix flour, sugar and baking powder.  Add the boiling water with honey and soda dissolved in it.  Pour into greased tin and bake at 180C for 1 hour.

Time: 75 minutes  

Comments: OK  
Source: Rally cook book, page 29

