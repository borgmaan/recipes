# Date loaf 

* 2 c water
* 1 c dried fruit - raisins or dates etc 
* 2 c flour
* 1 c brown sugar
* 1 T butter
* 1 t baking soda

Boil water, fruit and brown sugar 10 minutes.  Add butter.  Cool the mixture until nearly cold then add flour and baking soda.  

Put in loaf tin and bake 1-11/2 hours at 180 C.

Source: Cornell Cookbook

