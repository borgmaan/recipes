# Beer Bread

* 3 cups all-purpose flour
* 3 tsp. baking powder
* 1 1/2 tsp salt
* 3 Tbsp. sugar
* 1 (12 oz.) can beer
* 2-3 Tbsp. melted margarine

Grease loaf pan.  Mix dry ingredients.  Add beer and mix.  Put dough
in loaf pan.  Pour melted margarine over dough and bake 55 minutes at
375 degrees.

Alternate recipe:  Instead of 3 Tbsp. sugar, add 3/4 cup brown sugar,
1 tsp. cinnamon, and 1/2 cup raisins or walnuts.

Source: Dan Nettleton

