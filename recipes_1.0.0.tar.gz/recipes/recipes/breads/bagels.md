# Bagels

* 1lb strong white flour
* 1 T brown sugar
* 2 t salt
* 1 sachet (7g) easy blend yeast 
* 300 ml water

Mix flour, sugar, salt and yeast.  Add enough water to make dough.  

Knead.

Leave to double in size.  

Punch down, then form in 12 bagels.  Leave to double in size.

Drop in boiling water for 2 minutes, flip over and boil for another 1 1/2 minutes.  Drain.  Glaze with beaten egg.

Bake at 200 C for 12 minutes, then flip and bake for another 5 minutes until golden brown.


