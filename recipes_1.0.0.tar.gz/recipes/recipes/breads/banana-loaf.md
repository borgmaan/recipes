# Banana loaf

* 2 eggs
* 3 mashed bananas
* 1 c raw sugar
* 4 T melted butter
* 1 1/2 c wholemeal flour
* 1 t baking soda
* 1/4 t salt
* 2 tablespoons chocolate chips
* ½ cup pecans

Preheat oven to 180C.

Line a non-stick loaf tin with baking parchment.

Zap butter in microwave for 30 seconds to melt. Mix together eggs, mashed bananas, sugar and melted butter and beat well.  

Gently stir in flour, salt and soda ( add chopped pecans if wished) until just mixed. 

Place lined loaf tin. Decorate top with whole nuts and chocolate chips as desired.

Bake at 180C for for 1 hour.

Time: 60 minutes  

Comments: Delicious and super simple to make.

Great for starter cooks.  
Source: Modified "Rally cook book" page 114

