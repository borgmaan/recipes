# Sultana Loaf

* 1 cup white flour
* 1 cup whole meal flour
* 1 cup sugar
* 1.5 cups sultanas, raisins or other dried fruit
* pinch of salt
* 1 cup milk
* 1 Tbsp golden syrup
* 1 tsp baking soda
* 1/2 cup chopped walnuts

Rinse dried fruit in a sieve to remove any grit.  Place in a saucepan and cover with water and bring to the boil.  Add a tea bag and leave for 5 minutes. Drain well and return to cleaned saucepan. Discard tea bag.
  
Add syrup and milk to hot mixture then add soda, milk and nuts.  

Stir dry ingredients together and add to mix, stirring well.

Place in paper lined loaf tin.  Bake for 1 hour at 350 F (180 C).


Comments: Makes 1 loaf - uses tin approx 22.5cm x 11.5 cm x 5.5 cm  
Source: Grandma Nancy

