# Spianata

* Dough
* 1 teaspoon sugar
* 1/2 cup warm water
* 1/2 cup warm milk
* 1 tablespoon dried yeast
* 2 cups flour
* 1/2 teaspoon salt
* 2 tablespoons oil
* Filling
* 2-3 cups cold roasted 'Mediterranean' vegetables - red onions, courgettes, peppers, pumpkin etc
* 1 bunch spinach - wash then cook until wilted in water clinging to leaves
* 2 tablespoons tomato paste
* 1-2 tablespoons pesto
* 50g shaved ham or nay other tasty leftovers
* 100g middle bacon (3 full rashers approx.)
* grated parmesan

Make dough by sprinkling yeast over a mix of sugar, water and milk at lukewarm temperature.  When it begins to bubble add flour,salt and oil then knead until smooth and elastic.  Put in greased bowl and leave until doubled in size.

Roll out dough into rectangle about 30cmX36cm (on a non-stick flexible baking sheet to make the next steps easy).

Spread thinly with tomato paste and pesto.  Spread spinach, leftovers and roasted vegetables over.  Sprinkle with parmesan.  Gently roll like a sponge roll, enclosing vegetables. Arrange bacon over roll in crisscross design.  Place the sheet on a metal baking tray.  Bake in preheated 200C oven for around 20 minutes or until golden brown and hollow sounding when tapped.  Serve in thick slices with salad.


















Heat oven to 200C


Comments: Great for lunch or to take to a picnic/pot luck.
Looks spectacular and serves 6.
Like pizza but much lower fat!  

