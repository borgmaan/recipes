# Orange nut loaf

* 1/4 c dates, chopped
* 2 c flour
* 1/4 c raisins
* 1 t baking powder
* 2 T butter
* 1/4 t salt
* rind and juice of 1 orange
* 1 c sugar
* 1 t baking soda
* 1/2 c chopped walnuts
* 1 egg

Put the orange juice into a c and fill with boiling water.  Add the baking soda.  Pour this over the dates, raisins and butter. Mix together the flour, baking powder, salt, sugar and walnuts and add the former mixture with the beaten egg.  Vanilla essence may be added. 

Bake in a loaf tin for 45 minutes at 180 C.


Comments: EXCELLENT  
Source: Onslow College Cookbook, page 152

