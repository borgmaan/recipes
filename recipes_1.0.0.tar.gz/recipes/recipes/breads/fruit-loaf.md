# Fruit loaf

* 1/2 lb dates
* 2 eggs
* 2 t baking soda
* 4 c flour
* 2 c boiling water
* 1 c sultanas
* 4 oz butter
* 1 t salt
* 2 c sugar
* 1 c walnuts, chopped

Chop dates, add baking soda and pour boiling water over.  Leave to cool.  Cream and sugar, add eggs.  Sift flour and salt, add to mixture with sultanas and walnuts.  Lastly add chopped dates and liquid.  

Half fill 2 tins.  Bake at 170C for 1 hour.

Time: 60 minutes  
Source: Onslow College Cookbook, page 148

