# Kiwi Quick Mix Scones

* 1 1/2 cups plain flour
* 1/4 teaspoon salt
* 2 tablespoons butter
* 3 teaspoons baking powder
* 2 tablespoons boiling water
* 5-6 tablespoons milk 
* Variation Suggestions
* Date - add half a cup of chopped dates.
* Cheese - add 1 cup grated cheese and 1/4 teaspoon dry mustard powder to dry ingreds.
* Pinwheel - roll out into a rectangle 1cm thick.  Sprinkle with1/2 cup brown sugar and 1 teaspoon cinnamon.  Roll into log from short side and cut into slices.  Place on well greased foil or non-stick baking sheet for easy clean-up.
* Savoury - Add chopped cooked bacon and chopped parsley to dry ingreds.

Preheat oven to hot - 400 -450 F  220C

Sift flour, baking powder and salt.  Stir in any fruit/cheese etc.   

Melt the butter in the boiling water in  a cup and add the milk to bring it up to 3/4 cup.  

Pour wet ingredients into the dry.  Mix quickly and lightly with a spoon.  Mix should look soft and moist - add more milk if needed.  

Pat out into a rectangle on a lightly floured counter and cut into shapes - 8-10.

Brush tops with milk and bake immediately in a hot oven for 10 minutes.


Comments: Best eaten the day they are made.  Serve with butter.

USA - if they don't rise as much as they should, try increasing baking powder quantity.   
Source: Rally Cook Book

