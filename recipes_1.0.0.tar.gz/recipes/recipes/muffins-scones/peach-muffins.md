# Peach Muffins

* 1 c peaches, skinned & chopped
* 1/2 t cinnamon
* 1/2 c sugar
* 1 egg
* 1 c yoghurt
* 1/3 c butter or margarine, melted
* 2 T sherry
* 2 c flour
* 2 1/2 t baking powder

Lightly oil a muffin tin and preheat oven to 200C.  This recipe makes twelve muffins.

Put the first seven ingredients into a bowl and mix well.  Add the remaining ingredients and blend until just mixed.  Two-thirds will the muffin tins and bake for 15-20 minutes.

Time: 20 minutes  
Source: MMM Muffins, page 49

