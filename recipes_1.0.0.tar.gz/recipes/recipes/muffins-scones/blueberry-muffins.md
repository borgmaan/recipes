# Blueberry Muffins

* 1 egg
* 3/4 c milk
* 1/3 c oil
* 1 3/4 c flour
* 3/4 t salt
* 1/4 c sugar
* 2 1/2 t baking powder
* 2 T lemon rind
* 3/4 c blueberries

Lightly oil a muffin tin and preheat the oven to 200C.  This recipe makes 12 muffins.

Put the first three ingredients into a bowl and mix well.  Add the remaining ingredients except the blueberries and blend until just mixed, then fold in the blueberries.  Two-thirds fill the muffin tins and bake for 15-20 minutes.

Time: 20 minutes  
Source: Mmm Muffins, page 18

