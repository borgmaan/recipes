# Bran Muffins

* 1 heaped c bran
* 1 c milk
* 1 heaped tablespoon golden syrup
* 1 beaten egg
* 1 c flour
* 1 t soda
* 1/2 c sugar

Soak first three ingredient for 5 minutes.
Add egg, mix in dry ingredients. 
Bake 20 minutes at 180 C.

Source: Notebook

