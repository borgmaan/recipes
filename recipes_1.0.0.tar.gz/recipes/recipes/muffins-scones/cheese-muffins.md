# Cheese muffins

* 1 c flour
* 3oz butter
* 2 t baking powder
* 3 T grated cheese
* 1 egg
* 1/2 c milk

Sift flour, rub in butter, add cheese and baking powder.  Beat eggs and milk and add to dry ingredients.  Put spoonfuls in greased patty pans.  Bake at 200C for 10-15 minutes.

Time: 15 minutes  

Comments: OK  
Source: Rally cook book, page 34

