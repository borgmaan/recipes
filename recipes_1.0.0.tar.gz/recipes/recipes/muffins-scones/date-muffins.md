# Date Muffins

* 1 c milk
* 1 egg
* 2/3 c sugar
* 1 t vanilla
* 1/2 c melted butter or margarine
* 1 c dates, chopped
* 1/2 c walnuts, chopped
* 2 1/4 c flour
* 3 t baking powder

Lightly oil a muffin tin and preheat oven to 190 C.
Put the first seven ingredients into a bowl and mix well.  Add the remaining ingredients and blend until just mixed.  Two-thirds fill the muffin tins and place half a date on top of each muffin.  Bake for 15-20 minutes.

Source: MMM Muffins, page 41

