# Cupcakes

* 120g flour
* 140g caster sugar
* 1 1/2 t baking powder
* pinch salt
* 40g butter
* 120 ml milk
* 1 egg
* 1/2 t vanilla

Beat first five ingredients until sandy. Whisk together milk, egg and vanilla, then gradually mix in. 

Bake at 325C for 20-25 min.

Variations

* Chocolate: replace 20g of flour with cocoa.
* Coconut: replace all milk with coconut milk
* Espresso: replace equal volume with shot
* Rose: 1T rose water
* Apple tea: 2T boiling water + apple iced tea powder
* Earl grey tea bags

Soak in milk overnight:

* Ginger: 200g stem ginger in syrup
* Green tea: 3 tea bags
* Lavender: 3T dried lavender

Place in base (400g):

* Pineapple
* Peaches

Cut out segment of cook cupcake and fill with 200g:

* melted marshmallows
* nutella
* berries
* kirsch cherries
* dulche de leche
* ganache

Source: Hummingbird bakery (NZ version)

