# Apple muffins

* 8oz (225g) flour
* 1/2 t salt
* 6oz (175g)  sugar
* 1 c stewed apple
* 1 c sultanas
* 4oz (125g) butter
* 1 T mixed spice
* 1 egg
* 1 t baking soda

Sift the dry ingredients.  Stew the apples and while hot add the butter to melt.  Add to the dry ingredients together with the beaten egg.  Mix lightly and quickly.  

Put into greased muffin tins and cook for about 15 minutes at 200 C.


Comments: SUPERB  
Source: Onslow College Cookbook, page 151

