# Banana muffins, tropical

* 2 bananas, mashed
* 2/3 c yoghurt
* 2/3 c margarine, softened
* 3 eggs
* 3/4 c pineapple pieces, well drained, & roughly chopped
* 2 1/2 c flour
* 3/4 c sugar
* 2 1/2 t baking powder

Lightly oil a muffin tin and preheat the oven to 190C.  This recipe makes 24 muffins.

Put the bananas into a bowl and mash well.  Add the next four ingredients and mix until just blended.  Two-thirds fill the muffin tins and bake for 20-25 minutes.

Time: 20 minutes  
Source: MmM Muffins, page 16

