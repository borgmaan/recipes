# Carrot Muffins

* 1 c milk
* 1 egg
* 3 T margarine
* 1 c carrot, grated
* 1/2 c raisins
* 1 t cinnamon
* 1 t nutmeg
* 2 1/2 t baking powder
* 1/4 c brown sugar
* 1 3/4 c flour

Lightly oil and muffin tin and preheat oven to 190C.  This recipe makes 12 muffins.

Put the first seven ingredients into a bowl and mix well.  Then add the remaining ingredients and blend until just mixed.  Two-thirds fill the muffin tins and bake for 15 minutes.

Time: 15 minutes  
Source: MMM Muffins, page 23

