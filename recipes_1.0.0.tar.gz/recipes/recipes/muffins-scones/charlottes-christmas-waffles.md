# Charlotte's Christmas Waffles

* 1 cup white flour
* 1/2 cup rolled oats
* 1 heaping tablespoon sugar
* 1 well-rounded tablespoon baking powder
* 1/2 teaspoon salt
* 1 cup milk
* 1 large egg
* 1 egg yolk
* 1 egg white, beaten stiff.
* 3 tablespoons oil
* 1 teaspoon vanilla

Combine the dry ingredients in a large bowl. Combine the wet ingredients. Mix the wet ingredients into the dry ingredients very slowly. It's important to just trickle the wet ingredients in while mixing the dry ingredients vigorously with a fork. It may seem at first that there isn't enough liquid to moisten the flour, but it'll come out just fine.

Once the batter is made, fold in the stiff-beaten egg white.

Cook in waffle iron.


Comments: Made by Charlotte for Christmas day breakfast at Pacific Grove in December 2006.  
Source: Adapted fron Internet

