# Apple Muffins, Cashmere

* 1 egg
* 60g margarine or butter
* 1 c applesauce
* 1/2 c sugar
* 1 t cinnamon
* 1 t mixed spice
* 1 1/2 c wholemeal flour
* 1 t baking powder

Lightly oil the muffin tin and preheat the oven to 190C. This recipe makes 12 muffins.  Put the first six ingredients into a bowl and mix well.  Add the remaining ingredients and blend until just mixed.  Two-thirds fill the muffin tins and bake for 15 minutes.

Source: MmM Muffins, page 8

