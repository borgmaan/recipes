# Pancakes

* 8 oz milk
* 2 large eggs
* 2 oz butter, melted
* 1 t vanilla
* 8 oz flour
* 2 T sugar
* 2 t baking powder
* 1 t salt

Mix well wet with dry.


Comments: Best pancake recipe yet  
Source: Ratio, Michael Ruhlman

