# Peanut Butter & Jam Muffins

* 1 T  melted margarine
* 1/2 c peanut butter
* 1 egg
* 1 c sour milk
* 2 T  sugar
* 2 c flour
* 1 T baking powder
* Topping:
* 3 T crushed salted peanuts
* 4 T sugar
* 2 T butter
* strawberry jam for the middle

Lightly oil the muffin tin and preheat the oven to 200 C.  This recipe makes 12 muffins.
Put the first five ingredients into a bowl and mix well, then add the flour and baking powder and blend until just mixed.  Put a large spoonful of the batter into each muffin tin, then drop a small spoonful of jam in the centre of each and cover with remaining batter.  Sprinkle with the topping mixture and bake for 10-15 minutes.

Time: 30 minutes  

Comments: Excellent  
Source: MMM Muffins, page 51

