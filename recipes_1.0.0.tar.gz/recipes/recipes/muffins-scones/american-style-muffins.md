# American Style Muffins

* 2 c self raising flour
* 1/2 t salt
* 1/2 c castor sugar
* 1/2 c chocolate bits
* 100g butter, melted
* 1 c milk
* 1 egg
* 1 c mashed bananas
* Topping:
* 1T sugar
* 1/2 t cinnamon
* extra chocolate bits

Melt butter, remove from heat then beat in milk and egg.  Add mashed bananas. Mix in flour, salt, sugar and chocolate bits until just combined.  Grease 12 deep muffin tins and place in spoonfuls until about two thirds full.  Mix together sugar and cinnamon and sprinkle on top with a few extra chocolate bits.  Bake at 220C for 12-15 minutes, or until muffins spring back when pressed in the middle.  Remove from oven and stand 2-3 minutes.  Twist to loosen muffin then turn onto rack to cool.

Source: Newspaper

