# Raisin muffins, spicy

* 2 T butter or margarine, melted 
* 1 c sour milk 
* 2 eggs
* 1 1/4 c raisins
* 1/2 t allspice
* 1 t cinnamon
* 2 t baking powder
* 1/2 c sugar
* 1 1/2 c flour

Lightly oil the muffin tin and preheat oven to 200C.  This recipe makes 12 muffins.

Put the first six ingredients into a bowl and mix well.  Add the remaining ingredients and blend until just mixed.  Two-thirds fill the muffin tins and bake for 15-20 minutes.

Time: 20 minutes  

Comments: Variations

Use 2 tbs oil (not olive) instead of butter
Use 1 cup milk with 1 tbs lemon juice stirred in  instead of sour milk (may need an extra 1/4 cup flour to ensure mix is not too wet)

For Spicy Raisin & Oat muffins - add 1/2 cup rolled oats in place of 1/2 cup flour.

Mix is a wetter one than normal for muffins but if it looks too thin add some extra flour.  It does not have to be a stiff mix to work well.  
Source: MMM Muffins, page 57

