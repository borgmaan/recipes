# Berry Muffins

* 125g butter
* 125g sugar
* 2 large eggs
* 2 cups flour
* 1 heaped teaspoon baking powder
* ½ cup milk
* 1 cup fresh or frozen berries (½ cup frozen raspberries, ½ cup frozen blueberries) or blackberries
* Butter tins.  Preheat oven to 200C. Cream butter and sugar until pale and fluffy. Add eggs, beating well. Adding a little flour will stop mix from curdling.
* Sift flour and baking powder and add to creamed mix with milk. fold in berries- mix will be stiff.
* Spoon into prepared muffin tins and bake for 15mins or until tops are springy.
*  Let cool slightly before turning out of tins.  Sift icing sugar over top to serve.




