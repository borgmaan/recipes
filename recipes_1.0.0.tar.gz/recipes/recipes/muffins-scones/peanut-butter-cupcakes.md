# Peanut butter cupcakes

* 1 3/4 c flour
* 1/2 c brown sugar
* 1 1/2 t baking powder
* 1/2 t salt
* 3/4 c milk
* 1/3 c peanut butter
* 1 egg
* 2 T vegetable oil
* 1 t vanilla
* 1/2 c chocolate chips

Mix all ingredients until smooth.  Bake at 350 for 25-30 minutes.


Comments: Super easy and quick  
Source: Joy of cooking

