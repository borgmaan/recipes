# Hot cross buns

* 1 c milk
* 1/2 c hot water
* 2 T sugar
* 2 T dried yeast
* 2 c flour
* 100g butter
* 1/2 c sugar
* 1 egg
* 1 t salt
* 1 1/2 T mixed spice
* 1 t ground nutmeg 
* 2 t cocoa
* 1 t vanilla essence
* 1 c mixed dried fruit
* 2-3 c flour (warmed)

Mix milk, hot water and 2T sugar in metal bowl.  Sprinkle in yeast.  Leave to stand until bubbles appear.  Add  2 c flour and leave to stand.

Cream butter and sugar, add egg, salt spices, cocoa and vanilla.

Combine two mixtures and add mixed fruit.  Add warmed flour to make firm dough.  Knead cut into 20 pieces and leave to rise till doubled.

Press down, form into buns and cook 225 C for 10-12 minutes.  Glaze with 2 T sugar mixed in heated 1.5 t water.

Source: Cornell Cookbook

