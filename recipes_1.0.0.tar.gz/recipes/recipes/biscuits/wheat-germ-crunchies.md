# Wheat germ crunchies

* 125g butter
* 1 c brown sugar
* 1 egg
* 1/2 t vanilla
* 3/4 c flour
* 1 t baking powder
* 1/4 t salt
* 1 c wheat germ
* 1/2 c coconut
* 1 c cornflakes

Cream butter and sugar add egg and vanilla, beat well.  Sift in flour, baking powder and salt.  Add wheatgerm then coconut and cornflakes.  Roll into balls, put on greased trays and flatten with a fork.

Bake about 15 minutes at 180 C.

Time: 25 minutes  
Source: Cornell Cookbook

