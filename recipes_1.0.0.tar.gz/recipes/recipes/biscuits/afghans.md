# Afghans

* 7oz (200g) butter
* 3oz (75g) sugar
* 6oz (175g) flour
* 1oz (25g) cocoa
* 2oz (50g) cornflakes
* 1 t vanilla essence

Cream butter and sugar.  Sift in flour, and cocoa.  Mix in cornflakes and essence then place in round teaspoon lots on a greased oven tray.

Cook at 180 C for 15 minutes.


Chocolate icing:
1 tablespoon butter
1 Tablesppoon cocoa
Few drops of vanilla essence 
About a cup of icing sugar
Milk

About 1 cup of walnut halves

Melt butter and stir in cocoa & vanilla.  Add icing sugar and enough milk to make a thick paste.  Mix well adding more milk or icing sugar as necessary.  

When cookies are cold spread on top of each cookie generously and top with a walnut half.


Comments: A delicious special treat.  
Source: Edmonds Cookbook, NZ.

