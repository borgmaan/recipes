# Scroggins

* 6oz butter
* 2 T peanut butter
* 1/2 c sugar
* 2 eggs
* 1 t vanilla
* 1/4 t almond essence
* 1 c flour
* 1 t baking powder
* 1/2 chocolate chips
* 1 c raisins or sultanas
* 1/2 c chopped nuts
* 2 c rolled oats

Cream butter, sugar and peanut butter.  Add essence and eggs and mix well.  Stir in remaining ingredients.  Bake at 190C for 15 minutes


Comments: good for tramps etc.  
Source: Daniels Grandmother

