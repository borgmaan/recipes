# Hokey Pokey Biscuits

* 125g (4oz) butter
* 50g (2oz) sugar
* 1 D milk
* 1 D golden syrup
* 1 t baking soda
* 1 1/2 c flour

Cook the butter, sugar, golden syrup and the milk on the stove until just before it boils, mixing all the time. Sift the flour and the baking soda together and then mix the butter mixture with it.  Cool.  Roll into balls.  Press with a fork or flatten for a more crispy biscuit.  Bake on greased tray 15 to 20 minutes at 180C.

Time: 15 minutes  

Comments: Thanks to Sally N for updated method.  :- )  
Source: Edmonds Cook Book, page 39

