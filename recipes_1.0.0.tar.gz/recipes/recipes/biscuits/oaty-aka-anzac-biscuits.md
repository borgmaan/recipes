# Oaty (aka ANZAC) biscuits

* 100g butter
* 1/4 c golden syrup
* 1 t vanilla essence
* 1 c sugar
* 1 c rolled oats
* 1 c coconut
* 1 c flour
* 1/2 t baking soda
* 2 T warm water

Melt the butter in a fairly large saucepan.  Measure the golden syrup in a 1/4 c measure rinsed in very hot water, so the syrup tips out easily.

Stir the essence and golden syrup into the barely liquid butter, then remove from the heat.

Mix in dry ingredients then baking soda dissolved in warm water.

Roll into balls and flatten on a greased tray. 
Bake at 160C for 15 minutes

Variations: 

1. Replace vanilla with 2t garam masala, and use 1/2 c coconut and 1 1/2 oats

2.  Use all oats and no coconut for a healthier option.

3.  Reduce sugar to 3/4 cup and add 1 cup raisins or mix of dried blueberries, cranberries and sultanas for delicious fruity oat cookies.


Comments: If you like a a softer cookie take out of the oven sooner.  

