# Peanut Brownies

* 125g (4oz) butter
* 1 c sugar
* 1 egg
* 7 1/2 oz flour
* 1 t baking powder
* 2 desert spoons of cocoa
* pinch of salt
* 1 c peanuts

Cream butter and sugar, add egg, then peanuts, and dry ingredients sifted together.  Roll into balls, squash with a fork and bake 180 C (350 F) for 15 minutes.

This recipe is a great basic biscuit recipe - instead of (or as well as) peanuts, you can use other nuts (toasted or raw), raisins (or other dried fruit) or chocolate chips.  If you leave out the cocoa, you might want to add 1 t of vanilla (or other) essence.  

Time: 25 minutes  

Comments: Favourite classic  
Source: Edmonds Cook Book, page 45

