# Linzer schnitten

* 2 eggs
* 1 1/2 c sugar
* 175g butter
* 3 1/2 c flour
* 1 t baking powder
* 2 t cinnamon
* 1 t ground cloves
* 1/4 t salt
* 1 t finely grated lemon rind
* raspberry or red plum jam
* Glaze:
* 1 egg
* 1/2 c sugar

Beat eggs lightly and gradually beat in sugar.

Melt butter and add to egg mixture.

Sift together flour, baking powder, cinnamon, cloves and salt, and stir into egg mixture with lemon rind; mix well.  Turn out on to floured board and knead until smooth.  Chill one hour.

Roll out about 1.5 cm thick and cut into strips 3cm to 4cm wide by 25cm.  Mark groove down centre of each with piece of dowelling or wooden spoon handle.  Place on greased trays.   Fill centre of grooves with jam.

Bake at 180 C for 15 minutes until golden brown.

Glaze:

Beat egg and sugar together until very thick.  Brush over baked strips while hot.  Return to the oven for a few minutes until dry.  Cut into diagonal pieces and allow to cool.


Comments: A Christmas treat.  
Source: Cornell Cookbook

