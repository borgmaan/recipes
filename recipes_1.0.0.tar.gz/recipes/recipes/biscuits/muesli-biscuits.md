# Muesli biscuits

* 4oz butter
* 3/4 c flour
* 1/4 c sugar
* 1 t baking powder
* 1 egg
* vanilla
* 3/4 c coconut
* 1 c muesli

Cream butter and sugar.  Add vanilla and egg, then add sifted flour and baking powder.  Fold in coconut and muesli. Put on greased trays and flatten with a fork.  Bake at 180C for 15 minutes.

Time: 15 minutes  

Comments: very good  
Source: Rally cook book, page 114

