# Yo Yoes

* 175g (6oz) butter
* 50g (2oz) icing sugar
* Vanilla essence
* 175g (6oz) flour
* 50g (2oz) custard powder
* BUTTER FILLING
* 1 T butter
* 6 T icing sugar
* 1 T custard powder
* 1-2 T hot water

Cream butter, sugar and essence, add dry ingredients.  Roll into ball and flatten with fork.  Bake 20 minutes at 180C.  When cold put together with butter filling

BUTTER FILLING
Soften butter and add other ingredients.

Source: Edmonds Cook Book, page 52

