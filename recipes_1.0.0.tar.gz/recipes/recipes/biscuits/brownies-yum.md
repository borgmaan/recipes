# Brownies (yum)

* 1 1/2 c sugar
* 3 eggs
* 2 t vanilla
* 3/4 c flour
* 1/2 c cocoa
* 1 t baking powder
* 170g butter, melted

Beat eggs, sugar and vanilla. Sift in dry ingredients, and then mix in melted butter.

Bake at 350 for 25-35 minutes.

Serving suggestion from Jeff: pour into ice cream cones, and then serve with ice cream.

Source: http://www.cacaoweb.net/brownies3.html

