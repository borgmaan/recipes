# Gingernuts

* 100g butter
* 1 Tablespoon golden syrup
* 1 cup sugar
* 2 teaspoons ginger (depending on how gingery you like it)
* 1/2 cup  crystallised ginger chopped finely
* 1 egg
* 1 level teaspoon baking/bread soda
* 1 3/4 cups flour

Melt butter and golden syrup.  Add sugar, ginger and egg, beat with a fork until well mixed.  Add baking soda then unsifted flour.  Mix to make a dough.  Roll into balls and bake at 180 C for 10 minutes until golden brown.  No need to flatten them- they do it themselves.

Source: Newspaper

