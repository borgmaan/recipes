# Kisses

* 4oz butter
* 4oz sugar
* 2 eggs
* 4oz flour
* 4oz cornflour
* 1t baking powder

Cream butter and sugar.  Beat in eggs.  Sift in flour cornflour and baking powder.  Mix well.  Bake at 200C for 8-10 minutes.  When cold put together with raspberry jam.

Source: Notebook

