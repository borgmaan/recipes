# Cornflake Cookies

* 125g sugar
* 125g butter
* 1 egg
* 175g flour
* 1t baking powder
* 1/2 c raisins
* pinch salt
* 1 c cornflakes

Cream butter and sugar.  Add lightly beaten egg.  Sift in flour and baking powder.  Mix in raisins, salt and cornflakes.  Bake at 180C for 20 minutes.

Source: Notebook

