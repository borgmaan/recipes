# Chocolate Chip Cookies

* 125g butter
* 1/2 c brown sugar
* 1/2 c sugar
* 1/2t vanilla
* 1 egg
* 1 3/4 c self-raising flour
* 1/2t salt
* 1t cocoa
* 100g chocolate chips
* 60g walnut pieces

Cream butter, sugars and vanilla.  Add lightly beaten egg gradually, beating well after each addition.  Mix in sifted flour, salt and cocoa.  Add chocolate chips and chopped walnuts, mix well.  Shape teaspoonfuls into balls, press down lightly with a fork.  Bake at 200C for 10 minutes.

Source: Cornell Cookbook

