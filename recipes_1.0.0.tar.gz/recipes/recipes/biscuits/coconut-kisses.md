# Coconut kisses

* 3oz butter
* 2 T hot water
* 1/2 c sugar
* 1 c flour
* 3/4 c coconut
* 1 t baking powder

Melt butter with hot water and mix in dry ingredients.  Roll into balls and put on a greased tray.  Flatten a little with fork.  If mixture is too dry add some beaten egg.

Bake 15 minutes at 350 F.  Can be put together with jam or icing sugar.

Source: Cornell Cookbook

