# Kiwi biscuits

* 4oz butter
* 2oz sugar
* 2 T sweetened condensed milk
* 1 t vanilla essence
* 6oz flour
* 1 t baking powder
* 2oz chocolate chips

Cream butter and sugar, add condensed milk and essence. Mix in dry ingredients.

Bake at 180 C for 20 minutes.

Source: Cornell Cookbook

