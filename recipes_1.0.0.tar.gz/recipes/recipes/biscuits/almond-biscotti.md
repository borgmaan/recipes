# Almond Biscotti

* 1 cup almonds toasted and chopped coarsely
* 1 t baking powder
* 1/8 t salt
* 2 cups all purpose flour
* 3/4 cup white sugar
* 3 large eggs
* 1 t pure vanilla
* 1/2 t pure almond extract

Heat oven to 180C.

Beat eggs and extracts together in a small bowl.
Combine flour, sugar baking powder and salt.  Blend together.  Add egg mix and blend with mixer until a dough forms, adding almonds 1/2 way through.

Divide dough in half. Use cling film to make two logs about 10 ins (25cm) long by 2 ins (2.5cm) wide.
Put logs on parchment prepared baking sheet and bake for 35-40 mins or until firm to touch.

Cool on wire rack for 10 mins.
Transfer logs to cutting board and slice diagonally into 1/2 inch slices.

Bake again for 10 mins then turn them all over and bake another 10 mins until firm.

Cool on wire rack.. Keep in airtight container.

Makes about 40 pieces.  Dip in coffee or wine to eat.


Comments: Can vary by adding 1 tablespoon orange or lemon zest, or chopped glace cherries or dipping in chocolate.  
Source: JoyofBaking.com

