# Walnut biscuits

* 4oz butter
* 4oz brown sugar
* 2 t golden syrup
* Vanilla
* 5oz flour
* 1 t baking powder
* 1 c walnuts, chopped

Melt butter, brown sugar and golden syrup, add vanilla and dry ingredients.  Add walnuts.  Roll into balls and flatten.  Bake at 180C for 10-15 minutes.

Time: 15 minutes  

Comments: very good  
Source: Rally cook book, page 21

