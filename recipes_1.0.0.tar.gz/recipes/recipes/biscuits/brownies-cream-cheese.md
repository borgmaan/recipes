# Brownies (cream cheese)

* Brownie Layer:
* 1/2 cup (113 grams) unsalted butter, cut into pieces
* 4 ounces (115 grams) unsweetened chocolate, coarsely chopped
* 1 cups  granulated white sugar
* 1 teaspoon pure vanilla extract
* 2 large eggs
* 1/2 cup (65 grams) all purpose flour
* 1/4 teaspoon salt
* Cream Cheese Layer:
* 8 ounces (227 grams) cream cheese, at room temperature
* 1/4 cup granulated white sugar
* 1/2 teaspoon pure vanilla extract
* 1 large egg

Melt butter and chocolate in double-boiler. Whisk in other ingredients one at a time. Beat cream cheese until smooth, then beat in remaining ingredients.

Pour brownie batter in to lined tin, reserving 1/2 cup. Pour on cream cheese layer.  Add remaining batter in 16 dollops, then use skewer to make marbled effect.

Bake at 350 F for 30 minutes.  Cool on wire rack and then chill until firm.

Source: http://www.joyofbaking.com/barsandsquares/CreamCheeseBrownies.html

