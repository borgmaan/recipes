# "No-bake" sugar cookies

* 2 cup sugar
* 2 eggs
* 1 cup crisco oil
* 1 cup sour cream
* 2 tsp vanilla
* 4 cup flour
* 1 tsp soda
* 1.5 tsp salt

Beat eggs and sugar, add oil, sour cream and vanilla.  Mix in flour mixed with soda. Drop on cookie sheet and bake at 350 F for 10 minutes until pale gold.  


Comments: Jeff's favourite  
Source: Jeff's grandma

