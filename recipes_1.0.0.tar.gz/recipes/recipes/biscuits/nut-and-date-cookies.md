# Nut and date cookies

* 6oz butter
* 8oz brown sugar
* 2 eggs, well beaten
* 1 lb flour
* 1 t salt
* 1 t baking soda
* Vanilla
* 1 c dates, chopped
* 1 c peanuts

Cream butter and sugar, add eggs then dry ingredients and fruit.  Put in small balls on tray and flatten them.  Bake at 180C for 15-20 minutes.

Time: 20 minutes  
Source: Rally cook book, page 17

