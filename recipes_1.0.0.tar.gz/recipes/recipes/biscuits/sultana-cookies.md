# Sultana cookies

* 8oz butter
* 8oz brown sugar
* 5 T coconut
* 4 T honey
* 2 eggs
* 2 c flour
* 3 t baking powder
* 1 c wholemeal flour
* 8oz sultanas

Cream butter and sugar.  Add honey and coconut,  Add beaten eggs, dry ingredients and sultanas.  Put in teaspoon lots on greased trays and bake at 160C for 15 minutes, until golden.

Time: 105 minutes  

Comments: makes heaps  
Source: Rally cook book, page 115

