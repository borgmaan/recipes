# Peanut butter rice krispie treats

* 1/2 c water
* 1 c sugar
* 1/2 c brown sugar
* 1 1/2 c peanut butter
* 2 t vanilla
* 6 c cereal

Bring water and sugar to a boil. Mix in peanut butter and vanilla. Mix with cereal

Source: Adapted from http://www.marthastewart.com/343255/no-bake-peanut-butter-rice-krispies-cook

