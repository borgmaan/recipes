# Shortbread 

* 1/2 lb butter (I use the regular kind. Butter needs to sit at room temperature for a while to be soft enough- not oily though.) 
* 3/4 cup caster sugar
* 2 and 1/2 ounces cornflour
* 10 ounces of plain flour
* 1/4 teaspoon salt
*                                          ******
* ALISON'S CHRISTMAS VARIATION:
* Add 1 teaspoon almond essence to the butter and sugar mix. Add 1 cup of almonds (lightly toasted then cooled and chopped)  to the mix after the dry ingredients.  Decorate with cherries if desired. **

Cream butter and sugar and then add in remaining ingredients.   Mix well.
Turn out onto a long strip of greaseproof paper.  Using the paper to help, shape into a long rectangular log about 2 inches by 1 inch and cut into 40 pieces (about 1/4 inch deep).

Bake in a cool oven  (160 C)  for approximately 25 minutes until golden.  (They brown up more after they are removed so be careful.)  Cool on a wire rack.**                                     

As these cookies have no raising agents they spread only a small amount.  They should not be brown, but a pale creamy - gold colour, but crisp right through the centre when cool. 

Alternatively roll out between sheets of cling film and cut into small shapes with fancy cutters.  Check cooking time after 15 minutes.


Comments: (Traditional version made and sold for Clonakilty Market & Inchydoney Lodge & Spa by A Wickham in the early part of the 21st century.)  
Source: Original recipe from NZ Anchor or Fernleaf butter wrapper circa 1970's. 

