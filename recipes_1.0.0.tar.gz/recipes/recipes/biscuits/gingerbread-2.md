# Gingerbread 2

* 500g brown sugar
* 1 1/3 c golden syrup
* 2 t mixed spice
* 2 T ginger
* 375g butter
* 2 eggs, beaten
* 7 c flour, sifted
* 1 c flour, self raising

Heat first five ingredients until sugar dissolves.  Boil then remove from heat and cool.  Beat in the eggs then gradually work in the flour and knead.  Chill for 1 hour.

Bake at 180 C for 15 minutes ??  (Check and be careful)

Source: Paula

