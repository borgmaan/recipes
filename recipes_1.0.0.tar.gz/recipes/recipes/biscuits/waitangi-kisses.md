# Waitangi kisses

* 4oz butter
* 4oz sugar
* 8oz flour
* 2 eggs
* 2 c walnuts
* 2 t baking powder
* 2 heaped desert spoons cocoa
* 2 c dates

Cream butter and sugar.  Add egg and cocoa then fold in flour and baking powder.  Lastly add dates and nuts.  Put on cold tray in small teaspoonfuls and cook at 180C for 12-15 minutes.
When cold ice two together.

Alternatively make large teaspoonfuls and ice the tops.

Source: Cornell Cookbook

