# Vanishing oatmeal raisin cookies

* 4 oz butter
* 1/2 cup brown sugar
* 1/4 cup sugar
* 1 egg
* 1/2 t vanilla
* 3/4 c flour
* 1/2 t baking soda
* 1/4 t salt
* 1 1/2 cup rolled oats
* 1/2 cup raisin

Cream butter and sugars.  Add eggs and vanilla, then dry ingredients.  Add 2T extra flour to be more biscuit like.  Bake for 10-12 minutes at 350F


Comments: Delicious Oat & Date Bar Variation
Use 1/2 to 3/4 cup brown sugar, omit white sugar, increase vanilla essence to 1 t and 1 cup chopped dates instead of 1/2 cup raisins.  Place in a  greased  bar tray.  Cook for 18 minutes and cut into bars while warm.  
Source: Quaker oats lid

