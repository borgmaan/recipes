# Almond creams

* 6oz (175g) butter
* 3/4 c icing sugar
* 1/2 t vanilla
* 1/2 t almond essence
* 1 1/2 c flour
* 1/2 c cornflour or custard powder
* 1/4 c flaked almonds (optional)
* Filling:
* 3 T butter
* 1/2 t almond essence
* 3/4 c icing sugar
* few drops of water if needed

Soften but do not melt the butter.  Cream it with the icing sugar and essences, then stir in the sifted dry ingredients and chopped almonds, or put everything in a food processor without sifting the dry ingredients.  In a low powered food processor the last part of the dry ingredients may have to be added by hand mixing.

Roll out mixture to form a cylinder 2-3cm across.  Roll this in greaseproof paper and refrigerate it or chill it until firm in the freezer.

Make the icing by mixing the softened butter with the essence and sugar, adding a little water if needed.

Cut the chilled biscuit dough into 40-60 thin slices, depending on the thickness of the biscuits desired.  Bake at 180 C for about 12 minutes, until the edges start to brown slightly.

Cool on a wire rack.  Sandwich together with filling when biscuits are almost but no quite, cold.

Source: Cornell Cookbook

