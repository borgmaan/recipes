# Vanilla (or any other) Crisp Biscuits

* 125g (4oz) butter
* 175g (6oz) sugar
* 1 teaspoon vanilla essence
* 1 egg
* 225g (8oz) flour
* 1 t baking powder
* 50g (2oz) sultanas or raisins
* Variations
* - Add 1/2 cup chopped walnuts or pecans.
* - Peanut Brownies Use 7oz flour and 1 oz cocoa instead of all flour and add 1 cup of peanuts. 
* - Almond.  Leave out fruit and use almond essence instead of vanilla.  Press an almond on top of each ball of mix.

Cream butter, sugar and essence, add egg, then mix in dry ingredients.  Roll into balls and press with fork.  Bake 15 - 20 minutes at 160C until golden brown.  Cool on a rack.  Keep in airtight container to preserve crispness.  

Makes about 32

Time: 15 minutes  

Comments: USA - Use a heaped teaspoon baking powder.    


Variation by AW
Substitute 8oz flour with 1 oz cocoa, 3 oz rolled oats and 4oz flour 
Add chopped pecans or walnuts too if you like.  

