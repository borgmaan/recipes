# Speculaas

* 8oz butter
* 8oz brown sugar
* 1 egg
* 1 1/2 t almond essence
* 12oz flour
* 1 1/2 t baking powder
* 1 t cinnamon
* 2 t mixed spice
* 1/4 t baking soda

Cream butter and sugar, add beaten eggs and almond essence.  Then add sifted dry ingredients.  Shape in log and place in fridge.  Slice when cool.  Bake at 180C for  15 minutes.

Can also roll out dough and cut into shapes for Christmas.

Time: 15 minutes  

Comments: A Dutch thin crisp spicy biscuit.  
Source: Rally cook book, page 20

