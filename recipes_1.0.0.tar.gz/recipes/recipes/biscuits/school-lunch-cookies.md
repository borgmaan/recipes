# School Lunch Cookies

* 125g butter
* 2 T golden syrup
* 1 c sugar
* 1 t baking soda
* 1/3 c boiling water
* 1 c flour
* 1 c rolled oats
* 1/2 c dried milk
* 1/2 c coconut
* 1/2 c wheatgerm

Melt butter, sugar and golden syrup.  Dissolve baking soda in boiling water and add.  Add flour, rolled oats, dried milk, coconut and wheatgerm.  Place teaspoonfuls on greased tray.  Bake at 170C for 15-20 minutes.

Source: Cornell Cookbook

