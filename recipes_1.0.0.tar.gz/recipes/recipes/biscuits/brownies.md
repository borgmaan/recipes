# Brownies

* 1 1/2 cups sugar
* 90gm butter or margarine 
* 3 eggs
* 1 c flour
* 1/2 c cocoa
* 1t baking powder
* 1/2t vanilla
* 3/4 c chopped nuts

Cream sugar and butter.  Add beaten eggs and mix well.  Sift in remaining dry ingredients then mix in vanilla and chopped nuts.  Cook at 180C for 15 minutes.

Source: Cornell Cookbook

