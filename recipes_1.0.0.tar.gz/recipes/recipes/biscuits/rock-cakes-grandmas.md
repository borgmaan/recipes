# Rock Cakes, Grandma's

* 4oz butter
* 6oz sugar
* 2 eggs
* 1 T milk
* 10oz flour
* 2 t baking powder
* 1 c sultanas
* vanilla essence
* salt

Cream butter and sugar.  Beat eggs and rinse bowl with milk.  Sift in flour and baking powder and mix well.  Stir in sultanas, vanilla essence and salt.  Bake at 190C for 11 minutes.

Source: Notebook

