# Bo-peep biscuits

* 4oz butter
* 4oz sugar
* 1 egg
* 6oz flour
* 2oz custard powder
* 2oz cornflour
* 1 t baking powder

Cream butter and sugar, add egg then dry ingredients.  Place small teaspoons on greased tray.  Press a hollow in the top and fill with jam.  Bake at 180C for 20 minutes.

Time: 20 minutes  
Source: Rally cook book, page 14

