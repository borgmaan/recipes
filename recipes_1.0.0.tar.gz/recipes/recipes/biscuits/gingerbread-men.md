# Gingerbread men

* 6oz butter
* 1 c sugar
* 1 c golden syrup
* 3 c flour
* 2 heaped t ginger
* 1t baking soda
* 1/2t salt

Melt butter, sugar and syrup. 

Sift in dry ingredients.  

Mix well. 

Roll out thinly on a silicone sheet and cut into shapes. (The silicone does not stick to the mix, therefore you don't need to use flour on the counter top, which gives a better tasting end product. It is also easier to free them from the sheet by lifting it with one hand from underneath.)

Bake on greased trasy at 180C for 10 minutes, or until golden brown.

Makes loads - you can halve the recipe if wished.


Comments: You can cut into varied Christmas shapes and make a hole in the top by using a straw to use as decorations.  Leave plain or ice.  
Source: Notebook

