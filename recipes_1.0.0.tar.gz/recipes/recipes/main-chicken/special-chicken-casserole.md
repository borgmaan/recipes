# Special chicken casserole

* 1 chicken
* 1 pkt mushroom soup
* 2 T sherry
* 4 T flour
* 1 onion
* 4 c chicken stock
* 1/2 t mixed herbs
* 1 c cream
* 1/4 lb ham
* 1 c water
* 1 green pepper
* 1/4 lb mushrooms
* paprika

Boil chicken with onion and mixed herbs inside chicken.  Reserve stock. Take chicken off bones. In frypan lightly fry green peppers (chopped) and mushrooms.  Make up soup with 1 cup water.  Add to peppers and mushrooms.  Add flour to stock and blend in cream.  Add to frypan.  Add chopped ham and chicken pieces and sherry.  Put into casserole and heat in oven.  Sprinkle paprika over to serve.

Source: Onslow College Cookbook, page 75

