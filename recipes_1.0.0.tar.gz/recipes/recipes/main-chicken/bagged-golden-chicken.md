# Bagged golden chicken

* 450g can pineapple pieces
* Water
* 1 pkt chicken soup
* 1 T soy sauce
* 8 chicken pieces

Drain juice from pineapple and make up with up 1 c of water.  Pour into unperforated roasting bag with chicken soup and soy sauce and mix in bag.  Add chicken and pineapple and tie bag loosely, leaving a finger sized hole.  Lie in shallow baking dish so chicken is in one layer.  

Bake at 180C for 1 hour, turning bag after 30 minutes.  Serve on rice or noodles and sprinkle with chopped parsley.


