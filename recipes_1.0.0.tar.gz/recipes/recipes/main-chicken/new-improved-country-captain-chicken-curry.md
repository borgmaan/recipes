# New Improved COUNTRY CAPTAIN CHICKEN CURRY

* 2 chicken breasts, skinned and cut into cubes
* 2 heaped tablespoons butter
* 1 large onion finely diced- optional
* 1 large minced clove of garlic 
* 1 1/2 t curry powder
* 1/2 t thyme - or less if fresh
* 450 gram fresh tomatoes chopped and made up to 2 cups with water
* 2 T currants or golden raisins
* 1 1/2 t brown sugar
* 1 cup or more diced peeled butternut squash
* 1 cup or more broccoli florets
* Rice

 Roll chicken pieces in seasoned flour.  Melt butter in large flying pan on medium heat. Brown with butter, onion, garlic and curry powder until cooked.

Add thyme, tomatoes, butternut, currants and brown sugar. Simmer for 20 minutes.  Add broccoli and simmer for a further 10 minutes. Serve over cooked plain jasmine or basmati rice.


Comments: Modified by AW. 
A great mild curry two pan dinner for two. Serves four with accompanying dishes like naan breads and Indian condiments like chutneys, cucumbers in yogurt, sliced bananas, nuts  etc.

Double or triple recipe for more servings.  
Source: Original recipe Joy of Cooking

