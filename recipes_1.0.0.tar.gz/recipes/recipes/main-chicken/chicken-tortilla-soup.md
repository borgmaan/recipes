# Chicken tortilla soup

* 2 whole Boneless, Skinless Chicken Breasts
* 1 T Olive Oil
* 1-1/2 t Cumin
* 1 t Chili Powder
* 1/2 t Garlic Powder
* 1/2 t Salt
* 1 T Olive Oil
* 1 cup Diced Onion
* 1/4 cup Diced Green Bell Pepper
* 1/4 cup Red Bell Pepper
* 3 cloves Garlic, Minced
* 1 can tomatoes (and green chilli)
* 32 oz chicken stock
* 3 T Tomato Paste
* 4 cups hot water
* 2 cans (15 Oz. Can) black beans, drained
* 3 T cornmeal
* 5 corn tortillas, cut in 2" strips

Preheat oven to 375 degrees. Mix cumin, chili pepper, garlic powder, and salt. Drizzle 1 tablespoon olive oil on chicken breasts, then sprinkle a small amount of spice mix on both sides. Set aside the rest of the spice mix.

Place chicken breasts on a baking sheet. Bake for 20 to 25 minutes, or until chicken is done. Use two forks to shred chicken. Set aside.

Heat 1 tablespoon olive oil in a pot over medium high heat. Add onions, red pepper, green pepper, and minced garlic. Stir and begin cooking, then add the rest of the spice mix. Stir to combine, then add shredded chicken and stir.

Pour in tomatoes, chicken stock, tomato paste, water, and black beans. Bring to a boil, then reduce heat to a simmer. Simmer for 45 minutes, uncovered.
Mix cornmeal with a small amount of water. Pour into the soup, then simmer for an additional 30 minutes. Check seasonings, adding more if needed---add more chili powder if it needs more spice, and be sure not to undersalt. Turn off heat and allow to sit for 15 to 20 minutes before serving. Five minutes before serving, gently stir in tortilla strips.

Ladle into bowls, then top with sour cream, diced red onion, diced avocado, pico de gallo, and grated cheese, if you have it! (The garnishes really make the soup delicious.)

Source: http://thepioneerwoman.com/cooking/2011/01/chicken-tortilla-soup/

