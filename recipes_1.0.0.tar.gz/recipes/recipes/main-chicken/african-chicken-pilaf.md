# African chicken pilaf

* 4 T olive oil
* 1 large red onion, peeled & sliced
* 200g long grain rice
* 2 t ground coriander
* 1 t turmeric
* 300ml tomato pieces
* 450ml vegetable or chicken stock
* 2 large chicken breasts, cut into bite-sized pieces
* 1 red pepper, peeled & cut into chunks
* 1 yellow pepper, peeled & cut into chunks
* 1 kumara or sweet potato cut into chunks
* 1 T raisins
* 1 T chopped cashews
* 2 T chopped fresh coriander

Heat half olive oil in large saute pan, add the onion and saute until softened, stir in the rice until coated with oil, then add the corander and turmeric, cooking for 2-3 minutes.

Stir in tomato pieces and about 2/3 of the stock and bring to a simmer.   Cook gently for 20 minutes stirring occasionally to stop rice from sticking, adding more stock as necessary.

Meanwhile, heat remaining oil in a saute pan and stir-fry the chicken over a brisk heat for 2-3 minutes until browned.  Remove from pan and keep warm.

Add the peppers, kumara and raisins to the pan and saute over a medium heat until softened, add any remaining stock and simmer until the kumara is tender.

Just before rice is cooked, stir in the chicken and vegetables.

Serve the pilaf with cashews and choppped coriander scattered over.


