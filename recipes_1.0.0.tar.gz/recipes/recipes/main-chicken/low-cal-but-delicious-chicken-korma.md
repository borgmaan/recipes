# Low cal but delicious Chicken Korma

* 450g skinless, boneless, chicken breast cubed
* 2 medium onions chopped
* 1 medium apple chopped
* 4 teaspoons mild curry powder
* 300 mls chicken or vegetable stock
* 25g sultanas or raisins
* 1 tablespoon tomato puree
* 125g basmati rice
* 1 medium banana
* 8 tablespoons plain low fat yogurt
* pinch salt
* freash ground black pepper
* 4 sprigs fresh coriander

Lightly spray fry pan with low fat cookiing spray. Saute onions and apple for 4 minutes.  Add curry powder and cook a few moments longer.

Add chicken and stir fry for 3-4 minutes until sealed.

Add stock, sultanas, and tomato puree.  Bring to boil.  Reduce heat, cover and simmer gently for 40 minutes.

Cook rice to be ready about ten minutes before meat dish is cooked.

Just before serving, add sliced banana, chopped coriander and yogurt to the curry.  Cook for 2 minutes and serve with hot cooked rice.  Garnish with coriander.


Comments: Serves 4 
5 points per serve  
Source: Internet

