# Chicken with plums and ginger

* 6 chicken breasts
* spray canola oil
* 1 onion, chopped
* 2 T lemon juice
* 1 T soy sauce
* 1 inch piece stem ginger, peeled and sliced thinly
* 1 T tomato puree
* 1 T brown sugar
* 1 tsp salt
*  ½ cup plum jam
* 1 tsp dry mustard powder
* dash of worchestershire sauce
* 4 garlic cloves, peeled and sliced thinly
* 6 large fresh plums (stoned and quartered)
* Season chicken with salt and pepper
* Brown slightly in oil sprayed frying pan., remove from pan and place in a lidless oven proof dish.
* Saute onion in pan until soft. Add all remaining ingredients except fresh plums, simmer for 10 minutes.
* Bake in oven for 45 minutes at 350 degrees F.
* Serve with rice, salad or roast vegetables.




Comments: Sauce can be made the day before and refrigerated until needed.  

