# Chicken casserole

* chicken pieces for four people
* seasoned flour
* 1 onion cut in rings
* 11oz tin pineapple
* 2 bay leaves
* 1 pkt Maggi cream of chicken dried soup mix
* 1 c water
* 1 T soy sauce 
* 1 c white wine
* red or green pepper
* salt 
* pepper
* tomatoes if liked

Coat chicken pieces with seasoned flour.  Place in casserole, add onion, pineapple and 2 bay leaves.  Dissolve Maggi soup in 1 c of water, soy sauce and white wine.  Add green or red pepper.  More water may be added if necessary.  Salt and pepper to taste.

Cook at 250 F (120C) for 2 and 1/2 hours.  Add tomatoes if liked.  Stir once during cooking.

Microwave on high for 25 minutes.

Source: Cornell Cookbook

