# Guggy Cake

* 4oz butter
* 2t mixed spice
* 1 c sugar
* 1 c sultanas
* 1 c currants
* 1 c water
* 2 c flour
* 2t baking powder

Warm all ingredients except for flour and baking powder.  Cool and add flour and baking powder.  Bake at 180C for 45 minutes.


Comments: delicious!  
Source: Notebook

