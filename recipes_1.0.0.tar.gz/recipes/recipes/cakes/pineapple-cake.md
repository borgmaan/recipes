# Pineapple cake

* 5oz butter
* 5oz sugar
* 2 beaten eggs
* 5.5oz flour
* 2oz custard powder
* 1/2 t baking powder
* 1 c sultanas
* 1/2 small tin crushed pineapple

Cream butter and sugar.  Add beaten egg.  Mix in dry ingredients and fruit.

Bake 180C for 45 minutes in 7 inch square tin.

Source: Cornell Cookbook

