# Apricot cake

* 1 c dried apricots
* 1 c boiling water
* 6oz butter
* 6oz sugar
* 3 eggs
* 8oz flour
* 3/4t baking soda

Pour boiling water over apricots and leave to stand.  Cream butter and sugar well then add eggs and mix.  Add drained apricots reserving 1/3 c of liquid.  Add baking soda to this liquid.  Mix in flour well.  Then add baking soda and water.  

Bake in a 8" tin at 180C for 45-55 minutes.


