# Coffee and Walnut Cake

* 4oz butter
* 6oz brown sugar
* 3 eggs, separated
* 7oz self-raising flour
* 1/2 c milk
* 1t vanilla
* 4oz chopped walnuts
* 300ml strong black coffee
* 1/4 c brandy
* castor sugar

Cream butter and sugar.  Beat in egg yolks.  Fold in flour alternately with milk and vanilla.  Whip egg whites until stiff.  Fold alternately with walnuts into batter.  Pour into a buttered and floured 23cm cake tin.  Bake at 180C for about 45 minutes.  Mix coffee with brandy and enough sugar to make a sweet syrup.  Transfer cooled cake to a platter with a raised edge and poured syrup on.  Repour on the syrup that is not absorbed.  Keep on doing this until all liquid is absorbed.

Source: Notebook

