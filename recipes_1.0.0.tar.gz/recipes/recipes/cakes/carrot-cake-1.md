# Carrot cake 1

* 1 c wholemeal flour
* 1 c flour
* 2 t baking soda
* 2 c raw sugar
* 1 c cooking oil
* 4 eggs, beaten
* 2 c finely grated carrot
* 2 t cinnamon

Sift dry ingredients, add oil, stir in beaten eggs and carrot.  Mix thoroughly.  Pour into a 9 inch greased tin.  Bake at 190C for 1 hour.


