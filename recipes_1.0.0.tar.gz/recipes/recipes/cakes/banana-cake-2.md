# Banana Cake 2

* 125g (4oz.) butter
* 175g (6oz) sugar
* 2 eggs
* 2 ripe bananas, mashed
* 1 t baking soda
* 2 T boiling water
* 1 t baking powder
* 225g (8oz) flour

Lightly grease with butter a 210 mm cake pan. Cream butter and sugar, add eggs, mashed bananas, then baking soda dissolved in water.  (If mixture starts to curdle add a tablespoon or two of flour from the weighed quantity and stir unitl smooth.) Lastly sift in flour and baking powder.  Bake at 180C for 40 minutes. Ice with chocolate or lemon flavoured icing.

Time: 35 minutes  

Comments: excellent  
Source: Edmonds Cookbook 

