# Uncooked coffee gateau

* 1 lb sponge cake
* 6oz butter
* 3/4 c castor sugar
* 3 egg yolks
* 3/4 c black coffee
* 1 1/2 T coffee mixed with 1 1/2 T whisky or brandy, rum or sherry
* Whipped cream

Slice sponge into three horizontally, using top slices, line the side of a 7 inch loose bottomed cake tin.  

Place layer of sponge cake on the bottom of the tin, this time using the bottom slices.

Warm the butter and sugar, so that the butter is very soft but not oily.  Add the egg  yolks.  

Beat mixture, add when creamy warm the coffee until luke warm.  Add this a little at a time, beat continuously until all the coffee is absorbed.  If used sprinkle about a quarter of the coffee and alcohol on the sponge on the tin bottom, before spreading this with a third of the butter mixture, cover with another layer of sponge cake, again sprinkled with coffee and alcohol, repeat these last two layers twice more.  

Place a large flat plate upside down on top of the tin.  Carefully turn upside down, press down the tin bottom and put some weights on it.

Leave as is either in a cool place or the refrigerator, until the next day, when the tin may be removed.

Just before serving dress with cream.


