# Moist special occasion chocolate cake - Chelsea bake-off winner 

* 2 cups caster sugar
* 3 cups self- raising flour
* 2 teaspoons baking soda
* 1/2 cup cocoa
* 3 eggs separated
* 2 cups milk
* 2 tablespoons malt vinegar
* 2 tablespoons golden syrup
* 2 teaspoons vanilla
* 1 1/2 cups Canola oli
* 1 egg

Combine all dry ingredients.  In a large bowl beat the 3 egg whites until stiff.  In a separate bowl, combine milk and vinegar, then add the rest of the wet ingredients together, including the whole egg and 3 egg yolks, and beat.  Mix wet and dry ingredients together, then fold in the beaten egg whites.  Pour into two well greased or baking paper- lined tins about 20- 23 cm in diameter.  Bake for 25-30 minutes in a moderate oven (180C for NZ non-fan).  Cool on a wire rack.  To serve, pile whipped cream on one cake, place the other cake on top and frost top with chocolate icing.  

Chocolate Icing  
25g butter 
3  tablespoons cocoa
few drops vanilla essence 
2 cups  of icing sugar
milk to mix

Melt butter, stir in cocoa & essence.  Add icing sugar and stir in enough milk to make spreading consistency.  Beat well til smooth.


