# Sultana cake

* 1 lb sultanas
* 8oz butter
* 3 eggs
* 12oz sugar
* 12oz flour
* 1 t baking powder
* 1 t lemon essence

Place sultanas in a saucepan, cover with water and boil for 5 minutes.  Pour water off and put butter into hot fruit.  Leave to melt.  Beat eggs and sugar.  Stir into fruit and butter.  Add sifted flour and baking powder and essence.  Pour into tin and bake at 180C for 1 hr 10 minutes.

Time: 90 minutes  
Source: Rally cook book, page 54

