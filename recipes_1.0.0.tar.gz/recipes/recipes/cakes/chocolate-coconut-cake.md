# Chocolate coconut cake

* 125g butter
* 1 c brown sugar
* 1 egg
* 1 c self-raising flour
* 1 T cocoa
* 1 c coconut
* 1 T icing sugar
* 1/2 c milk

Cream butter and sugar until light and fluffy.  Add egg, beat well.  Stir  in sifted flour and cocoa, beat lightly until smooth.  Spread half mixture evenly into greased 20cm (8in) square tin.

Combine coconut, icing sugar and milk, mix until smooth, spread evenly over cake mixture.  Spoon remaining cake mixture evenly  on top of the filling.  

Bake in moderate oven 30 minutes or until cooked when tested.  If desired, top this delicious cake with chocolate icing.

Source: Cornell Cookbook

