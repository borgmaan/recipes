# Christmas Cake, Pineapple

* 1 - 1.5 kg dried fruit
* 450g can pineapple, crushed
* 3 c flour
* 1 t cinnamon
* 1 t mixed spice
* 225g butter
* 1 c sugar
* 1/2 t vanilla, almond, lemon essence
* 6 eggs, large
* up to 1 c extra flour

A day before mixing cake, warm fruit cake mix until it feels hot, then put it in a large unperforated oven bag or plastic bag with the undrained pineapple.  Turn fruit occasionally, in a warm place, until juice is absorbed.

Mix the spices with three c of flour and put aside.  Cream butter, sugar and essences until light and smooth,  Beat in eggs, one at a time adding about 2 of the flour mix with each egg.

Toss together prepared fruit and remaining spiced flour in a large bowl or a roasting pan.  Stir in the creamed mixture.  The mixture should be just soft enough to drop from a spoon.  If it seems too soft add extra flour.

Press mixture into a 23cm  lined tin, levelling the top.  Decorate with blanched almonds and cherries if desired. Bake at 150C for 1 1/2 hours, then at 130C for about 2 hours longer.

Time: 270 minutes  
Source: Newspaper

