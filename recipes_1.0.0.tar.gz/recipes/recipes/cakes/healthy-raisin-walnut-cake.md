# Healthy Raisin & Walnut Cake

* 1 cup raisins
* 1 cup water
* 1 teaspoon baking soda
* 1 1/2 cups flour sifted
* 1/2 cup rolled oats
* 2 eggs
* 1/2 cup canola or safflower oil
* 1 t lemon essence
* 1/2 t vanilla essence
* 1/2 t almond essence
* 3/4 cup sugar
* 1/2 cup chopped walnuts

Boil water and pour over raisins and soda.  Leave until cold.  Beat together eggs and sugar, add oil & essences.  Add dry ingredients and fruit mix alternately, beat well then stir in nuts.

Pur into paper lined (or very well greased) 9 or 10 inch square tin, or two loaf pans. Bake in preheated moderate (approx 180 C) oven till done.  One square tin 45 - 60 mins, loaf tins  40 minutes (approximate times only).  Take out of oven when it smells cooked.

Variation for Xmas
Instead of raisins & walnuts 
2 cups mixed fruit
1 teaspoon each of almond, lemon & vanilla essences
1/2 cup almonds
1/2 cup cherries
Bake in two loaf tins about 40 mins


Comments: You can use a mix of chopped prunes and dried apricots instead of raisins.  Or, chopped dates or indeed any mix of dried fruit you like.  Similarly you can use whatever nuts or essences you fancy.  Enjoy experimenting!  
Source: Modified recipe from L Churn

