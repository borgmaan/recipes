# Sour Cream Lemon Cake

* 185g softened butter
* 1 1/2 c sugar
* 4 lightly beaten large eggs
* 3 t lemon zest
* 1 1/2 c flour
* 1 1/2 t baking powder
* 3/4 c light sour cream or 50:50 sour cream and natural unsweetened yogurt
* Glaze
* Juice of 1 lemon and 3/4 cup sugar heated until sugar is melted

Cream butter and sugar until light, add eggs and lemon rind.  Blend well.

Fold in sifted flour and baking powder alternately with sour cream.  Mix gently unitl smooth and place in a well greased 21cm round spring form pan.  Bake at 160C until done (about 40 minutes).

Leave cake in tin for a few minutes and then pour over glaze.  Leave until cool and then remove from tin.  Serve with yogurt, or whipped cream and a dash of lemon butter.


Comments: Made for Charlottes birthday 2005  

