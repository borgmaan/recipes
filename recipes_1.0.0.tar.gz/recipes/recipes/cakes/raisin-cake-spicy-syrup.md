# Raisin Cake, Spicy Syrup

* 2oz (50g) butter
* 8oz (225g) castor sugar
* 2 eggs
* 1 t baking soda
* 125 ml water, cold
* 1lb 4oz (575g) flour
* 4oz (125g) golden syrup
* 8oz (225g) raisins
* Pinch of cinnamon, ground cloves & nutmeg

Cream butter and sugar.  Add eggs one at a time and mix well.  Dissolve baking soda in cold water and add with remaining ingredients.  Beat thoroughly for a few minutes.  Turn into well greased cake tin and bake at 180C for 55 minutes.

Time: 85 minutes  
Source: The Victorian Kitchen Book of Cakes and Cookies, page 27

