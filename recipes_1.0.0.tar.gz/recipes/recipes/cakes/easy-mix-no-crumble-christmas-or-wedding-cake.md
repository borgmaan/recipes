# Easy Mix, no crumble,  Christmas or Wedding Cake

* 1 tin sweetened condensed milk
* 1/4 lb butter
* 2 T golden syrup
* 4 eggs
* 1 t vanilla essence
* 1 t lemon essence
* 1 t almond essence
* 2 c flour
* pinch salt
* 1/2 t mixed spice
* 1/2 t nutmeg
* 1/2 t curry powder
* 3 lb mixed fruit
* 1 t baking soda
* 1/4 c milk
* 16oz tin crushed pineapple (drained)
* 2 tablespoons sherry

Melt over hot water, 1 tin sweetened condensed milk, 1/4 lb. butter and 2 tablespoons golden syrup.  

Add 4 eggs beating in one at a time.  Add 1 teaspoon each of vanilla, lemon, and almond essence.   

Measure out the flour and stir about 3/4 cup of it through the mixed dried fruit - set aside.

Sift the remaining flour, a pinch of salt, 1/2 teaspoon each of mixed spice, nutmeg, and curry powder, into the butter & egg mixture.  Add 3 lb. mixed fruit floured and 1 t baking soda dissolved in 1/4 c milk.  Lastly add 1 16 oz tin of pineapple (drained and crushed).

Bake in 9" square lined tin at 250 F (120ºC) for 4-5 hours.  Pour 2 tablespoons sherry over when cooked.

If made in a round 9" tin it will be a deeper cake and may take six or more hours to cook.

If you wish to decorate the top with cherries and nuts, flour the bottom of each one before placing it to prevent it sinking out of sight during baking.

Source: Jo from NHSC

