# Pineapple christmas cake

* 1.5kg mixed fruit (700g sultana, 500g raisins, 250g currents, 50g mixed peel)
* 450g can crushed pinapple
* 3 cups flour
* 1 t cinnamon, mixed spice
* 1/2 t ground cloves
* 225g butter
* 1 c sugar
* 1/2t vanilla, almond, lemon essences
* 6 large eggs
* up to an extra c of flour
* 50g glace cherries and blanched almonds for decoration

2-3 days before making cake, put mixed fruit in bag with pineapple + juice.  Leave in warm place turning occasionally until all juice absorbed.  23cm cake tin (or 2 18cm).  Mix spices with flour and set aside.  Cream butter, sugar and essences until light and smooth.  Beat in eggs one at a time, adding about 2 T of spiced flour with each egg.  Toss together fruit and remaining flour.  Stir in creamed mixture.  Should be just soft enough to drop from hand - add more flour if not.  Press mixture into lined tin, leveling top.  Bake at 150C for one and a half hours, then 130 for two more hours. Feed with sherry (1/4 c). 


