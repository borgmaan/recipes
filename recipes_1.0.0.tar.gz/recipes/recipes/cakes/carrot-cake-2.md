# Carrot cake 2

* 125g butter
* 2 medium carrots grated
* 1 c sugar
* 1 egg
* 1 c raisins
* 1 1/2 c flour
* 1 t cinnamon
* 1/2 t nutmeg
* 1/2 t allspice
* 1 t salt
* 1 t baking soda
* Frosting:
* 1oz butter
* 2oz cream cheese
* 1 t lemon rind
* 1 1/2 c icing sugar

Melt butter and add grated carrots.  Add in egg and sugar and stir with a fork.  Stir in raisins.  Mix in flour, spice and baking soda. Bake in 9 inch square tin at 180 C for 40-45 minutes.  Cover with cream cheese frosting.

To make frosting:  cream butter and cream cheese together.  Add lemon rind and icing sugar.

Source: Cornell Cookbook

