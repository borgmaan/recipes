# Delicious Fruit Cake

* 1 lb mixed fruit 
* 12 oz sugar
* 12 oz flour
* 1 t vanilla
* 1/2 t almond essence
* 1/2 lb butter
* 3 eggs
* 1 t baking powder
* 1 t lemon essence
* pinch salt

Boil fruit covered with water for 5 minutes.  Strain and while hot cut up butter and add to fruit.  Add essences, sugar and salt.  Beat eggs and stir in.  Add sifted flour with baking powder and place in a paper-lined 10 inch square cake tin. 

Bake in a moderate oven for 1 1/2 -2 hours.

Time: 120 minutes  
Source: Onslow College Cookbook, page 133

