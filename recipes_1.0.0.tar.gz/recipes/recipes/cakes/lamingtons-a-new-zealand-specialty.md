# LAMINGTONS - a New Zealand specialty?

* 2 T butter
* 2 T cocoa
* 6 T water, boiling
* 3/4 lb icing sugar
* vanilla essence
* coconut
* A ready made rectangular sponge cake

Melt butter and add cocoa and water.  Add icing sugar and essence and mix until smooth.  

Cut sponge into squares, coat each with mixture by dipping it in the mix using two forks.  Drain off excess and then roll in coconut. 

Fiddly but worth it.


Comments: In US a lot of coconut is sold in a sweetened form. You need plain dessicated (dried) coconut for this recipe. The bag should list the contents as 100% coconut - nothing else.  

