# Apple Cake, with crunchy topping

* 2 2/3 cups wholemeal self raising flour
* 1 t cinnamon
* 1/2 t nutmeg
* 1 C caster sugar
* 185g butter, melted
* 1/2 C water
* 3 eggs, beaten
* 3 medium apples, peeled, sliced
* CRUNCHY TOPPING:
* 60g butter, melted
* 1/2 c brown sugar, firmly packed
* 1/4 t cinnamon
* 1/4 t nutmeg

Grease and line 23cm cake tin.  Sift dry ingredients into large bowl.   Add butter water and eggs, then mix well.  Fold in apples then spread mixture into tin.  Spread over crunchy topping.  Bake at 180C for 1 1/4 hours.  Cool cake in pan.

CRUNCHY TOPPING: combine all ingredients and mix well.

Source: Women's weekly

