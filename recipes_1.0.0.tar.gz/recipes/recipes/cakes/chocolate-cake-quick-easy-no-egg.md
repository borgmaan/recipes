# Chocolate cake - quick & easy no egg

* 4oz butter
* 1 c sugar
* 1 1/2 Tablespoons golden syrup
* 7 1/2oz flour
* 1/2 c milk
* 1 1/2 Tablespoons cocoa
* 1/2 teaspoon cinnamon
* 1/4 teaspoon mixed spice
* 1 teaspoon  baking soda
* 1/2 c milk
* 1 teaspoon  vanilla essence

Melt butter, sugar, syrup and milk in a large pot.  Cool.  Add sifted dry ingredients.  Mix in baking soda dissolved in milk and vanilla.  Mix well and place in a ring tin. Bake in a moderate oven (NZ non-fan - 180C) for about 40 minutes.

Ice with chooclate icing.

Time: 40 minutes  

Comments: excellent  
Source: Rally cook book, page 43

