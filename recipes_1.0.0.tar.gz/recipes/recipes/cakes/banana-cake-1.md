# Banana Cake 1

* 125g butter
* 1/2 c sugar
* 1/2 t baking soda
* 1/4 c milk
* 2 large bananas, mashed
* 2 1/4 c self-raising flour
* 2 eggs, beaten

Melt butter and sugar.  Remove from heat, add baking soda, and leave for 5 minutes.   Mix mashed bananas, milk and eggs together.  Add alternately with sifted flour to melted butter mix.  Pour into cake tin and cook for 40 minutes and 180C.

Source: Newspaper

