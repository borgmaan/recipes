# Christmas cake, Grandma's

* 3/4lb butter
* 3/4lb sugar
* 3 T golden syrup
* 6 eggs
* 1/2 c milk
* 1 1/4lb flour
* 1 t baking powder
* 1lb sultanas
* 1lb currants
* 1/2lb peel
* 1/4lb cherries
* 1/4lb almonds
* 1 t each vanilla, lemon,  & almond essence
* 1 1/2 t cinnamon

Cream the butter, essences, syrup and sugar, then add the beaten egg and milk. Mix in dry ingredients then fruit.

Fill lined square tin.  Bake at 135 C for 3 hours.

Time: 180 minutes  
Source: Nancy Arlidge

