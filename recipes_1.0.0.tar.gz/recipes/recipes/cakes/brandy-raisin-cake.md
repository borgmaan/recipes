# Brandy raisin cake

* 1 1/2 c seeded raisins coarsely chopped
* 1 c boiling water
* 1 t bicarbonate of soda
* 125g butter, softened
* 1 c sugar
* 2 eggs
* 2 c flour
* 1 t baking powder
* 1/2 t salt
* 1 c walnuts, coarsely chopped
* Syrup:
* 3/4 c sugar
* 1/4 c water
* 1/4 c lemon juice
* 1 T butter
* 1/4 c brandy

In a small bowl combine half the seeded raisins with the boiling water and the bicarbonate of soda.  In a large bowl cream together the softened butter and sugar until the mixture is light and fluffy.  Add the beaten eggs, one at a time and mix well.  Sift together the flour, baking powder and salt.  Fold the flour into the butter mixture.  Stir in the chopped walnuts and the remaining seeded raisins, then fold in the cooled mixture of seeded raisins water and soda.  Pour the cake batter into a buttered 20cm square cake tin .  

Bake in a moderate oven, for about 45 minutes at 180 C or until cooked when tested.

While cake is still hot and remaining in the tin pierce the cake all over with a fine skewer.  Spoon the brandy syrup over the cake.

Source: Cornell Cookbook

