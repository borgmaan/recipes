# Zucchini/Courgette Chocolate Cake

* 125g butter
* 1 c brown sugar
* 1/2 c white sugar
* 3 eggs
* 2 1/2 c flour
* 1/2 c yogurt
* 1/2 c cocoa
* 2 t baking soda
* 1 tsp cinnamon
* 1/2 tsp mixed spice
* 1/2 t salt
* 1 t vanilla essence
* 3 cups (350g) grated zucchini/or courgette
* 1/2-1 c chocolate pieces (optional)

Line 25 cm square tin.

Cream butter and sugar.  Add eggs one at a time with a spoonful of flour mixture.  Add vanilla and yogurt and stir well.  Sift in dry ingredients and stir in zucchini.

Pour into tin, and sprinkle with chocolate pieces if desired.

Bake at 170C for 45 minutes.


Comments: Great with Strawberries.  AW  
Source: Meals without meat

