# Orange cake

* 6oz butter
* 6oz sugar
* 2 t grated orange rind
* 3 eggs
* 6oz flour
* 1 t baking powder

Cream butter and sugar.  Add rind and beat in eggs.  Sift in four and baking powder.  Mix well and bake at 180C for 45 minutes.


