# Carrot cake, ziggy's

* 2 c raw sugar
* 4 eggs
* 1 c light olive oil
* 1 c wholemeal flour
* 1 c plain flour
* 2-3 t cinnamon
* 2 t baking powder
* 1 t baking soda
* 1/4 t salt
* 1 c walnuts, chopped
* 3 c carrot, grated

Blend the sugar, eggs and olive oil until fluffy.  Add the wholemeal flour to the liquids, then sift in the other dry ingredients.  Add the walnuts and the carrot.  Place mixture in a 23 cm square or round cake pan.  Bake at 150-180C for 1 1/2 hours or until cooked.  Ice with lemon icing when cool.

Time: 110 minutes  

Comments: delicious  
Source: Living Today

