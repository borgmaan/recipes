# Super Easy Ultimate Large Chocolate Cake

* 3 cups self raising flour
* 2 cups sugar
* 3/4 cup cocoa
* 200g  softened butter
* 2 tsp baking soda- lumps squashed
* 1 cup milk
* 1 & 1/2 tsp vanilla essence
* 3 large eggs
* 1 cup boiling hot coffee
* Prepare a 30cm round cake tin by lining it with paper.  Alternativey use a regular cake pan and a loaf tin.
* Place all ingredients except coffee in a large bowl.  Add hot coffee and beat with wooden spoon or beater until smooth and lump free.  Pour into tin/s and bake at 160C for 60 minutes.




Comments: Large and fabulously moist and delicious.  See how to make it here:
http://www.youtube.com/user/annabellangbein?blend=3&ob=5#p/u/0/E5fdrbfdtbg
Lovely to watch too!  
Source: Annabel Langbein - New Zealand super-cook

