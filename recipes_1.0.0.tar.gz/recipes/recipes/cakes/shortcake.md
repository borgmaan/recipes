# Shortcake

* 4 oz butter
* 4 oz sugar
* 1 egg
* 1 1/2 c flour
* 1 t baking powder
* 1 pinch salt
* FILLINGS:
* Caramel
* 1 T butter
* 2 T condensed milk
* 1 T golden syrup
* 2 T brown sugar
* Lemon
* 2 oz butter
* 1 egg
* 1/2 cup sugar
* 1 lemon rind and juice
* Fruit
* 1 c dates
* 3 apples
* 1/2 cup water

Cream butter and sugar.  Ad beaten egg gradually, mix well.  Sift in dry ingredients and stir well.  Divide mixture in half and cover greased sandwich tin with one half rolled to fit.  Cover with filling.  Roll out second price on floured greaseproof paper to fit the tin then invert it over the mixture.  Bake at 180C for 30 minutes.

FILLINGS:
Caramel - heat slowly together until caramel coloured.  Add 1 T boiling water.

Lemon - Mix butter and sugar in top of double boiler.  Add beaten egg and finely grated rind and juice of lemon.  Cook until it thickens, stirring all the time.  Cool.

Fruit - Simmer for 30 minutes.

Source: Onslow College Cookbook, page 158

