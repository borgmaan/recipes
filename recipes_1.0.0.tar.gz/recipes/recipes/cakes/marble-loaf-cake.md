# Marble loaf cake

* 150g butter
* 1 1/2 c sugar
* 2 eggs, separated
* 1 1/2 T cocoa
* 1/2 c boiling water
* 1 3/4 c flour
* 1 1/2t baking powder
* Icing:
* 1 1/2 c icing sugar
* 1T soft butter
* 2T cocoa
* Hot water to mix

Cream butter and sugar,  add yolks one at a time.  Beat egg whites until stiff fold into creamed mixture.  Dissolve cocoa in 3T of the boiling water.  Add remaining water to the cake mixture alternately with sifted flour and baking powder.

Divide mixture in two.  To one half add the cocoa and mix well.  Place the two mixtures alternately into a greased tin.  Bake at 180C for 50-60 minutes.  When cooled remove from tin and cool on a wire rack.  Ice when cold.

To make icing : Sift icing sugar, add softened butter and cocoa, mix together, add hot water to soft consistency.  Spread over cake.


