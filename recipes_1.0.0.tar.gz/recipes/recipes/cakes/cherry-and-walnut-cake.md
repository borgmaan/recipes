# Cherry and Walnut Cake

* 180g butter
* 180g castor sugar
* 3 eggs
* 220g self raising flour
* 100g glace cherries chopped in half
* 75g coarsely chopped walnuts
* 3 additional T flour for rolling cherries and nuts in
* 1/2 t vanilla essence
* 1-2 T milk

Heat oven to 160C.  Grease and flour and 18cm cake tin.  
Cream butter and sugar until light.  Gradually beat in eggs one by one.  Mix glace cherries with walnuts and 3 T flour.  Fold 220 g flour into the batter, then add the floured nuts and cherries with vanilla essence.  Moisten with milk to give a dropping consistency.  Pour into the tin and bake for about 75 minutes until risen and golden.  Turn
onto a rack to cool.  Dust with icing sugar and slice to serve.


Comments: Sir John's favourite  
Source: Brisbane paper

