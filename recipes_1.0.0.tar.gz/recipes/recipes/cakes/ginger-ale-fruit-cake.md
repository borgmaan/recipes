# Ginger Ale Fruit Cake

* 300ml ginger ale
* 1/2 lb sultanas
* 1/2 lb dates
* 1/2 lb currants
* 1/2 lb raisins
* 2oz peel
* 1t vanilla essence
* 1t almond essence
* 1/2 lb butter
* 1/2 lb sugar
* 4 eggs 
* 10oz flour
* 1 t baking powder

Soak sultanas, dates, currant, raisins and peel in ginger ale overnight.  The next day cream butter and sugar and add in eggs.  Sift in flour and baking powder and mix well.  Add soaked fruit and essences and bake at 140-150C for 3 hours.

Source: Notebook

