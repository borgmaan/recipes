# Gluten Free Orange Cupcakes

* 225g butter
* 225g caster sugar
* 6 eggs at room temperature
* 110g wheat-free and gluten-free plain flour
* 110g cornflour
* 4 level teaspons gluten-free baking powder
* 55 g ground almonds
* finely grated zest of an orange

Preheat oven to 180 C/Gas 4 and place muffin paper cases in a large 12 cup muffin tin. 

Beat butter and sugar to a cream and then beat in eggs.  Sieve flours with baking powder and stir in along with ground almonds and orange zest.

Distribute evenly among the 12 cases.  Bake for 15 -25 minutes until golden and cooked.

Cool on a wire rack and ice if desired when cold.  May be frozen.


Comments: Makes 12  cupcakes (one and a half inch high muffin cases) or 24 small ones.

Lemon may be substituted for orange if desired.  

