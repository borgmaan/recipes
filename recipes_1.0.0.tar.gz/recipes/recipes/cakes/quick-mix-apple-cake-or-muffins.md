# Quick Mix Apple cake or Muffins

* 2 cooking apples
* 1 c sugar
* 1 1/2 c flour
* 1 t baking soda
* 1 t cinnamon
* 1/2 t nutmeg
* 1/2 t allspice
* 4oz (125g)  butter
* 1 egg
* 1/2 c each walnuts & raisins
* Icing sugar

Grate, peel or dice 2 cooking apples.  Put in bowl and sprinkle 1 c sugar.  Sift in dry ingredients.  Add melted butter and egg.  Add walnut and raisins. 

Bake in round tin for 50-60 minutes at 180 C.

Sprinkle with icing sugar when cold.

Can be baked as 12 muffins too.

Source: Cornell Cookbook

