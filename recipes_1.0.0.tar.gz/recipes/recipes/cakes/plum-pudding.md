# Plum pudding

* 6 C fine breadcrumbs
* 1 1/2 t salt
* 1 1/2 t cinnamon
* 1 t nutmeg
* 1/2 t ground cloves
* 1 1/4 C light brown sugar
* 1 1/2 C scalded milk
* 12 eggs, beaten
* 3/4 lb butter, chopped finel
* 3 cups raisins
* 1 cup currants
* 1 1/2 C candied peel
* 1/2 C chopped dates
* 1 C chopped dried apples
* 1 C rum

Mix crumbs, salt, spices, brown sugar.  Add milk and let stand until cool.

Add eggs, butter.  Mix.  Add fruits (and rum) and mix to separate fruit.

Turn into greased molds, cover with foil, stand on a rack in an inch of water in a pot with tight lid.  steam 5-6 hours adding more boilding water as necessary.

Source: Di Cook

