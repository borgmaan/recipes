# Fisherman's Cake

* 1 orange
* 1/2 c dates
* 1/2 c walnuts
* 110g butter
* 1 c sugar
* 1 egg
* 2 c flour
* 1 t baking soda
* 1 c milk

In a food processor or blender place the orange cut in quarters (skin and flesh), the dates and walnuts.  Process until finely chopped.

Cream butter and sugar until light and fluffy.  Add the egg and mix.  Add orange and date mixture.  Sift in flour.  Lastly add the baking soda dissolved in the warm milk.  Mix until combined.

Spoon into a 20cm cake tin and bake at 170C for 60 minutes.  When cool ice with orange icing if desired.

Time: 80 minutes  
Source: newspaper

