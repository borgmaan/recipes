# Lasagna

* 1 lb lasagna
* Meat layer:
* 500g mince
* 1 large jar of pasta sauce
* Cheese layer:
* Large tub of cottage cheese
* 2 eggs
* 1 cup of cheese
* Salt & pepper
* Veggies:
* Spinach
* Mushrooms
* Extra cheese for topping

Boil lasagna according to package.  Brown mince and heat through with pasta sauce.  Mix cottage cheese, eggs & cheese together.  

Layer lasagna, then meat, then cheese and veggies.  Repeat.  Top with extra cheese.

Cook at 350F for 45 minutes or until top is golden brown.  Let cool for 20 minutes then slice and serve.

Source: Jeffrey Edwards

