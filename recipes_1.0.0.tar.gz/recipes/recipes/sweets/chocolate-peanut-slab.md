# Chocolate peanut slab

* 8oz kremelta solid white vegetable fat
* 1 c milk powder
* 1 c icing sugar
* 1 c sultanas
* 1 c peanuts, roasted
* 1/2 c cocoa
* 1 1/2 c rice bubbles
* 1/4 c coconut (optional)

Mix all dry ingredients together and add melted kremalta.  Pour into shallow tin to set


Comments: Tasty but probably very unhealthy now we know about hyrdrogentaed veg fat.  
Source: Rally cook book, page 203

