# Russian Fudge

* 1/2 cup milk
* 3 cup sugar
* 1/2 tin sweetened condensed milk
* 4oz butter
* 1/4 teaspoon salt
* 1 Tablespoon golden syrup

Heat all ingredients very gently in a large heavy bottomed non stick saucepan.  

Stir until the mix is boiling. Simmer about 30 minutes, stirring frequently until thick and dark golden brown  - about 120 C on a candy/jam thermometer (hard ball stage).  

Cool for a few minutes in a sink of cold water , then beat with a wooden spoon or electric hand beater until very thick.  Pour into a greased tin, or heat proof container equivalent to 240cm  or 9 inches square.  Mark into squares when the candy is warm and cut up when set.

Vanilla and nuts may be added if desired, prior to beating.

Keep in an airtight container.


Comments: Very similar to Mella's West Cork Fudge.  
Source: Rally cook book, page 204

