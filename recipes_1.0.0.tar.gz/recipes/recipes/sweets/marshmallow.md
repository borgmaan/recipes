# Marshmallow

* 2 c sugar
* 1 1/4 c water
* 2 T gelatine
* 1 t vanilla

Add 1/2 c water to sugar and simmer until soft ball stage.  Cool and add remaining water in which gelatine has been soaked.  Add vanilla essence.  Beat until stiff. Quickly pour into a flat wet 9 inch square dish.  When set cut inot squares with a wet knife and roll in toasted coconut.

Source: Notebook

