# Peppermint Cushions

* 1 T butter
* 2 T sugar
* 1/4 c golden syrup
* 3/4 - 1 c milk powder
* 1 t peppermint essence

Slowly boil butter, sugar and syrup until soft ball stage.  Take off heat and add essence and milk powder.  When cool enough to handle knead and roll into logs.  Cut each log into square cushions.

Source: Notebook

