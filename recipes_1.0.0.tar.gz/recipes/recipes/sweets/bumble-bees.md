# Bumble Bees

* 1 tin sweetened condensed milk
* 2 c mixed dried fruit
* 2 c dessicated coconut

Mix well together and form into balls and place on a well greassed oven slide.  Preheat oven to 180C then turn off.  Place in oven and leave for 30 minutes or until firm.

Time: 45 minutes  

Comments: Note that the oven is turned off while the Bumble Bees are in there.  
Source: Rally cook book, page 61

