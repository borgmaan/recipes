# Apricot almond fudge

* 200g butter
* 100g brown sugar
* 1/2 tin sweetened condensed milk
* 2 pkts biscuits,  plain or coconut flavoured, crushed finely
* 100g dried apricots finely chopped
* Rind of 1/2 lemon finely grated
* 1/2 t almond essence

Place the butter, sugar and condensed milk in a large heatproof microwave bowl and cover loosely.  Microwave on 100% power for 4 minutes, stirring well every minute.  Alternatively boil for 2 minutes, stirring frequently to prevent catching.

Remove from the microwave and mix in all other ingredients.  Press the mixture into a sponge roll tin and chill for about 20 minutes before icing.  

To ice combine 50g soft butter and 300g icing sugar with enough water to make a spreadable icing.  Mix in 1 teaspoon of vanilla and a dash of almond essence.  Spread over the slice and dot with sliced toasted almonds.  Chill until icing has set then cut into bite sized squares.


Comments: Microwave recipe.  
Source: Notebook

