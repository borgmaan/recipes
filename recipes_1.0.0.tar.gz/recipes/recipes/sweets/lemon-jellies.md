# Lemon jellies

* 1 1/4 c lemon juice
* 1/4 c lime juice
* 1/2 c water
* 8 envelopes jelly
* 1 1/4 c sugar
* 2 T lime zest
* 2 T lemon zest

Combine 1 cup juice/water mix with gelatin and mix. Boil other cup and sugar until 255 F (hard ball stage). Mix with juice and zest. Refrigerate until set (~4 hours), then cut into pieces and coat in sugar.


Comments: Do not serve to vegetarians if 'jelly' comes from gelatine.  
Source: http://cooking-from-scratch.blogspot.com/2010/12/lemon-jellies.html + http://www.foodnetwork.com/recipes/alton-brown/acid-jellies-recipe/index.html

