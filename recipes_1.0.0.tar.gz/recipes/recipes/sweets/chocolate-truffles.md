# Chocolate truffles

* 4 T butter
* 4 T cocoa
* 8 T sugar
* 1/2 c walnuts and fruit (cherries sultanas and dates)
* 4 T fresh milk
* 12 T dried whole milk 
* 1  t vanilla essence
* a little desiccated coconut

In a saucepan place the butter, sugar and fresh milk, heat slowly until sugar is dissolved.  Sift together the cocoa with the dried milk.  Add the nuts and fruit and the vanilla essence.  Pour into the dissolved sugar mixture and mix well.  Let the mixture stand until firm and then break off small pieces and roll into balls.  Roll in coconut or chocolate hail.


Comments: A TREAT!  
Source: Onslow College Cookbook, page 138

