# Rum balls

* 300g crushed maltmeal or digestive biscuits
* 1 tin sweetened condensed milk
* 1 cup of mixed dried fruit - raisins etc.
* 1 1/4 c desiccated coconut
* 1/2 c lemon juice
* 2 T rum or brandy
* 2 T baking cocoa
* Coconut for decoration

Mix the crushed biscuits with sweetened condensed milk, dried fruits, measured coconut, lemon juice, baking cocoa, and rum or brandy.  Chill the mixture and roll into 3cm diameter balls.  Roll in extra coconut.  

Store refrigerated.

Source: Modified Highlander Can

