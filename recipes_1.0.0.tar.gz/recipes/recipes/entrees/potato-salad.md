# Potato Salad

* 6 potatoes, medium
* 3/4 c canned whole kernel corn
* 1/4 c parsley, chopped
* 1/4 t salt
* ground back pepper
* 1 T French dressing
* 1/4 c mayonnaise

Boil scrubbed potatoes until tender.  When cool peel and cube.  Gently mix potato cubes with remaining ingredients.  Serve cold.

Time: 25 minutes  
Source: Kid's Cookbook, page 27

