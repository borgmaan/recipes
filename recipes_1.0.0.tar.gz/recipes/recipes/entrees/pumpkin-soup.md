# Pumpkin soup

* 2 large onions
* clove crushed garlic
* 1 T olive oil
* 4 c cut and peeled pumpkin pieces (not Halloween pumpkin but any of the dry, firm pumpkin or squash types e.g. butternut, buttercup, whanga crown, ironbark etc.)
* 1 t beef or vegetable stock powder
* 1/4 t nutmeg
* 1 t salt
* 1/4 t white pepper
* water to cover

Peel and chop onions.  Gently cook with garlic in oil until soft.  Add pumpkin pieces and remaining ingredients.  Boil for 30 minutes until soft.

Blend until creamy in food processor.  Thin if necessary with water, milk or cream.  Adjust seasonings if necessary. Serve piping hot(but do not boil if thinned with dairy products) with crusty bread.


