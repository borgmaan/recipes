# Curried Sweet Potato or Parsnip Soup

* Serves 4-6
* 2 cloves garlic
* 1/2-1 teaspoon curry powder
* 75 g butter
* 500g sweet potato or parsnip
* 1 cup water
* 2 teaspoon vegetable or other stock flavouring
* 3 cups milk

Melt butter in large pot and add curry powder and garlic. Peel vegetables and slice into pieces 1 cm thick. Cook in butter 1-2 minutes but do not brown.  Add the water and stock flavouring, cover and cook for ten minutes until tender.  Puree and thin with milk until it is the desired consistency. Reheat but do not boil.  Serve.


Comments: Fast and delicious.  

