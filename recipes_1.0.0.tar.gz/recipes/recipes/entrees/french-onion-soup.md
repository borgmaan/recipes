# French Onion Soup

* 3 onions
* 1 T brown sugar
* 25 g butter
* 1 T plain flour
* 2 beef stock cubes
* 1 1/2 c hot water
* 1 cup hot water
* 4 slices cheese
* 4 slices French bread, toasted

Slice onions.  Put in large bowl with brown sugar and butter.  Cover with cling wrap.  Pierce.  Micro-cook on high for 2 1/2 minutes.  Add flour, stock cubes, and 1 1/2 c hot water.  Stir.  Cover and pierce.  Micro-cook on high power for 10 minutes.  Stir.  Add the 1 cup hot water.  Put cheese on toasted bread and micro-cook until cheese melts.  Float toast on top of soup.

Source: Kid's Microwave Cookbook, page 20

