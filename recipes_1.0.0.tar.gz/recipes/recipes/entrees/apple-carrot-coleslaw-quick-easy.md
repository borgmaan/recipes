# Apple & Carrot coleslaw -  quick & easy

* About 2-3 cups finely sliced mild flavoured cabbage 
* (Sweet heart variety is good) cut into 3 inch shreds.
* 1 medium carrot peeled and coarsely grated 
* 1 red eating apple washed and grated
* 2 tablespoons mixed seeds (pumpkin, sunflower etc)
* 1 tablespoon store bought mayonnaise
* 1 tablespoon unsweetened plain yogurt
* ½ teaspoon whole grain mustard
* Salt & pepper to taste
* Prepare fruit and veg and toss together with seeds in a salad bowl.
* Mix yogurt, mayo and mustard together and stir through slaw.
* Season to taste and garnish with more seeds.
* Vary ingredients to suit yourself.
* Serves 4




Comments: Leftovers keep well for 24 hours if covered with cling wrap and stored in fridge.  
Source: ALW creation

