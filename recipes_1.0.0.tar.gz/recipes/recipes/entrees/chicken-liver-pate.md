# Chicken liver pate

* 1 lb chicken livers
* 1 clove garlic, crushed
* 2 rashers bacon
* 2 oz butter
* 2 small onions, finely chopped
* chopped parsley
* 3 T sherry

Brown garlic, onion and bacon lightly in butter.  Add chopped chicken livers and cook 10 -15 minutes.  Add sherry and parsley and put through liquidiser.  Shape into log, cover and put in fridge.  Slice thinly, garnish with parsley and lemon.

Source: Onslow College Cookbook, page 5

