# Hummus with Yogurt & Lemon

* 2 large garlic cloves
* 1 15 oz can chick peas (garbanzo beans) drained
* 2 T plain non-fat yogurt
* 2 T tahini
* 2 T fresh lemon juice
* pinch ground cumin

Mince garlic in processor.  Add remaining ingredients and process, scraping down sides of the bowl regularly, until a coarse puree results.  Season to taste with salt and pepper.

Transfer to a small bowl, cover and place in fridge.  Bring to room temperature before serving with raw vegetable sticks or pita bread.  Keeps refrigerated for at least three days.

Makes a cup and a half.


Comments: Delicious lower fat version of an old favourite.  

