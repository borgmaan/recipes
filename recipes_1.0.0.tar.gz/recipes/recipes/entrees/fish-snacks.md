# Fish Snacks

* 6 slices cut bread
* softened butter
* 1 c mashed potato
* 1/2 - 3/4 c cooked smoked fish fillets
* 1 small egg
* 1T finely chopped onion
* 1 rasher bacon, chopped
* 1T chopped parsley
* salt and pepper to taste

Butter bread evenly.  Remove crusts and cut each slice into for small squares. Press these butter-side down into patty tins.  Combine the remaining ingredients and place in spoonfuls in each of the uncooked bread cases.  Bake at 180C for 20-30 minutes or until cases and filling are golden brown.  Serve hot garnished with parsley or to follow soup, lunch or tea, or as savouries.


Comments: Tasty  
Source: Cornell Cookbook

