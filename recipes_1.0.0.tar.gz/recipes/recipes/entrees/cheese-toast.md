# Cheese toast

* 1 egg
* 1 c cheese, grated
* 2 T chutney
* 1 T onion, grated
* 1 t Worcestershire sauce
* 25g butter, melted
* 6 thick slices wholegrain bread

Mix together all ingredients, stir well.  Grill bread on one side.  Spread cheese mixture on other side.  Grill until cheese is melted and bubbly.

Time: 20 minutes  

Comments: Delicious  
Source: Kid's Cookbook, page 14

