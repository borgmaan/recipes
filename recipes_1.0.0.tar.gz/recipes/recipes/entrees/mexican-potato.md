# Mexican Potato

* 4 large red potatoes
* 1 1/2T vegetable oil
* 1t garlic granules
* 1t steak seasoning
* 1t chilli powder

Wash and cut potatoes into 8 pieces, cover and microwave for 7 minutes on high.  Drain on paper.  Heat oil in frying pan and potatoes and seasoning.  Cook until golden.

Source: Cornell Cookbook

