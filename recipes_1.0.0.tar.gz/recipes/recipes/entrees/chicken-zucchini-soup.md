# Chicken & Zucchini Soup

* 20g butter
* 3 chicken breast fillets finely sliced, or equivalent in left over cooked chicken 
* 800g zucchini grated
* 2 cloves garlic crushed
* 1 carrot grated
* 2 tablespoons plain flour
* 3 cups (750 ml) chicken or vegetable stock
* 1 cup (250 ml) milk

Melt butter in a large pot.  Add uncooked chicken and cook until done but not browned. Add zucchini, carrot, garlic and cook for 5 minutes stirring occasionally.

Stir in flour and cook for a couple of  minutes.  Add stock and cooked chicken and bring to boil, stirring until soup thickens slightly. Simmer for a minute or two.  Stir in milk and season with salt and pepper.  Serves 4


Comments: This recipe can be halved to serve 2. A quick, colourful and tasty way of using up courgettes/zucchini.  

