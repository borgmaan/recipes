# Sushi Salad

* For two servings - scale up as needed.
* 1 heaped cup sushi rice
* 1 and 1/2 cups water
* 30g sugar
* 1/4 teaspoon salt
* 25ml of white wine vinegar
* 2 sheets sushi nori (seaweed)
* 2 cups fillings e.g selection of smoked or cooked fish, chicken, crabmeat, prawns, avocado, cucumber,cooked peas or beans, pumpkin or squash etc.  Whatever would taste good  and look colourful together.
* One egg & 1 tablespoon water

Wash rice until water runs clear and drain in colander. Cook in pot with close fitting lid. Bring to boil over a medium heat.  Cook until all water has been absorbed.
Remove from heat and take off lid, spread clean kitchen towel over the top of the pot, replace lid and let stand for 10 minutes.
Meanwhile blend sugar, salt and vinegar together over a low heat.  Empty rice into a non-metallic container and stir vinegar mix through it.
Lightly beat egg and water and cook as an omelet until just firm.
Stir fillings through rice mix. Cut up omelet and sushi nori into bite sized rectangles and arrange decoratively on top.
Serve.


Comments: If you love sushi, this is a quick, tasty and easy way to prepare it.  
Source: Inspired by Keiko, our Japanese friend.

