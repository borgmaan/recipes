# Baked potato soup

* 1/2 c butter
* 1/2 c flour
* 7 c milk
* 4 potatoes, roasted, peeled & cubed
* 4 green onions (optional)
* 10-12 rashers turkey bacon
* 1/2 c sour cream (or yoghurt)
* 1 1/2 smoked gouda, grated

Make roux and cook for ~10 minutes.  Add potatoes and green onions and cook for another 10 minutes.  Mix in remaining ingredients.


Comments: Hearty comfort food  
Source: http://southernfood.about.com/od/potatosoups/r/bl30324f.htm

