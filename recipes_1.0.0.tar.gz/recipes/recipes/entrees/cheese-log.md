# Cheese log

* 4 c grated cheese
* 4 T ham, chopped
* 1/2 c walnuts
* 1/2 green pepper
* 2-3 cloves of garlic
* 2-3 T mayonnaise

Mix all ingredients together and chill.  Take care to not make the mixture to sloppy


