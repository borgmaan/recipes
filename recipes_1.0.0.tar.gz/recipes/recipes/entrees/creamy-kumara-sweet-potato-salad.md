# Creamy kumara (sweet potato) salad

* 2 large kumara or sweet potatoes
* 1/4 c raisins
* 1/2 c green pepper or spring onion, finely chopped
* 1 T orange rind, grated
* 2 T orange juice
* 1/4 c light sour cream
* 1/4 c milk
* freshly ground black pepper

Scrub the kumara, do not peel.  Cut in half and boil for 20-25 minutes or until softened but still firm.  Drain and cut into bite-sized chunks.

Place the kumara, raisins, pepper and orange rind in a large bowl.  Blend the orange juice, sour cream and milk together.  Pour over the kumara and mix well.  Season generously with black pepper.

Source: The vegie cookbook, page 60

