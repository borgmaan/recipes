# Chicken Cheese Chowder

* 4 T butter
* 1 cup grated carrot
* 1 c diced cooked chicken
* 1/4 c chopped onion
* 1/4 cup flour
* 2 c milk
* 1 1/2 c chicken broth
* 1 T dry white wine
* 1/2 t celery seed
* 1/2 t Worcester sauce
* 1 c grated cheese

In large saucepan, cook onion and carrot in butter until tender but not brown.  Blend in flour, add milk and chicken broth.  Cook and stir until thickened and bubbly.  Stir in chicken, wine, celery seed, and Worcester sauce.  Heat through. Ad cheese, stir until melted.  Garnish with snipped chives.

Source: Onslow College Cookbook, page 16

