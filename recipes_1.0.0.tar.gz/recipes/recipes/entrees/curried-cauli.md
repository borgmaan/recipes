# Curried Cauli

* 1 small cauliflower, cut into florets
* 1 T oil
* 1 onion, finely chopped
* 1 T curry
* 2 T pumpkin seeds
* 2 t sugar
* 1/4 c water
* 1 c mushrooms, sliced
* 1 green pepper, finely chopped
* 1/4 c currants

Blanch the cauliflower in boiling water for 2-3 minutes.  Coll under cold running water.  Drain.
Heat the oil in a pan, add the onion, curry powder and pumpkin seeds.  Stir-fry for 2-3 minutes or until the onion softens.  Mix in the sugar and water.  Remove from heat.
Add the cauliflower, mushrooms, pepper and currants.  Mix thoroughly until well coated in curry mixture.  Serve warm or cold.

Source: The vegie cookbook, page 53

