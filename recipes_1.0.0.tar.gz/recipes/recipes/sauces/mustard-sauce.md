# Mustard Sauce

* 1 egg
* 1/4 c sugar
* 1 T flour
* 1 t mustard
* 1 c water, from corned beef
* 1/4 c vinegar

Beat egg and sugar, add flour, mustard, then stir in liquid gradually.  Microwave on high until thick.

Source: Edmonds Cook Book, page 151

