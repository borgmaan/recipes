# Cocktail sauce for shellfish

* 3-4 T mayonnaise
* 2 T tomato sauce
* Dash of Worcester sauce
* Salt
* Pepper
* Lemon juice
* 1/4 pt whipped cream

Mix ingredients and lightly add into whipped cream.  Chill.  Top shellfish with sauce.

Source: Rally cook book, page 9

