# Lemon Butter

* 1/2 c lemon juice
* 75g butter
* 1 1/4 c castor sugar
* 2 t lemon rind, grated
* 4 eggs, beaten

Micro-cook juice and butter on high for 1 1/2 minutes.  Whisk in the sugar and lemon rind.  Add the beaten eggs.  Micro-cook, on high, for 7 minutes.  Whisk well for 1-2 minutes.  Pour into hot, dry, clean jar.

Source: Kid's Microwave Cookbook, page 100

