# Bread and butter pickles

* 2 L sliced cucumbers
* 1/2 - 1 L sliced onion
* 1/2 c salt
* 3 c white wine vinegar
* 2 c sugar
* 1 T mustard seeds
* 1 T celery seeds
* 1 t turmeric

Slice cucumbers and onions thinly into 2 L ice cream containers for easy measuring.  Sprinkle the sliced vegetables with salt, cover with cold water and leave to stand for 8 - 12 hours, then discard salty water and drain well.

In a large saucepan or jam pan, heat vinegar, sugar, seeds and turmeric.  When mixture boils add the drained vegetables.

As soon as the mixture come back to the boil, ladle vegetables and liquid into cleaned, sterilised, hot bottles.  Fill to overflowing and seal immediately with seals that have been boiled for 5 minutes.  Screw on bands.

Remove bands when pickles are quite cold and wash jars to remove any vinegary syrup.

Store in a cool, dark place.

Source: Alison Holst Calendar

