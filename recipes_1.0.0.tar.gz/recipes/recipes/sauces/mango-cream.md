# Mango Cream

* 250g cream cheese
* 1 T lemon juice
* 1/3 c castor sugar
* 1 1/4 c thickened cream
* 1 small mango, pureed

With electric beaters, beat cream cheese, lemon juice and sugar until smooth.  Beat cream until soft peaks form, then fold into mango mixture.

Serve on pavlova or meringues.


Comments: Delicious with pavlova or meringue  
Source: Family Circle Bestever Christmas Book, page 12

