# Sauce for preserving beetroot

* 1 cup water
* 1 cup sugar
* 2 cups malt vinegar
* 1 tablespoon salt.

Boil sauce for ten minutes.  

Pour over hot sliced or cubed cooked beetroot.  Fill to overflowing hot sterilized glass jars with beetroot and sauce and screw on sterilized metal lids (the kind with a rubber seal in them) immediately.

When jar lid depresses on cooling you know you have a patent seal and contents will be safe to eat.

Source: Tawa neighbour

