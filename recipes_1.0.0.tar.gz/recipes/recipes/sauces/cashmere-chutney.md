# Cashmere Chutney

* 450g tart apples
* 225 g onions
* 8 cloves garlic
* 1 c choppd dates
* 1 c seedless raisins
* 1 c stoned prunes
* 2/3 c chopped crystallised ginger
* 2 t salt
* 1 t curry powder
* 1/4 t ground pepper
* 2 c white sugar
* 3-4 c white vinegar

Peel apples and cut into chunks.  Peel onions & garlic and slice finely.  Combine all ingredients into a large deep saucepan.

Bring to boil stirring to dissolve sugar.  Reduce heat and simmer gently for 40 minutes until fruit is soft and mixture is thick.  Stir often to prevent sticking.  Add extra vinegar if it gets too thick.  Spoon into prepared jars and seal.

Source: Gifts from the Pantry the New Zealand way

