# Apple, peach and apricot chutney

* 500g cooking apples, cored, peeled & chopped
* 110g dried peaches
* 110g dried apricots
* 50g sultanas
* 6 cloves garlic, mashed
* Two 1" cubes of fresh ginger
* 400ml white wine vinegar
* 2 t salt
* 1/2 t cayenne pepper

Combines all ingredients in a heavy pot and bring to boil.  Vigorously simmer for 30 minutes until thick.  Stir frequently.  Will thicken as it cools.  Pour into  clean jars.


Comments: Double recipe  
Source: Mary H

