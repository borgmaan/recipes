# Custard - Microwave

* 2T custard powder
* 2T sugar
* 1 1/2 c milk

Mix custard powder and sugar and gradually add milk.  Microwave on power for 3-4 minutes, or until thick.  Stir well then stir while hot.

Source: Cornell Cookbook

