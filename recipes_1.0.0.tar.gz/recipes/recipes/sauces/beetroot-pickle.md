# Beetroot Pickle

* 2 large or 4 small beets, boiled in water (skin on) until tender, about 1 hour
* 1 smallish cinnamon stick
* 1/2 tsp allspice
* 1/2 tsp whole cloves
* 225ml white wine vinegar
* 225ml water
* 225g caster sugar

Peel the cooked beets and cut into 3cm hunks. Heat the vinegar, water, sugar and spices in a large pan. Bring just to the boiling poin. Add the beets and cook for 2-3 minutes. Then, pack in sterile jars, fill with hot liquid. Seal. 

If you don't fancy properly pickling them, simply follow the instructions, place the beets in a fridge-friendly container, allow the beets to cool fully and then store in the fridge for up to a week.


Comments: I used this for three large beetroot we were given while A was away in NZ. Increased all quantities by 50%.  Made six jars (255ml).  BW   
Source: http://www.abelandcole.co.uk/recipes/beetroot#recipe29

