# Chocolate Sauce

* 1T butter
* 2T sugar
* 1/2T custard powder
* 1T cocoa
* 1/2 c water

Melt butter in microwave.  Then mix in sugar, custard powder and cocoa.  Stir in water then microwave on high until thick.

Source: Notebook

