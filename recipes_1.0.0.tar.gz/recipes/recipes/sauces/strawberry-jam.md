# Strawberry Jam

* 1 kg strawberries
* 1/4 c water
* 1 1/2 kg sugar
* 2 t tartaric acid

Hull the berries.  Bring to boil with the water in a jam pan, crushing with a potato masher as they cook.  As soon as the fruit is soft, add the sugar and bring to the boil stirring frequently.  

Boil briskly for 3 minutes then add acid and stir well.   This dramatically changes the colour of the jam.

Boil 5 minutes longer then pour into clean, warm bottles and seal.

Source: Alison Holst Calendar

