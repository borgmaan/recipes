# Rhubarb Conserve

* 3 cups finely sliced rhubarb (red stems make the most attractive jam)
* 1 tablespoon peeled root ginger
* 1 lemon, rind and juice
* 1  orange, rind and juice
* 2 Cups sugar
* 1/2 cut chopped walnut pieces

Trim rhubarb and slice into 1 cm chunks and place in large saucepan.
Place 1 cup sugar, citrus rinds (use a floating blade peeler and avoid pith) and roughly chopped ginger into a food processor and whizz until finely chopped. Place into saucepan along with all other ingredients except walnuts.

Bring slowly to the boil and boil until thick and clear stirring often.  

While cooking pour boiling water over walnuts in a small bowl and leave 2 minutes.  Drain well. 

Check that conserve has reached setting point by placing about half a teaspoonful on a saucer in a cool place.  When cool, push surface with forefinger.  If ready to set a wrinkled skin should be visible. 

Stir in nuts and bottle into sterilised jars and screw on sterilised lids. 


Comments: A tasty alternative to marmalade.  
Source: A Holst's Cooking Class

