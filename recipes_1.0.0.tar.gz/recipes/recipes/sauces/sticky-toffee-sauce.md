# Sticky Toffee Sauce

* 200g brown sugar
* 200ml cream
* 1 t butter
* 1 t vanilla
* 1 t rum or marsala wine
* walnuts

Combine all ingredients and bring to the boil.  Simmer for three to four minutes.  Pour over ice cream or other dessert, if you wish sprinkle with chopped walnuts.

Source: Newspaper

