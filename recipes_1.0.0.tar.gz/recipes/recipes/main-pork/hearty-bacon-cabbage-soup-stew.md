# Hearty bacon & cabbage soup/stew

* 250g lean bacon 
* 2 leeks or 1 large onion - sliced finely
* 1 large carrot grated
* 2 cloves garlic minced
* 1 large potato, peeled and diced
* 1 15 ounce can chopped tomatoes and juice
* 1/2 tsp brown sugar
* I/2 t chicken or veg. stock
* 1/2 cup water
* 2 cups very thinly sliced cabbage

Brown bacon in a large saucepan - drain off excess fat. 

Add leeks, carrot, garlic, potato and cook, stirring occasionally until softened but not brown. 

Add tomatoes, stock and  water so it can all be left to simmer covered  for 30 mins while stirring occasionally.  
Just before serving stir in cabbage and cook for a few minutes.

Serve in bowls with crusty brown bread.

Serves two.

Variations.

Any cold left over sausages or salami can also be sliced and added towards the end of cooking time or even substituted for some of the bacon..

Stretch to feed four by adding a can of baked beans in tomato sauce.


Comments: Satisfying and tasty for a cold night. Looks colourful and tastes great.  
Source: Alison Wickham

