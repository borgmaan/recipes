# Sweet & sour pork

* 1.5 lb lean pork cubes
* 1 can pineapple chunks
* 1/4 c brown sugar
* 2 T cornflour
* 1/4 c vinegar
* 1 T soy sauce
* 1/2 t salt
* 1/4 c chopped onion

Brown pork slowly in 2 tablespoons hot fat.  Add 1/4 c water and simmer 1 hour.  Make sauce by slowly cook onion in a little oil, add pineapple juice, soy sauce and vinegar, when boiling add cornflower mixed to paste with cold water. Cook until thick.  Pour over pork and stand 10 minutes.  Add onion and pineapple and cook 2-3 minutes longer.

Source: Cornell Cookbook

