# Golden Sausages

* 500g sausages
* 1 T brown sugar
* 1 onion, chopped
* 1 T tomato sauce
* 2 T Worcester sauce
* 1 T vinegar
* 2 T flour
* salt and pepper
* 2 c boiling water
* 1 c carrot, grated

Place raw sausages in microwave bowl.  Mix together dry ingredients and boiling water and pour over sausages with grated carrot.  Micro-cook, covered, on high, for 25 minutes.  Stir often.

Time: 40 minutes  
Source: Rally cook book, page 155

