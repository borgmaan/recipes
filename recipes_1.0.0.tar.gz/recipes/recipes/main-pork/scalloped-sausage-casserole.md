# Scalloped sausage casserole

* 8 sausages
* 1 large onion, thinly sliced
* 2 large potatoes, thinly sliced
* 1 t curry powder
* 43g pkt thick vegetable soup
* 1 1/2 c water

1.  Prick sausages with a fork.  Arrange on paper towel in microwave oven.  Micro-cook, high power, 3 minutes.  Slice pre-cooked sausages.

2.  Place sliced potatoes and onion in a casserole dish.  Add 1 T water.  Micro-cook, high power, 5-6 minutes. or until vegetables are tender.

3.  Combine curry powder and soup powder in large measuring jug.  Gradually stir in water.  Micro-cook, high power, 4 minutes., stirring once during cooking.

4.  Mix sliced sausages into cooked vegetables.  Power sauce over casserole.  Micro-cook, high power 5-6 minutes.

Time: 48 minutes  

Comments: kids don't like it  
Source: NZ Microwave Cookbook, page 26

