# Bacon, egg 'n' noodles

* 2 cups cooked noodle
* 3-4 rashers bacon
* 4 eggs
* 1/4 c milk
* 1/4 t salt
* shake pepper

Cook noodles until just tender.  Chop bacon finely and cook until crisp in a medium-large frying pan.  Beat eggs with milk, and add salt and pepper.  Drain cooked noodle and toss with bacon in pan, coating them with bacon fat.  Pour egg mixture over.  Turn with fish slice while cooking to break up pieces of egg.

Source: Alison Holst Family Cookbook, page 47

