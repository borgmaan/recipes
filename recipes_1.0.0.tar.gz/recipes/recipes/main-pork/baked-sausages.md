# Baked sausages

* 1 lb sausages
* 1 large onion
* tomatoes as required
* 1 T tomato sauce
* 1 T flour
* 1/2 t mustard
* 2 T brown sugar
* 1 T vinegar
* 1 c water

Fry sausages in a little fat until brown.  Place in a casserole and cover with onions and tomatoes. Mix other ingredients together and pour over.  Bake in a slow oven for 2 hours.

Time: 120 minutes  
Source: Onslow College Cookbook, page 92

