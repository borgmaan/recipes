# Pork Casserole with apple

* 600g lean diced pork
* 25g flour
* 2t dried thyme
* 1T vegetable oil
* 2 cloves garlic crushed
* 2 celery sticks chopped 
* 12 halved scallions or 3 quartered red onions
* 2 eating apples cored and chopped into chunks, but not peeled
* 450ml hot vegetable or chicken stock

Heat oil in pan. Roll meat in flour, thyme and seasoning.
Brown meat in oil and transfer to casserole dish.
Brown apples and vegetables in pan and then transfer to casserole dish.
Cover with hot stock and a lid and cook for 1 hour at 180C or 350 F.

Serve with mashed or baked potatoes and a green vegetable.


Comments: Very easy and tasty.  
Source: WW

