# Ginger Stir-Fry

* 1 t sugar
* 1 T dry white wine
* 3 T soy sauce
* 1 t grated root ginger
* 400g boneless trim pork schnitzel
* 6 Chinese or plain cabbage leaves
* 4 spring onions
* 1 T julienne of root ginger
* 2 T Soy oil

Combine the marinade ingredients well.
Cut the pork in thin strips and place in the marinade.  Stir to coat well.  Refrigerate and marinade for 30 minutes.
Cut cabbage leaves in 3 cm squares.  Slice spring onions diagonally.
Heat a tablespoon of oil in a wok or frying pan.  Stir-fry the pork for about 3 minutes.  Remove to one side.  Add remaining oil and add cabbage and onions and stir-fry for 2 minutes.  Add pork, remaining marinade and ginger.  Serve immediately.


Comments: Excellent  
Source: Living Today, page 23

