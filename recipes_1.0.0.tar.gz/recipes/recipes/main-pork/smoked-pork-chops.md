# Smoked pork chops

* 3 big tablespoons of crisco
* pork chops
* flour, salt & pepper
* more flour
* milk

Rinse chops and dip in flour & salt & pepper mix.  Heat crisco over medium heat.  Cook until golden brown and then flip.

Pour off most of fat and then mix in flour to thicken.  Mix in milk.

Serve with mashed potatoes.

Source: Jeff's grandma

