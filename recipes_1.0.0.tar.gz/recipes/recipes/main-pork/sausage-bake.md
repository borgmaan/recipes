# Sausage Bake

* 6-8 sausages
* 1 onion, grated
* 1 apple, grated
* 1/2 c tomato sauce
* 1/4 c water
* 2 t soy sauce
* 1 T brown sugar
* 1 T vinegar

Place sausage in a saucepan with a little water.  Cover, bring to the boil then simmer gently for 5 minutes.  Drain, run cold water over them and slice lengthways.

Grate the onion and apple.  Add to greased baking dish and spread over sides.  Arrange sausages on top and bake at 200C for 30 minutes.

Time: 50 minutes  
Source: Let's cook some more, page 20

